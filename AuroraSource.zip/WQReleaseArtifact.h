// WQ Files – Aurora Edition. GPL-3.0-or-later.
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
enum { WQReleaseMaximumDownloadBytes = 32 * 1024 * 1024 };
// Bounded extraction using the existing archive safety code. Checks metadata
// and arm64 executable header, NOT certificate trust or install eligibility.
BOOL wq_release_validate_ipa(NSURL *file, NSString *version, NSProgress *cancellation);
NS_ASSUME_NONNULL_END
