// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
typedef NS_ENUM(NSInteger, WQAuroraAppearance) {
    WQAuroraAppearanceBlue = 0,   // default: Modern Dark · Blue
    WQAuroraAppearanceRed = 1,    // second design: Modern Dark · Red
};
WQAuroraAppearance wq_aurora_appearance(void);
void wq_aurora_set_appearance(WQAuroraAppearance appearance);
void wq_aurora_apply_window(UIWindow *window);
UIColor *wq_aurora_surface(void);
// Dark-aurora accents: neon cyan and violet, theme-aware.
UIColor *wq_aurora_neon(void);
UIColor *wq_aurora_violet(void);
UIView *wq_aurora_scene_view(BOOL landscape);
// Alternate app icons: name (nil = primary) / title key / icon file stem.
NSArray<NSDictionary<NSString *, id> *> *wq_aurora_icon_choices(void);
// Native dashboard tile: caller supplies measured data and the actual action.
@interface WQAuroraMetricControl : UIControl
@property (nonatomic, readonly) UILabel *valueLabel;
- (instancetype)initWithTitle:(NSString *)title symbol:(NSString *)symbol tint:(UIColor *)tint;
- (void)setCaption:(NSString *)caption;
@end
void wq_aurora_show_splash(UIWindow *window);
UIButton *wq_aurora_update_button(UIViewController *host, NSDictionary<NSString *, NSString *> *release, void (^dismiss)(void));
// No timer or fabricated percentage. Controllers own the actual operation state.
@interface WQAuroraProgressView : UIView
@property (nonatomic) BOOL running;
@property (nonatomic) BOOL indeterminate;
@property (nonatomic, readonly) CGFloat progress;
@property (nonatomic, readonly) UILabel *titleLabel;
@property (nonatomic, readonly) UILabel *detailLabel;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
@end
@interface WQAuroraPreferencesController : UITableViewController
@end
NS_ASSUME_NONNULL_END
