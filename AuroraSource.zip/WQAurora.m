// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
// Presentation only: no container/access, startup-health or file mutation logic.
#import "WQAurora.h"
#import "WQUI.h"
#import "WQUpdate.h"
#import "WQReleaseDownload.h"
#import "WQRecent.h"

static NSString *const WQAuroraAppearanceKey = @"WQAuroraTheme";

WQAuroraAppearance wq_aurora_appearance(void)
{
    NSInteger value = [NSUserDefaults.standardUserDefaults integerForKey:WQAuroraAppearanceKey];
    return value == 1 ? WQAuroraAppearanceRed : WQAuroraAppearanceBlue;
}

void wq_aurora_apply_window(UIWindow *window)
{
    // Dark-only app; Blue is the default design, Red the second one.
    wq_theme_set_red(wq_aurora_appearance() == WQAuroraAppearanceRed);
    window.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
    window.tintColor = wq_neon_blue();
}

void wq_aurora_set_appearance(WQAuroraAppearance appearance)
{
    NSCAssert(NSThread.isMainThread, @"Appearance is a main-thread UI operation");
    if (appearance != WQAuroraAppearanceRed) appearance = WQAuroraAppearanceBlue;
    [NSUserDefaults.standardUserDefaults setInteger:appearance forKey:WQAuroraAppearanceKey];
    wq_theme_set_red(appearance == WQAuroraAppearanceRed);
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            if (UIAccessibilityIsReduceMotionEnabled()) { wq_aurora_apply_window(window); continue; }
            [UIView transitionWithView:window duration:0.22 options:UIViewAnimationOptionTransitionCrossDissolve
                animations:^{ wq_aurora_apply_window(window); } completion:nil];
        }
    }
}

UIColor *wq_aurora_surface(void)
{
    // Immersive Neon surface token (dark navy in dark mode, clean white in light).
    return wq_neon_surface();
}

UIColor *wq_aurora_neon(void)
{
    return wq_neon_cyan();
}

UIColor *wq_aurora_violet(void)
{
    return wq_neon_violet();
}

// 4 app icons about what the app actually does: cleaning, files, storage,
// apps. Wired to the system's alternate-icon API (switch takes effect
// immediately from the in-app picker).
NSArray<NSDictionary<NSString *, id> *> *wq_aurora_icon_choices(void)
{
    return @[
        @{ @"name": [NSNull null], @"title": @"Clean",        @"stem": @"AppIcon60x60" },
        @{ @"name": @"files",    @"title": @"Files",          @"stem": @"AltFiles" },
        @{ @"name": @"storage",  @"title": @"Storage Used",   @"stem": @"AltStorage" },
        @{ @"name": @"apps",     @"title": @"Apps",           @"stem": @"AltApps" },
    ];
}

// This view does not capture touches/VoiceOver and does not own the root VC.
// UIKit starts the real controllers/health checks immediately beneath it.
void wq_aurora_show_splash(UIWindow *window)
{
    UIView *splash = [[UIView alloc] initWithFrame:window.bounds];
    splash.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    splash.userInteractionEnabled = NO;
    splash.accessibilityElementsHidden = YES;
    splash.backgroundColor = UIColor.systemBackgroundColor;
    UIView *background = wq_prism_background_view();
    background.frame = splash.bounds;
    background.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [splash addSubview:background];
    if (!UIAccessibilityIsReduceMotionEnabled()) {
        CAGradientLayer *light = [CAGradientLayer layer];
        light.frame = splash.bounds;
        light.startPoint = CGPointMake(0, 0);
        light.endPoint = CGPointMake(1, 1);
        light.colors = @[(id)UIColor.clearColor.CGColor,
            (id)[UIColor colorWithRed:0.18 green:0.62 blue:0.85 alpha:0.12].CGColor,
            (id)[UIColor colorWithRed:0.48 green:0.32 blue:0.86 alpha:0.12].CGColor,
            (id)UIColor.clearColor.CGColor];
        [background.layer addSublayer:light];
        CABasicAnimation *sweep = [CABasicAnimation animationWithKeyPath:@"locations"];
        sweep.fromValue = @[@(-0.8), @(-0.4), @0, @0.4];
        sweep.toValue = @[@0.6, @1, @1.4, @1.8];
        sweep.duration = 0.63;
        [light addAnimation:sweep forKey:@"aurora.startup"];
    }

    UIImageView *logo = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"folder.fill.badge.gearshape"]];
    logo.contentMode = UIViewContentModeScaleAspectFit;
    logo.tintColor = window.tintColor;
    [logo.heightAnchor constraintEqualToConstant:72].active = YES;
    UILabel *name = [UILabel new];
    name.text = @"WQ Files";
    name.font = [UIFont preferredFontForTextStyle:UIFontTextStyleLargeTitle];
    name.textColor = UIColor.labelColor;
    name.textAlignment = NSTextAlignmentCenter;
    UILabel *edition = [UILabel new];
    edition.text = @"Aurora Edition";
    edition.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    edition.textColor = UIColor.secondaryLabelColor;
    edition.textAlignment = NSTextAlignmentCenter;
    UIStackView *brand = [[UIStackView alloc] initWithArrangedSubviews:@[logo, name, edition]];
    brand.axis = UILayoutConstraintAxisVertical;
    brand.spacing = 12;
    brand.translatesAutoresizingMaskIntoConstraints = NO;
    [splash addSubview:brand];
    [NSLayoutConstraint activateConstraints:@[
        [brand.centerXAnchor constraintEqualToAnchor:splash.centerXAnchor],
        [brand.centerYAnchor constraintEqualToAnchor:splash.centerYAnchor],
        [brand.leadingAnchor constraintGreaterThanOrEqualToAnchor:splash.safeAreaLayoutGuide.leadingAnchor constant:24],
        [brand.trailingAnchor constraintLessThanOrEqualToAnchor:splash.safeAreaLayoutGuide.trailingAnchor constant:-24],
    ]];
    [window addSubview:splash];
    BOOL reduce = UIAccessibilityIsReduceMotionEnabled();
    brand.alpha = 0;
    if (!reduce) brand.transform = CGAffineTransformMakeScale(0.96, 0.96);
    [UIView animateWithDuration:reduce ? 0 : 0.18 animations:^{
        brand.alpha = 1;
        brand.transform = CGAffineTransformIdentity;
    } completion:^(BOOL __unused finished) {
        [UIView animateWithDuration:reduce ? 0 : 0.30 delay:reduce ? 0 : 0.15
            options:UIViewAnimationOptionBeginFromCurrentState animations:^{ splash.alpha = 0; }
            completion:^(BOOL __unused done) { [splash removeFromSuperview]; }];
    }];
}

UIButton *wq_aurora_update_button(UIViewController *host, NSDictionary<NSString *, NSString *> *release, void (^dismiss)(void))
{
    UIButtonConfiguration *config = [UIButtonConfiguration tintedButtonConfiguration];
    config.title = WQLocalizedFormat(@"Original developer update: %@", release[@"version"]);
    config.subtitle = WQLocalized(@"Not an Aurora Edition update.");
    config.image = [UIImage systemImageNamed:@"arrow.up.forward.app"];
    config.imagePadding = 10;
    config.contentInsets = NSDirectionalEdgeInsetsMake(14, 16, 14, 16);
    config.cornerStyle = UIButtonConfigurationCornerStyleLarge;
    __weak UIViewController *weakHost = host;
    return [UIButton buttonWithConfiguration:config primaryAction:[UIAction actionWithHandler:^(UIAction *__unused action) {
        UIViewController *owner = weakHost;
        if (!owner || owner.presentedViewController || !owner.view.window) return;
        NSString *notes = [release[@"notes"] isKindOfClass:NSString.class] ? release[@"notes"] : @"";
        NSString *message = [NSString stringWithFormat:@"%@\n\n%@", WQLocalized(@"Not an Aurora Edition update."),
            notes.length ? notes : WQLocalized(@"No release notes available.")];
        NSURL *downloadURL = wq_update_official_download_url(release);
        if (downloadURL) message = [message stringByAppendingFormat:@"\n\n%@",
            WQLocalized(@"This IPA is the original developer's release and does not include Aurora changes. Download and share it with a signing app?")];
        UIAlertController *alert = wq_alert_controller(WQVerbatim(WQLocalizedFormat(@"Original developer update: %@", release[@"version"])),
            WQVerbatim(message), UIAlertControllerStyleAlert);
        if (downloadURL) [alert addAction:wq_alert_action(@"Download IPA", UIAlertActionStyleDefault, ^(UIAlertAction *__unused a) {
            WQReleaseDownloadController *download = [[WQReleaseDownloadController alloc] initWithRelease:release];
            UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:download];
            [owner dismissViewControllerAnimated:YES completion:^{
                if (owner.view.window && !owner.presentedViewController)
                    [owner presentViewController:navigation animated:YES completion:nil];
            }];
        })];
        [alert addAction:wq_alert_action(@"View official release", UIAlertActionStyleDefault, ^(UIAlertAction *__unused a) {
            // Always open the original developer's official page. No automatic install.
            [UIApplication.sharedApplication openURL:[NSURL URLWithString:@"https://github.com/kolbicz/WQFiles/releases/latest"] options:@{} completionHandler:nil];
        })];
        [alert addAction:wq_alert_action(@"Do not remind me about this version", UIAlertActionStyleDefault, ^(UIAlertAction *__unused a) {
            wq_update_dismiss(release);
            dismiss();
        })];
        [alert addAction:wq_alert_action(@"Later", UIAlertActionStyleCancel, nil)];
        [owner presentViewController:alert animated:YES completion:nil];
    }]];
}

@implementation WQAuroraPreferencesController
- (instancetype)init
{
    if ((self = [super initWithStyle:UITableViewStyleInsetGrouped])) self.title = @"Aurora Edition";
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    wq_prism_install_background(self);
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 64;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *__unused)tableView { return 5; }
- (NSInteger)tableView:(UITableView *__unused)tableView numberOfRowsInSection:(NSInteger)section
{
    return section == 0 ? 2 : section == 1 ? (NSInteger)wq_aurora_icon_choices().count : 2;
}
- (NSString *)tableView:(UITableView *__unused)tableView titleForHeaderInSection:(NSInteger)section
{
    return WQLocalized(@[@"Appearance", @"App Icon", @"Aurora Edition Design & UI Redesign", @"Original project", @"Recent Files"][section]);
}
- (NSString *)tableView:(UITableView *__unused)tableView titleForFooterInSection:(NSInteger)section
{
    if (section == 4) return WQLocalized(@"Recent files stay on this device. Turn this off to clear the list.");
    return section == 2 ? WQLocalized(@"Designed by @abdulmajeedG. Original application by kolbicz; worse_query by Taj C (forcequit). GPL-3.0-or-later.") : nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"aurora"]
        ?: [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"aurora"];
    UIListContentConfiguration *c = [UIListContentConfiguration subtitleCellConfiguration];
    if (wq_prism_enabled()) {
        c.textProperties.color = wq_neon_textPrimary();
        c.secondaryTextProperties.color = wq_neon_textSecondary();
        c.imageProperties.tintColor = wq_neon_cyan();
    }
    c.textProperties.numberOfLines = 0;
    c.secondaryTextProperties.numberOfLines = 0;
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.accessoryView = nil;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (indexPath.section == 4) {
        c.text = WQLocalized(indexPath.row == 0 ? @"Remember Recent Files" : @"Clear Recent Files");
        c.image = [UIImage systemImageNamed:indexPath.row == 0 ? @"clock" : @"clock.badge.xmark"];
        if (indexPath.row == 0) {
            UISwitch *toggle = [UISwitch new];
            toggle.on = WQRecentStore.shared.enabled;
            [toggle addAction:[UIAction actionWithHandler:^(UIAction *action) {
                WQRecentStore.shared.enabled = ((UISwitch *)action.sender).on;
            }] forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = toggle;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
        }
        cell.contentConfiguration = c;
        cell.backgroundColor = wq_aurora_surface();
        return cell;
    }
    if (indexPath.section == 1) {
        // App icon: system-supported alternate icons, applied immediately.
        NSDictionary *choice = wq_aurora_icon_choices()[(NSUInteger)indexPath.row];
        c.text = WQLocalized(choice[@"title"]);
        NSString *stem = choice[@"stem"];
        c.image = [UIImage imageNamed:[stem stringByAppendingString:@"120"]] ?: [UIImage imageNamed:stem];
        c.imageProperties.maximumSize = CGSizeMake(44, 44);
        c.imageProperties.cornerRadius = 10;
        NSString *current = UIApplication.sharedApplication.alternateIconName;
        BOOL primary = [choice[@"name"] isKindOfClass:NSNull.class];
        if ((primary && !current) || (!primary && [choice[@"name"] isEqual:current]))
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        cell.contentConfiguration = c;
        cell.backgroundColor = wq_aurora_surface();
        return cell;
    }
    if (indexPath.section == 0) {
        c.text = WQLocalized(@[@"Blue", @"Red"][indexPath.row]);
        c.image = [UIImage systemImageNamed:@"circle.fill"
            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightRegular]];
        c.imageProperties.tintColor = indexPath.row == 0
            ? [UIColor colorWithRed:0.224 green:0.529 blue:0.961 alpha:1]
            : [UIColor colorWithRed:0.898 green:0.282 blue:0.302 alpha:1];
        if (indexPath.row == wq_aurora_appearance()) cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        c.text = indexPath.section == 2 ? @[@"Telegram: @abdulmajeedG", @"GitHub: @abdulmajeedG"][indexPath.row]
            : indexPath.row == 0 ? @"kolbicz / WQFiles" : @"GPL-3.0-or-later";
        c.image = [UIImage systemImageNamed:indexPath.section == 2 ? @"person.crop.circle" : @"doc.text"];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.contentConfiguration = c;
    cell.backgroundColor = wq_aurora_surface();
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 4) {
        if (indexPath.row == 1) [WQRecentStore.shared clear];
        return;
    }
    if (indexPath.section == 1) {
        NSDictionary *choice = wq_aurora_icon_choices()[(NSUInteger)indexPath.row];
        id name = choice[@"name"];
        NSString *iconName = [name isKindOfClass:NSNull.class] ? nil : name;
        __weak typeof(self) weakSelf = self;
        [UIApplication.sharedApplication setAlternateIconName:iconName completionHandler:^(NSError *error) {
            WQAuroraPreferencesController *strongSelf = weakSelf;
            if (!strongSelf) return;
            dispatch_async(dispatch_get_main_queue(), ^{
                if (error) wq_alert(strongSelf, WQLocalized(@"App Icon"), error.localizedDescription);
                [strongSelf.tableView reloadData];
            });
        }];
        return;
    }
    if (indexPath.section == 0) {
        wq_aurora_set_appearance((WQAuroraAppearance)indexPath.row);
        [tableView reloadData];
        // Rebuild the open screens so the new accent applies everywhere.
        [NSNotificationCenter.defaultCenter postNotificationName:@"WQAuroraThemeChanged" object:nil];
        return;
    }
    NSString *url = indexPath.section == 2 ? @[@"https://t.me/abdulmajeedG", @"https://github.com/abdulmajeedG"][indexPath.row]
        : indexPath.row == 0 ? @"https://github.com/kolbicz/WQFiles" : @"https://github.com/kolbicz/WQFiles/blob/main/LICENSE";
    [UIApplication.sharedApplication openURL:[NSURL URLWithString:url] options:@{} completionHandler:nil];
}
@end
