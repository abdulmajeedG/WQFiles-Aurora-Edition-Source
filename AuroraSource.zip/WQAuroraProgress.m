// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
#import "WQAurora.h"
#import <math.h>

@implementation WQAuroraProgressView {
    CAShapeLayer *_track;
    CAShapeLayer *_stroke;
    CAShapeLayer *_orbit;
    CAGradientLayer *_gradient;
    BOOL _applicationInactive;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame])) {
        self.userInteractionEnabled = NO;
        self.isAccessibilityElement = YES;
        _track = [CAShapeLayer layer];
        _stroke = [CAShapeLayer layer];
        _orbit = [CAShapeLayer layer];
        for (CAShapeLayer *shape in @[_track, _stroke, _orbit]) {
            shape.fillColor = UIColor.clearColor.CGColor;
            shape.lineCap = kCALineCapRound;
        }
        _gradient = [CAGradientLayer layer];
        _gradient.startPoint = CGPointMake(0, 0);
        _gradient.endPoint = CGPointMake(1, 1);
        _gradient.mask = _stroke;
        [self.layer addSublayer:_track];
        [self.layer addSublayer:_gradient];
        [self.layer addSublayer:_orbit];
        _titleLabel = [UILabel new];
        _titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleTitle1];
        _titleLabel.adjustsFontForContentSizeCategory = YES;
        _titleLabel.adjustsFontSizeToFitWidth = YES;
        _titleLabel.minimumScaleFactor = 0.7;
        _titleLabel.textColor = UIColor.labelColor;
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _detailLabel = [UILabel new];
        _detailLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
        _detailLabel.adjustsFontForContentSizeCategory = YES;
        _detailLabel.numberOfLines = 2;
        _detailLabel.textColor = UIColor.secondaryLabelColor;
        _detailLabel.textAlignment = NSTextAlignmentCenter;
        UIStackView *labels = [[UIStackView alloc] initWithArrangedSubviews:@[_titleLabel, _detailLabel]];
        labels.axis = UILayoutConstraintAxisVertical;
        labels.spacing = 5;
        labels.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:labels];
        [NSLayoutConstraint activateConstraints:@[
            [labels.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [labels.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:20],
            [labels.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-20],
        ]];
        [self registerForTraitChanges:@[UITraitUserInterfaceStyle.class, UITraitAccessibilityContrast.class]
            withAction:@selector(updateColors)];
        NSNotificationCenter *nc = NSNotificationCenter.defaultCenter;
        [nc addObserver:self selector:@selector(updateAnimation) name:UIAccessibilityReduceMotionStatusDidChangeNotification object:nil];
        [nc addObserver:self selector:@selector(becameActive) name:UIApplicationDidBecomeActiveNotification object:nil];
        [nc addObserver:self selector:@selector(resignedActive) name:UIApplicationWillResignActiveNotification object:nil];
        [self updateColors];
    }
    return self;
}
- (void)updateColors
{
    UITraitCollection *traits = self.traitCollection;
    _track.strokeColor = [UIColor.tertiarySystemFillColor resolvedColorWithTraitCollection:traits].CGColor;
    UIColor *blue = [UIColor.systemBlueColor resolvedColorWithTraitCollection:traits];
    UIColor *teal = [UIColor.systemTealColor resolvedColorWithTraitCollection:traits];
    UIColor *violet = [UIColor.systemIndigoColor resolvedColorWithTraitCollection:traits];
    _gradient.colors = @[(id)teal.CGColor, (id)blue.CGColor, (id)violet.CGColor];
    _stroke.strokeColor = UIColor.whiteColor.CGColor;
    _orbit.strokeColor = teal.CGColor;
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    // Layers have local coordinates, so rotating the orbit keeps its center fixed.
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    _track.frame = self.bounds;
    _gradient.frame = self.bounds;
    _stroke.frame = _gradient.bounds;
    _orbit.bounds = self.bounds;
    _orbit.position = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
    CGFloat side = MIN(self.bounds.size.width, self.bounds.size.height);
    CGFloat width = side < 80 ? 3 : 7;
    CGPoint center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
    CGFloat radius = MAX(0, side / 2 - width - 7);
    UIBezierPath *circle = [UIBezierPath bezierPathWithArcCenter:center radius:radius
        startAngle:-M_PI_2 endAngle:3 * M_PI_2 clockwise:YES];
    _track.path = circle.CGPath;
    _stroke.path = circle.CGPath;
    _track.lineWidth = width;
    _stroke.lineWidth = width;
    _orbit.path = [UIBezierPath bezierPathWithArcCenter:center radius:radius + width + 3
        startAngle:-M_PI_2 endAngle:3 * M_PI_2 clockwise:YES].CGPath;
    _orbit.lineWidth = side < 80 ? 1.5 : 2;
    _orbit.strokeStart = 0;
    _orbit.strokeEnd = 0.16;
    [CATransaction commit];
}
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated
{
    CGFloat value = isfinite(progress) ? MIN(1, MAX(0, progress)) : 0;
    CGFloat from = ((CAShapeLayer *)_stroke.presentationLayer).strokeEnd;
    if (!_stroke.presentationLayer) from = _stroke.strokeEnd;
    _progress = value;
    CGFloat end = _indeterminate ? 0.22 : value;
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    _stroke.strokeEnd = end;
    [CATransaction commit];
    if (animated && self.window && !_indeterminate && !UIAccessibilityIsReduceMotionEnabled()) {
        CABasicAnimation *change = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        change.fromValue = @(from);
        change.toValue = @(end);
        change.duration = 0.22;
        [_stroke addAnimation:change forKey:@"aurora.progress"];
    } else [_stroke removeAnimationForKey:@"aurora.progress"];
}
- (void)setIndeterminate:(BOOL)indeterminate
{
    if (_indeterminate == indeterminate) return;
    _indeterminate = indeterminate;
    [self setProgress:_progress animated:NO];
    [self updateAnimation];
}
- (void)setRunning:(BOOL)running { _running = running; [self updateAnimation]; }
- (void)didMoveToWindow { [super didMoveToWindow]; [self updateAnimation]; }
- (void)becameActive { _applicationInactive = NO; [self updateAnimation]; }
- (void)resignedActive { _applicationInactive = YES; [self updateAnimation]; }
- (void)updateAnimation
{
    BOOL active = _running && self.window && !_applicationInactive
        && UIApplication.sharedApplication.applicationState == UIApplicationStateActive;
    BOOL animate = active && !UIAccessibilityIsReduceMotionEnabled();
    _orbit.hidden = !_running;
    if (animate) {
        if (![_orbit animationForKey:@"aurora.orbit"]) {
            CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
            rotation.fromValue = @0;
            rotation.toValue = @(2 * M_PI);
            rotation.duration = 1.5;
            rotation.repeatCount = HUGE_VALF;
            [_orbit addAnimation:rotation forKey:@"aurora.orbit"];
        }
    } else [_orbit removeAnimationForKey:@"aurora.orbit"];
    if (animate && _indeterminate) {
        if (![_gradient animationForKey:@"aurora.scan"]) {
            CABasicAnimation *rotation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
            rotation.fromValue = @0;
            rotation.toValue = @(2 * M_PI);
            rotation.duration = 2.1;
            rotation.repeatCount = HUGE_VALF;
            [_gradient addAnimation:rotation forKey:@"aurora.scan"];
        }
    } else [_gradient removeAnimationForKey:@"aurora.scan"];
}
- (NSString *)accessibilityValue
{
    NSMutableArray *parts = [NSMutableArray new];
    if (_titleLabel.text.length) [parts addObject:_titleLabel.text];
    if (_detailLabel.text.length) [parts addObject:_detailLabel.text];
    if (!_indeterminate) [parts addObject:[NSNumberFormatter localizedStringFromNumber:@(_progress) numberStyle:NSNumberFormatterPercentStyle]];
    return [parts componentsJoinedByString:@", "];
}
@end
