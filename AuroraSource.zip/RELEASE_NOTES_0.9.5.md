> **Requires:** iOS 27, or iOS 26.0 – 26.7.2. Tested on iOS 27.0.1, 27.2.1 and 26.7.1; iOS 27.3 beta support is based on a user's Log.
> **Needs:** a sideloading tool that keeps the App Group entitlement; see [Signing](https://github.com/kolbicz/WQFiles#signing-the-app-group) in the README.

# Worse Query Files 0.9.5

## New

- **iOS 27.3 beta** ([#50](https://github.com/kolbicz/WQFiles/issues/50)): WQ Files reads the app database of iOS 27.3, where app extensions are stored differently. Before, most folders on 27.3 stayed unidentified, and the Cache Cleaner couldn't clean them.
- **Turkish**, and a **flag next to each language** under **Language** in WQ Files' Settings.
- **Import several files at once with Replace All** ([#49](https://github.com/kolbicz/WQFiles/issues/49)): when some names already exist, WQ Files asks once: **Replace All** (each replaced file is backed up first) or **Keep Both**.
- **Rename in Select** ([#41](https://github.com/kolbicz/WQFiles/issues/41)): with one item selected, **Rename** is in the toolbar.
- **Restore edited app backups:** a backup whose files were swapped afterwards, for example with files from another backup tool, used to be refused. WQ Files now says which parts changed and offers **Restore Anyway**. The app's current data is still backed up first.

## Changed

- **Deleting folders:** the alert now says how many files are backed up and how many links or special files are removed without a backup, instead of promising a copy of everything.
- **Recently Deleted:** shows when Backups can't be read instead of "Nothing deleted". A failed restore removes the empty folders it created.
- **Share as ZIP:** asks before sharing when items couldn't be read and were left out. The container's own system file doesn't count.
- **SQLite:**
  - **Saving** keeps one complete backup of the previous database, including changes that were still only in the `-wal` file.
  - **Text** that can't be shown exactly (invalid UTF-8, embedded NUL) is shown as hex and can't be edited as text by accident.
  - **CSV export** escapes column names, writes exact values and never shares a failed export.
  - **SQL statements** run in the background and can be cancelled.
- **Plist editor:** dates keep fractions of a second in binary plists, and 64-bit numbers are kept exactly instead of being clamped.
- **Hex editor:** search can be stopped and no longer blocks loading or saving. Oversized byte input is rejected at once.
- **Media:** each player gets its own temporary copy, so two open players no longer disturb each other. Streaming reads one consistent version of the file. `.m3u8` playlists open as text.
- **ZIP import and extraction** build the result in a hidden folder and only show it once it's complete. Very large or malformed archives are refused.
- **App backup import** asks when the backup names a different app than its contents.
- **Startup check:** a failure is shown once you're back on the start screen, instead of covering whatever is open.

## Fixed

- **Deleting a folder:** if the folder was replaced while it was being deleted, the replacement could be deleted instead. WQ Files now stops. Rename, move and Move Here also check that the item is still the one you selected.
- **ZIP files with a comment** could extract as empty.
- **App backups** of apps with sockets or pipes failed their check.
- **Recently Deleted** could show an older copy when more than nine backups were made in the same second.
- **Reset Access Cache** couldn't repair a damaged lock file.
- **Cache Cleaner:** pulling to refresh while cleaning could hide **Stop**.
- **Refresh** could show the result of the scan from before the refresh.
- **Translations:** "Date" and "Data" were the same word in the plist editor in Italian, Polish and Portuguese. App names that match a menu word (like "Files") are no longer translated.

## Credit

Sandbox technique: [worse_query](https://github.com/forcequitOS/worse_query) by Taj C (forcequit). Container enumeration: [KAMUI](https://github.com/murk-sus/kamui-escape) by murk-sus. Translations: iosrxwy (Simplified Chinese), hfip (Arabic), hooray804 (Korean), Reinascape (Russian). Thanks to xuhao2004 for the iOS 27.3 Log and to everyone who sent Logs and ideas. GPL-3.0-or-later.

SHA-256 of WQFiles.ipa: `f0e41b3e300032f0b25a72efdc63954032606812600e610a82f68c53a4ef7587`
