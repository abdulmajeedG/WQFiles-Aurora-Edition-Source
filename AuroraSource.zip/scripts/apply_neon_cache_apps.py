#!/usr/bin/env python3
"""Neon colors for the Cache Cleaner and Apps screens."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

cache = ROOT / "WQCache.m"
text = cache.read_text(encoding="utf-8")
text = text.replace(
    """        _detailLabel = [UILabel new];
        _detailLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        _detailLabel.textColor = UIColor.secondaryLabelColor;""",
    """        _detailLabel = [UILabel new];
        _detailLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        _detailLabel.textColor = wq_neon_textSecondary();""")
text = text.replace(
    """        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        _nameLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;""",
    """        _nameLabel = [UILabel new];
        _nameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
        _nameLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        _nameLabel.textColor = wq_neon_textPrimary();""")
text = text.replace(
    """        _sizeLabel = [UILabel new];
        _sizeLabel.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightSemibold];""",
    """        _sizeLabel = [UILabel new];
        _sizeLabel.font = [UIFont monospacedDigitSystemFontOfSize:15 weight:UIFontWeightSemibold];
        _sizeLabel.textColor = wq_neon_textPrimary();""")
text = text.replace(
    """        _statusLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        _statusLabel.textColor = UIColor.secondaryLabelColor;""",
    """        _statusLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
        _statusLabel.textColor = wq_neon_textSecondary();""")
cache.write_text(text, encoding="utf-8")
print("WQCache.m neon colors:", text.count("wq_neon_text"))

apps = ROOT / "WQApps.m"
text = apps.read_text(encoding="utf-8")
old = """    c.secondaryTextProperties.color = UIColor.secondaryLabelColor;
    c.image = wq_app_icon(app.bundleID) ?: [UIImage systemImageNamed:@"app.dashed"];"""
new = """    c.secondaryTextProperties.color = wq_prism_enabled() ? wq_neon_textSecondary() : UIColor.secondaryLabelColor;
    if (wq_prism_enabled()) {
        c.textProperties.color = wq_neon_textPrimary();
        cell.backgroundColor = wq_neon_surface();
    }
    c.image = wq_app_icon(app.bundleID) ?: [UIImage systemImageNamed:@"app.dashed"];"""
if old in text:
    text = text.replace(old, new)
    print("WQApps.m cell themed")
else:
    print("WQApps.m pattern not found")
apps.write_text(text, encoding="utf-8")
