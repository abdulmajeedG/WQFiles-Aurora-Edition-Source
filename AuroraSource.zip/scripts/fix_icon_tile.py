#!/usr/bin/env python3
"""Remove the duplicated icon tile and keep one clean implementation."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

DUP_MARK = "// Modern Dark icon tile: raised neutral square, single accent glyph.\n@implementation WQPrismIconTile"
start = text.index(DUP_MARK)
after = text.index("\n@end", start) + len("\n@end\n\n")
text = text[:start] + text[after:]

# Replace the remaining (old gradient) implementation with the clean one.
start = text.index("@implementation WQPrismIconTile {")
end = text.index("\n@end", start) + len("\n@end")
clean = r'''@implementation WQPrismIconTile {
    UIImageView *_imageView;
}

- (instancetype)initWithSymbol:(NSString *)symbol tone:(NSString *)tone size:(CGFloat)size
{
    if ((self = [super initWithFrame:CGRectZero])) {
        (void)tone;
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.userInteractionEnabled = NO;
        self.layer.cornerRadius = size * 0.28;
        self.layer.cornerCurve = kCACornerCurveContinuous;
        self.clipsToBounds = YES;
        self.backgroundColor = wq_neon_surfaceRaised();
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = wq_neon_border().CGColor;
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:size * 0.44
                                                                                         weight:UIImageSymbolWeightSemibold];
        _imageView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbol withConfiguration:cfg]];
        _imageView.translatesAutoresizingMaskIntoConstraints = NO;
        _imageView.tintColor = wq_neon_blue();
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:_imageView];
        [NSLayoutConstraint activateConstraints:@[
            [self.widthAnchor constraintEqualToConstant:size],
            [self.heightAnchor constraintEqualToConstant:size],
            [_imageView.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
            [_imageView.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [_imageView.widthAnchor constraintEqualToConstant:size * 0.58],
            [_imageView.heightAnchor constraintEqualToConstant:size * 0.58],
        ]];
    }
    return self;
}

@end'''
text = text[:start] + clean + text[end:]
path.write_text(text, encoding="utf-8")
print("icon tile deduplicated; WQPrismTone references left:", text.count("WQPrismTone("))
