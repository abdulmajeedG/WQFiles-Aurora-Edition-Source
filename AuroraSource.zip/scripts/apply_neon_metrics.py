#!/usr/bin/env python3
"""Rewrite refreshMetrics for the Neon storage card and add openBackups."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

START = "- (void)refreshMetrics"
END = "- (void)rebuildRecent"
start = text.index(START)
end = text.index(END, start)

new = r'''- (void)refreshMetrics
{
    _favoritesValue.text = [NSNumberFormatter localizedStringFromNumber:@(wq_favorites().count)
        numberStyle:NSNumberFormatterDecimalStyle];
    id count = [NSUserDefaults.standardUserDefaults objectForKey:@"WQAuroraAppCount"];
    _appsValue.text = [count isKindOfClass:NSNumber.class]
        ? [NSNumberFormatter localizedStringFromNumber:count numberStyle:NSNumberFormatterDecimalStyle] : @"—";
    if (_metricsPending) return;
    _metricsPending = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(wq_io(), ^{
        // Personal data inside this app, measured recursively (bounded).
        NSURL *documents = [NSURL fileURLWithPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] isDirectory:YES];
        NSFileManager *manager = NSFileManager.defaultManager;
        NSDirectoryEnumerator<NSURL *> *walker = [manager enumeratorAtURL:documents
            includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLIsSymbolicLinkKey, NSURLFileSizeKey]
            options:NSDirectoryEnumerationSkipsHiddenFiles errorHandler:nil];
        NSUInteger files = 0, seen = 0;
        unsigned long long bytes = 0;
        for (NSURL *url in walker) {
            if (++seen > 50000) break;
            NSDictionary *values = [url resourceValuesForKeys:@[NSURLIsSymbolicLinkKey, NSURLIsRegularFileKey, NSURLFileSizeKey] error:nil];
            if (![values[NSURLIsSymbolicLinkKey] isEqual:@YES] && [values[NSURLIsRegularFileKey] isEqual:@YES]) {
                files++;
                bytes += [values[NSURLFileSizeKey] unsignedLongLongValue];
            }
        }
        // Device capacity from the modern volume API; legacy keys as fallback.
        NSURL *volumeURL = [NSURL fileURLWithPath:@"/" isDirectory:YES];
        NSDictionary *volumeValues = [volumeURL resourceValuesForKeys:@[
            NSURLVolumeTotalCapacityKey, NSURLVolumeAvailableCapacityKey] error:nil];
        unsigned long long total = [volumeValues[NSURLVolumeTotalCapacityKey] unsignedLongLongValue];
        unsigned long long free = [volumeValues[NSURLVolumeAvailableCapacityKey] unsignedLongLongValue];
        if (!total || free > total) {
            NSDictionary *volume = [manager attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
            total = [volume[NSFileSystemSize] unsignedLongLongValue];
            free = [volume[NSFileSystemFreeSize] unsignedLongLongValue];
        }
        BOOL readable = walker != nil;
        (void)bytes;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) owner = weakSelf;
            if (!owner) return;
            owner->_metricsPending = NO;
            owner->_filesValue.text = readable
                ? [NSNumberFormatter localizedStringFromNumber:@(files) numberStyle:NSNumberFormatterDecimalStyle] : @"—";
            if (total && free <= total) {
                owner->_storageValue.text = wq_size_text(total - free);
                owner->_storageTotalLabel.text = [@"/ " stringByAppendingString:wq_size_text(total)];
                double fraction = (double)(total - free) / (double)total;
                fraction = MIN(1.0, MAX(0.02, fraction));
                if (owner->_storageFillConstraint) owner->_storageFillConstraint.active = NO;
                owner->_storageFillConstraint = [NSLayoutConstraint constraintWithItem:owner->_storageFill
                    attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual
                    toItem:owner->_storageTrack attribute:NSLayoutAttributeWidth multiplier:fraction constant:0];
                owner->_storageFillConstraint.active = YES;
            } else {
                owner->_storageValue.text = @"—";
                owner->_storageTotalLabel.text = @"";
            }
        });
    });
}

'''

text = text[:start] + new + text[end:]
# Add the Backups action next to the other tool actions.
anchor = "- (void)openCleaner { [self openTab:2]; }"
if "openBackups" not in text:
    text = text.replace(anchor, anchor + "\n- (void)openBackups { [self openTab:3]; }")
path.write_text(text, encoding="utf-8")
print("refreshMetrics rewritten; openBackups added.")
