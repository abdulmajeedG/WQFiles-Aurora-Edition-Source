#!/usr/bin/env python3
"""Generate the four Modern Dark app icons: Cleaning, Files, Storage, Apps.

Each icon is a clean white glyph with a single blue accent on the modern dark
background (#0D1117 → #111823). Pure local PIL drawing.
"""
import shutil
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
ICONS = ROOT / "icons"
SRC = ICONS / "src"
SRC.mkdir(parents=True, exist_ok=True)
S = 1024

BG_TOP = (13, 17, 23)        # #0D1117
BG_BOTTOM = (17, 24, 35)     # #111823
WHITE = (245, 247, 250)
BLUE = (57, 135, 245)        # #3987F5
LIGHT_BLUE = (101, 166, 255)


def vgrad(size, top, bottom):
    img = Image.new("RGB", size)
    d = ImageDraw.Draw(img)
    for y in range(size[1]):
        t = y / max(1, size[1] - 1)
        d.line([(0, y), (size[0], y)], fill=tuple(int(a + (b - a) * t) for a, b in zip(top, bottom)))
    return img


def base():
    img = vgrad((S, S), BG_TOP, BG_BOTTOM)
    # Soft accent wash at the top, like the app's own ambient glow.
    overlay = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    for i in range(40, 0, -1):
        r = 520 * i / 40
        d.ellipse([512 - r, -220 - r, 512 + r, -220 + r],
                  fill=BLUE + (max(0, int(26 * (1 - i / 40))),))
    img = Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")
    return img, ImageDraw.Draw(img)


def cleaning(draw):
    # Sparkle broom: tilted handle, bristle block, three sparkles.
    draw.line([(430, 300), (640, 700)], fill=WHITE, width=46)
    draw.rounded_rectangle([560, 660, 760, 800], radius=34, fill=WHITE)
    for x in range(590, 760, 34):
        draw.line([(x, 800), (x - 12, 880)], fill=WHITE, width=14)
    for cx, cy, r in ((330, 260, 22), (760, 330, 16), (300, 470, 13)):
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], fill=LIGHT_BLUE)


def files(draw):
    # Folder with a document sheet peeking out.
    draw.rounded_rectangle([390, 280, 640, 640], radius=30, fill=WHITE)
    for i in range(3):
        y = 360 + i * 66
        draw.rounded_rectangle([430, y, 600, y + 14], radius=7, fill=(176, 190, 214))
    draw.rounded_rectangle([250, 450, 510, 560], radius=26, fill=WHITE)
    draw.rounded_rectangle([236, 520, 788, 812], radius=50, fill=WHITE)
    draw.rounded_rectangle([236, 520, 788, 556], radius=18, fill=BLUE)


def storage(draw):
    # Rounded drive with a gauge arc and needle.
    draw.rounded_rectangle([250, 360, 774, 740], radius=64, fill=WHITE)
    draw.rounded_rectangle([250, 560, 774, 740], radius=64, fill=(214, 224, 240))
    draw.arc([330, 380, 700, 660], start=200, end=340, fill=BLUE, width=30)
    draw.line([(515, 520), (620, 430)], fill=BLUE, width=24)
    draw.ellipse([488, 493, 542, 547], fill=BLUE)
    draw.line([(300, 690), (724, 690)], fill=(160, 176, 200), width=16)


def apps(draw):
    # 2 × 2 rounded grid with one accented tile.
    size, gap, left, top = 210, 34, 272, 272
    for row in range(2):
        for col in range(2):
            x = left + col * (size + gap)
            y = top + row * (size + gap)
            fill = BLUE if (row, col) == (0, 1) else WHITE
            draw.rounded_rectangle([x, y, x + size, y + size], radius=54, fill=fill)


DESIGNS = {
    "cleaning": cleaning,
    "files": files,
    "storage": storage,
    "apps": apps,
}


def render(kind):
    img, draw = base()
    DESIGNS[kind](draw)
    return img


def save(img, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)
    print("wrote", path.name, img.size)


def main():
    for name in ("AppIcon1024.png", "AppIcon1024-dark.png", "AppIcon1024-tinted.png"):
        source = ICONS / name
        if source.exists() and not (SRC / name).exists():
            shutil.copy2(source, SRC / name)
    primary = render("cleaning")
    save(primary, ICONS / "AppIcon1024.png")
    save(render("cleaning"), ICONS / "AppIcon1024-dark.png")
    tinted = Image.new("RGBA", (S, S), (0, 0, 0, 255))
    gray = primary.convert("L").point(lambda v: 0 if v < 40 else 255)
    tinted.putalpha(gray)
    save(tinted, ICONS / "AppIcon1024-tinted.png")
    alts = {"files": "AltFiles", "storage": "AltStorage", "apps": "AltApps"}
    for kind, stem in alts.items():
        image = render(kind)
        save(image.resize((120, 120), Image.LANCZOS), ICONS / f"{stem}120.png")
        save(image.resize((180, 180), Image.LANCZOS), ICONS / f"{stem}180.png")
    # Remove the previous Aurora art alternates so no stale icons remain.
    for stale in ("AltAuroraWave", "AltGlassPrism", "AltMountain"):
        for suffix in ("120.png", "180.png"):
            stale_path = ICONS / f"{stale}{suffix}"
            if stale_path.exists():
                stale_path.unlink()
                print("removed", stale_path.name)


if __name__ == "__main__":
    main()
