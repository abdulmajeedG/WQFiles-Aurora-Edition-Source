#!/usr/bin/env python3
"""Prepare a source-only private build bundle and a manual workflow, offline.

This avoids creating a PAT or granting an OAuth app access to other repositories:
the bundle and workflow can be uploaded through the owner's normal GitHub UI.
No upload or workflow dispatch is performed by this script.
"""
import hashlib
import json
import stat
import subprocess
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".work/private-build"
TEXT = {".m", ".h", ".py", ".sh", ".strings", ".plist", ".yml", ".yaml", ".json", ".md"}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    names = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
                           cwd=ROOT, check=True, capture_output=True).stdout.decode("utf-8").split("\0")
    archive = OUT / "AuroraSource.zip"
    total = 0
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for name in sorted(set(names)):
            if not name or name.startswith(("docs/design/", ".work/", ".git/")):
                continue
            path = ROOT / name
            if not path.is_file() or path.is_symlink():
                continue
            if path.suffix.lower() in {".ipa", ".p12", ".pfx", ".pem", ".key", ".cer", ".mobileprovision"}:
                raise SystemExit(f"Refusing credential/artifact file: {name}")
            data = path.read_bytes()
            if path.suffix in TEXT or path.name in {"LICENSE", ".gitignore", ".gitattributes"}:
                data = data.replace(b"\r\n", b"\n")
                data.decode("utf-8")
            info = zipfile.ZipInfo(name, (2026, 11, 15, 0, 0, 0))
            info.create_system = 3
            mode = 0o755 if path.suffix == ".sh" else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            output.writestr(info, data)
            total += len(data)
    if archive.stat().st_size > 4 * 1024 * 1024:
        raise SystemExit("Bundle exceeds conservative browser-transfer limit; no upload attempted.")
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    extract = f'''      - name: Verify and unpack the reviewed source bundle
        shell: bash
        working-directory: .
        run: |
          set -euo pipefail
          python3 - <<'PY'
          import hashlib, pathlib, stat, zipfile
          bundle = pathlib.Path('AuroraSource.zip')
          expected = '{digest}'
          if hashlib.sha256(bundle.read_bytes()).hexdigest() != expected:
              raise SystemExit('Source bundle SHA-256 mismatch; no build.')
          root = pathlib.Path('.work/aurora-source')
          root.mkdir(parents=True, exist_ok=False)
          with zipfile.ZipFile(bundle) as archive:
              entries = archive.infolist()
              if len(entries) > 500 or sum(x.file_size for x in entries) > 50 * 1024 * 1024:
                  raise SystemExit('Source bundle exceeds reviewed bounds.')
              for entry in entries:
                  path = pathlib.PurePosixPath(entry.filename)
                  kind = stat.S_IFMT(entry.external_attr >> 16)
                  if path.is_absolute() or '..' in path.parts or '\\\\' in entry.filename or ':' in entry.filename:
                      raise SystemExit('Unsafe source path.')
                  if kind not in (0, stat.S_IFREG):
                      raise SystemExit('Only regular source files are accepted.')
                  target = root.joinpath(*path.parts)
                  target.parent.mkdir(parents=True, exist_ok=True)
                  target.write_bytes(archive.read(entry))
                  target.chmod(0o755 if target.suffix == '.sh' else 0o644)
          print('Reviewed source bundle verified and unpacked.')
          PY
'''
    workflow = (ROOT / ".github/workflows/aurora-manual-build.yml").read_text(encoding="utf-8")
    workflow = workflow.replace("    env:\n", "    defaults:\n      run:\n        working-directory: .work/aurora-source\n    env:\n", 1)
    workflow = workflow.replace("      - name: Select a preinstalled stable Xcode", extract + "      - name: Select a preinstalled stable Xcode", 1)
    workflow = workflow.replace("            WQFiles.ipa\n", "            .work/aurora-source/WQFiles.ipa\n")
    workflow = workflow.replace("            WQFiles.ipa.sha256\n", "            .work/aurora-source/WQFiles.ipa.sha256\n")
    workflow = workflow.replace("            .work/tests/**/*.log\n", "            .work/aurora-source/.work/tests/**/*.log\n")
    (OUT / "aurora-private-build.yml").write_text(workflow, encoding="utf-8", newline="\n")
    (OUT / "README.md").write_text(
        "# WQ Files – Aurora Edition: private device-test build\n\n"
        "Private preparation only. No public release or upstream submission.\n\n"
        "`AuroraSource.zip` contains the reviewed Objective-C source, translations,\n"
        "tests, GPL-3.0-or-later license and build.sh. Promotional images are excluded.\n"
        f"SHA-256: `{digest}`\n\n"
        "The manually dispatched macOS workflow verifies this exact bundle, runs\n"
        "the original regression/build gates and retains a private IPA for one day.\n"
        "No successful build or device compatibility is claimed in advance.\n"
        "Re-signing with a valid App Group provisioning profile is required.\n\n"
        "Original application: kolbicz/WQFiles. GPL-3.0-or-later.\n"
        "Aurora design/UI credit: Telegram and GitHub @abdulmajeedG.\n",
        encoding="utf-8", newline="\n")
    (OUT / "LICENSE").write_bytes((ROOT / "LICENSE").read_bytes().replace(b"\r\n", b"\n"))
    with zipfile.ZipFile(archive) as check:
        assert check.testzip() is None
        assert {"LICENSE", "build.sh", "main.m", "entitlements.plist"}.issubset(check.namelist())
        count = len(check.infolist())
    report = {"archive": str(archive), "sha256": digest, "files": count,
              "source_bytes": total, "archive_bytes": archive.stat().st_size,
              "workflow_bytes": len(workflow.encode("utf-8")), "uploaded": False, "built": False}
    (OUT / "bundle-report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
