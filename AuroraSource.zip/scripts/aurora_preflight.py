#!/usr/bin/env python3
"""Offline portable preflight. NOT the full macOS runner or an iOS build.

Only test fixtures/source are inspected. No GitHub access, downloads, signing,
installed-app access or credential inspection is performed.
"""
import os
import plistlib
import re
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UPSTREAM_BASE = "dcd5c1811811fb8bb75a370f9e0080d0b856fb11"
PROTECTED = (
    "LICENSE", "entitlements.plist", "WQAccess.m", "WQAccessSafety.h", "WQCore.m",
    "WQArchive.m", "WQHealth.m", "WQAppsSupport.h", "WQCacheSafety.h",
    "WQSQLiteSave.m", "WQSQLiteSupport.h", "WQPlistEditorSupport.h", "WQHexViewerHelpers.h",
)


def run_portable_tests():
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    for pattern in ("test_aurora_contracts.py", "test_localization.py", "test_release_policy.py"):
        suite.addTests(loader.discover(str(ROOT / "tests"), pattern=pattern))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        raise SystemExit("Portable tests failed; no build/push authorized.")
    subprocess.run([sys.executable, "-X", "utf8", "tests/browser_ui_regressions.py"], cwd=ROOT, check=True)


def inspect_source_only():
    # Never print matching secret material. Even a suspicion fails closed.
    secret = re.compile(r"(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)")
    listing = subprocess.run(["git", "ls-files", "--cached", "--others", "--exclude-standard", "-z"],
                             cwd=ROOT, check=True, capture_output=True).stdout
    extensions = {".m", ".h", ".py", ".sh", ".strings", ".plist", ".yml", ".yaml", ".json", ".md"}
    suspicious = []
    count = 0
    for name in listing.decode("utf-8").split("\0"):
        if not name:
            continue
        path = ROOT / name
        if not path.is_file() or (path.suffix not in extensions and path.name not in (".gitignore", ".gitattributes", "LICENSE")):
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        count += 1
        if secret.search(text):
            suspicious.append(name)
    if suspicious:
        raise SystemExit("Possible credential material; STOP. File names only: " + ", ".join(suspicious))
    print(f"Credential-pattern source scan: no matches in {count} text files (not a comprehensive secret-scanner certification).")
    for name in PROTECTED:
        base = subprocess.run(["git", "show", f"{UPSTREAM_BASE}:{name}"], cwd=ROOT, check=True, capture_output=True).stdout
        if base.replace(b"\r\n", b"\n") != (ROOT / name).read_bytes().replace(b"\r\n", b"\n"):
            raise SystemExit(f"Protected upstream file changed: {name}")
    print(f"Protected safety/license files: {len(PROTECTED)} unchanged from upstream base.")
    info = plistlib.loads((ROOT / "Info.plist").read_bytes())
    entitlements = plistlib.loads((ROOT / "entitlements.plist").read_bytes())
    if info["MinimumOSVersion"] != "26.0" or info["WQUpstreamVersion"] != "0.9.10":
        raise SystemExit("Unexpected compatibility/upstream metadata.")
    if entitlements["com.apple.security.application-groups"] != ["group.cz.kolbi.wqfiles"]:
        raise SystemExit("Required App Group changed.")
    print("Metadata/App Group source checks: PASS (not a signed-artifact or device check).")


def main():
    os.chdir(ROOT)
    run_portable_tests()
    inspect_source_only()
    print("PORTABLE PREFLIGHT PASSED. macOS Foundation fixtures, UIKit compile/link, IPA build and device tests remain REQUIRED and UNRUN.")


if __name__ == "__main__":
    main()
