#!/usr/bin/env python3
"""QR for the existing authenticated private artifact; no public hosting/upload."""
import argparse
import json
from pathlib import Path
from urllib.parse import quote

import qrcode
from PIL import Image, ImageDraw, ImageFilter, ImageFont

URL = "https://github.com/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43756930594/artifacts/14178333595"
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/private-test1"


def font(size, bold=False):
    candidates = [Path("C:/Windows/Fonts") / ("segoeuib.ttf" if bold else "segoeui.ttf"),
                  Path("/usr/share/fonts/truetype/dejavu") / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")]
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sign-in", action="store_true", help="Open official GitHub login before the private run summary")
    args = parser.parse_args()
    target = URL
    suffix = ""
    if args.sign_in:
        target = "https://github.com/login?return_to=" + quote("/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43756930594", safe="")
        suffix = "-login"
    OUT.mkdir(parents=True, exist_ok=True)
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=12, border=4)
    qr.add_data(target)
    qr.make(fit=True)
    code = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    plain = OUT / f"Aurora-Private-Download-QR{suffix}-simple.png"
    code.save(plain)
    width, height = 1080, 1440
    card = Image.new("RGB", (width, height), "#080f25")
    draw = ImageDraw.Draw(card)
    for y in range(height):
        t = y / height
        draw.line((0, y, width, y), fill=(int(10 + 9 * t), int(17 + 8 * t), int(45 + 18 * t)))
    glow = Image.new("RGBA", card.size)
    g = ImageDraw.Draw(glow)
    g.ellipse((700, -200, 1200, 510), fill=(15, 210, 215, 65))
    g.ellipse((-300, 900, 420, 1700), fill=(95, 70, 245, 60))
    glow = glow.filter(ImageFilter.GaussianBlur(95))
    card = Image.alpha_composite(card.convert("RGBA"), glow).convert("RGB")
    draw = ImageDraw.Draw(card)
    draw.text((100, 82), "WQ Files", font=font(68, True), fill="#f4f8ff")
    draw.text((103, 171), "AURORA EDITION", font=font(32), fill="#7ce9e1")
    draw.text((103, 257), "Private iPhone Test Build  |  0.1.0", font=font(29), fill="#b7c8eb")
    draw.rounded_rectangle((100, 340, 980, 1180), radius=32, fill="white")
    x, y = (width - code.width) // 2, 390
    require = code.width <= 760
    if not require:
        raise SystemExit("QR exceeds the reviewed layout; no card produced.")
    card.paste(code, (x, y))
    draw = ImageDraw.Draw(card)
    title = "Sign in to download" if args.sign_in else "Scan to download"
    bounds = draw.textbbox((0, 0), title, font=font(34, True))
    draw.text(((width - bounds[2]) / 2, 1100), title, font=font(34, True), fill="#172748")
    draw.text((100, 1230), "GitHub sign-in required. Private repository.", font=font(27), fill="#ecf1ff")
    detail = "After sign-in: Artifacts > aurora-manual-build..." if args.sign_in else "ZIP contains the IPA. Link available for one day."
    draw.text((100, 1278), detail, font=font(25), fill="#a9bfdf")
    draw.text((100, 1325), "Re-sign with App Group support before installing.", font=font(25), fill="#a9bfdf")
    draw.text((100, 1380), "Design & UI: @abdulmajeedG", font=font(24), fill="#7ce9e1")
    poster = OUT / f"Aurora-Private-Download-QR{suffix}.png"
    card.save(poster)
    assert card.crop((x, y, x + code.width, y + code.height)).tobytes() == code.tobytes()
    decoded = False
    try:
        import cv2
        value, _, _ = cv2.QRCodeDetector().detectAndDecode(cv2.imread(str(plain)))
        if value != target:
            raise SystemExit("QR decoding did not match the private artifact URL.")
        decoded = True
    except ImportError:
        pass
    report = {"url": target, "private": True, "github_sign_in_required": True,
              "retention_days": 1, "plain_png": str(plain), "poster_png": str(poster),
              "decoded_verified": decoded, "poster_qr_pixels_match": True}
    (OUT / f"qr-report{suffix}.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
