#!/usr/bin/env python3
"""Storage metrics: legacy block values first (closest to Settings), chips."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

start = text.index("- (void)refreshMetrics")
end = text.index("- (void)rebuildRecent", start)

metrics = r'''- (void)refreshMetrics
{
    NSNumber *favoritesCount = @(wq_favorites().count);
    _favoritesValue.text = [NSNumberFormatter localizedStringFromNumber:favoritesCount
        numberStyle:NSNumberFormatterDecimalStyle];
    id count = [NSUserDefaults.standardUserDefaults objectForKey:@"WQAuroraAppCount"];
    NSString *appsText = [count isKindOfClass:NSNumber.class]
        ? [NSNumberFormatter localizedStringFromNumber:count numberStyle:NSNumberFormatterDecimalStyle] : @"—";
    _appsValue.text = appsText;
    if (_metricsPending) return;
    _metricsPending = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(wq_io(), ^{
        // Personal data inside this app, measured recursively (bounded).
        NSURL *documents = [NSURL fileURLWithPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] isDirectory:YES];
        NSFileManager *manager = NSFileManager.defaultManager;
        NSDirectoryEnumerator<NSURL *> *walker = [manager enumeratorAtURL:documents
            includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLIsSymbolicLinkKey, NSURLFileSizeKey]
            options:NSDirectoryEnumerationSkipsHiddenFiles errorHandler:nil];
        NSUInteger files = 0, seen = 0;
        for (NSURL *url in walker) {
            if (++seen > 50000) break;
            NSDictionary *values = [url resourceValuesForKeys:@[NSURLIsSymbolicLinkKey, NSURLIsRegularFileKey, NSURLFileSizeKey] error:nil];
            if (![values[NSURLIsSymbolicLinkKey] isEqual:@YES] && [values[NSURLIsRegularFileKey] isEqual:@YES]) files++;
        }
        // Storage figures: the legacy block values are what Settings reports
        // most closely; modern volume APIs are the fallback.
        NSDictionary *legacy = [manager attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
        unsigned long long total = [legacy[NSFileSystemSize] unsignedLongLongValue];
        unsigned long long free = [legacy[NSFileSystemFreeSize] unsignedLongLongValue];
        if (!total || free > total) {
            NSURL *volumeURL = [NSURL fileURLWithPath:@"/" isDirectory:YES];
            NSDictionary *volume = [volumeURL resourceValuesForKeys:@[
                NSURLVolumeTotalCapacityKey,
                NSURLVolumeAvailableCapacityKey,
                NSURLVolumeAvailableCapacityForImportantUsageKey] error:nil];
            total = [volume[NSURLVolumeTotalCapacityKey] unsignedLongLongValue];
            unsigned long long available = [volume[NSURLVolumeAvailableCapacityKey] unsignedLongLongValue];
            unsigned long long important = [volume[NSURLVolumeAvailableCapacityForImportantUsageKey] unsignedLongLongValue];
            free = (available && important) ? MIN(available, important) : (available ?: important);
        }
        BOOL readable = walker != nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) owner = weakSelf;
            if (!owner) return;
            owner->_metricsPending = NO;
            NSString *filesText = readable
                ? [NSNumberFormatter localizedStringFromNumber:@(files) numberStyle:NSNumberFormatterDecimalStyle] : @"—";
            owner->_filesValue.text = filesText;
            owner->_chipAppsValue.text = appsText;
            owner->_chipFilesValue.text = filesText;
            owner->_chipFavoritesValue.text = [NSNumberFormatter localizedStringFromNumber:favoritesCount
                numberStyle:NSNumberFormatterDecimalStyle];
            if (total && free <= total) {
                unsigned long long used = total - free;
                owner->_storageValue.text = wq_size_text(used);
                owner->_storageTotalLabel.text = [@"/ " stringByAppendingString:wq_size_text(total)];
                owner->_storageAvailableValue.text = wq_size_text(free);
                owner->_chipStorageValue.text = wq_size_text(used);
                [owner->_storageRing setFraction:(double)used / (double)total animated:YES];
            } else {
                owner->_storageValue.text = @"—";
                owner->_storageTotalLabel.text = @"";
                owner->_storageAvailableValue.text = @"—";
                owner->_chipStorageValue.text = @"—";
            }
        });
    });
}

'''
text = text[:start] + metrics + text[end:]
path.write_text(text, encoding="utf-8")
print("refreshMetrics rewritten for legacy-primary storage + chips")
