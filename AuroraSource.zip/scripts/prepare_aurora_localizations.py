#!/usr/bin/env python3
"""Generate localized resources, preserving every existing translation value.

One-time --legacy-dir imports only fr/ur tables from the user's earlier local
work, never code or credentials. Subsequent invocations need no legacy tree.
New resources remain machine-assisted drafts until native-speaker/device review.
"""
import argparse
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from test_localization import read_table, PLACEHOLDER, BIDI_CONTROLS  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy-dir", type=Path)
    args = parser.parse_args()
    spec = json.loads((ROOT / "scripts/aurora_strings.json").read_text(encoding="utf-8"))
    english = read_table(ROOT / "en.lproj/Localizable.strings")
    dashboard = json.loads((ROOT / "scripts/aurora_dashboard_strings.json").read_text(encoding="utf-8"))
    keys = spec["keys"] + spec["download_keys"] + dashboard["keys"]
    all_values = {"en": keys, **{language: values + spec["download_translations"][language] + dashboard["translations"][language]
                               for language, values in spec["translations"].items()}}
    # Validate EVERYTHING before writing any generated resource.
    outputs = {}
    for language, values in all_values.items():
        assert len(keys) == len(values), language
        path = ROOT / f"{language}.lproj/Localizable.strings"
        if path.exists():
            original = path.read_text(encoding="utf-8")
            table = read_table(path)
        else:
            if language not in ("fr", "ur") or not args.legacy_dir:
                raise SystemExit(f"Missing {path}; specify --legacy-dir for the initial migration")
            legacy = read_table(args.legacy_dir / f"{language}.lproj/Localizable.strings")
            translated = {**legacy, **spec["migration_fixes"][language]}
            table = {key: translated[key] for key in english if key not in keys}
            original = "/* Aurora migration: local translation draft; GPL-3.0-or-later. Native review pending. */\n"
            original += "\n".join(f"{json.dumps(k, ensure_ascii=False)} = {json.dumps(v, ensure_ascii=False)};" for k, v in table.items()) + "\n"
        additions = []
        for key, value in zip(keys, values):
            if key in table:
                # Preserve upstream/existing wording, never silently overwrite it.
                value = table[key]
            else:
                additions.append(f"{json.dumps(key, ensure_ascii=False)} = {json.dumps(value, ensure_ascii=False)};")
                table[key] = value
            assert PLACEHOLDER.findall(key) == PLACEHOLDER.findall(value), (language, key)
        assert set(table) == set(english) | set(keys), language
        for key, value in table.items():
            assert PLACEHOLDER.findall(key) == PLACEHOLDER.findall(value), (language, key)
            assert value.strip() or not key.strip(), (language, key)
        if additions:
            original = original.rstrip() + "\n\n/* Aurora Edition additions (2026-11-15); linguistic review pending. */\n" + "\n".join(additions) + "\n"
        outputs[path] = original
    # Derived draft languages (e.g. pt-PT from pt-BR, zh-Hant from zh-Hans):
    # the base table plus curated overrides and authored Aurora additions.
    # Machine-assisted drafts until a native speaker reviews them.
    def derive_value(value, spec_):
        for old, new in spec_.get("phrases") or ():
            value = value.replace(old, new)
        for old, new in (spec_.get("whole_strings") or {}).items():
            if value == old:
                value = new
        for old, new in spec_.get("words") or ():
            value = re.sub(rf"(?<![A-Za-zÀ-ÿ]){re.escape(old)}(?![A-Za-zÀ-ÿ])", new, value)
        chars = spec_.get("chars") or {}
        if chars:
            value = "".join(chars.get(c, c) for c in value)
        return value

    derived_spec = json.loads((ROOT / "scripts/aurora_derived_languages.json").read_text(encoding="utf-8"))
    for language, spec_ in derived_spec.items():
        if language == "comment" or not isinstance(spec_, dict):
            continue
        path = ROOT / f"{language}.lproj/Localizable.strings"
        existing = path.exists()
        if existing:
            # Idempotent regeneration: keep an existing reviewed table intact.
            table = read_table(path)
        else:
            base_table = read_table(ROOT / f"{spec_['base']}.lproj/Localizable.strings")
            table = {key: derive_value(value, spec_) for key, value in base_table.items()}
        additions = []
        for key in keys:
            value = spec_.get("additions", {}).get(key)
            if value is None:
                raise SystemExit(f"{language}: missing addition translation for {key!r}")
            if existing:
                if key not in table:
                    additions.append(f"{json.dumps(key, ensure_ascii=False)} = {json.dumps(value, ensure_ascii=False)};")
                    table[key] = value
            else:
                # Authored derived wording wins over the base language's copy.
                table[key] = value
            assert PLACEHOLDER.findall(key) == PLACEHOLDER.findall(value), (language, key)
        assert set(table) == set(english) | set(keys), language
        for key, value in table.items():
            assert PLACEHOLDER.findall(key) == PLACEHOLDER.findall(value), (language, key)
            assert value.strip() or not key.strip(), (language, key)
            assert not BIDI_CONTROLS.search(value), (language, key)
        if existing:
            original = path.read_text(encoding="utf-8")
            if additions:
                original = original.rstrip() + "\n\n/* Aurora Edition additions (2026-11-16); linguistic review pending. */\n" + "\n".join(additions) + "\n"
        else:
            original = (f"/* Aurora derived translation draft (2026-11-16); base {spec_['base']}. Native review pending. */\n"
                        + "\n".join(f"{json.dumps(key, ensure_ascii=False)} = {json.dumps(value, ensure_ascii=False)};" for key, value in table.items()) + "\n")
        outputs[path] = original
    for path, content in outputs.items():
        path.parent.mkdir(exist_ok=True)
        path.write_text(content, encoding="utf-8", newline="\n")
    print(f"Validated/generated {len(outputs)} tables, {len(set(english) | set(keys))} keys each.")


if __name__ == "__main__":
    main()
