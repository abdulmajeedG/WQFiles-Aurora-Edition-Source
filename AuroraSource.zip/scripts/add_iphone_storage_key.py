#!/usr/bin/env python3
"""Add the iPhone Storage shortcut label to every translation input."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KEY = "iPhone Storage"
TRANSLATIONS = {
    "en": "iPhone Storage",
    "ar": "تخزين iPhone",
    "de": "iPhone-Speicher",
    "es": "Almacenamiento del iPhone",
    "fr": "Stockage de l’iPhone",
    "it": "Spazio iPhone",
    "ko": "iPhone 저장 공간",
    "pl": "Pamięć iPhone’a",
    "pt-BR": "Armazenamento do iPhone",
    "ru": "Хранилище iPhone",
    "th": "พื้นที่เก็บข้อมูล iPhone",
    "tr": "iPhone Depolama",
    "ur": "iPhone اسٹوریج",
    "vi": "Dung lượng iPhone",
    "zh-Hans": "iPhone 存储空间",
}
DERIVED = {"pt-PT": "Armazenamento do iPhone", "zh-Hant": "iPhone 儲存空間"}


def main():
    spec_path = ROOT / "scripts/aurora_strings.json"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if KEY in spec["keys"]:
        print("'iPhone Storage' already present.")
        return
    spec["keys"].append(KEY)
    for language, value in TRANSLATIONS.items():
        if language == "en":
            continue
        spec["translations"][language].append(value)
    assert all(len(v) == len(spec["keys"]) for v in spec["translations"].values())
    spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

    derived_path = ROOT / "scripts/aurora_derived_languages.json"
    derived = json.loads(derived_path.read_text(encoding="utf-8"))
    for language, value in DERIVED.items():
        derived[language]["additions"][KEY] = value
    derived_path.write_text(json.dumps(derived, indent=2, ensure_ascii=False), encoding="utf-8")
    print("'iPhone Storage' added to 15 base and 2 derived languages.")


if __name__ == "__main__":
    main()
