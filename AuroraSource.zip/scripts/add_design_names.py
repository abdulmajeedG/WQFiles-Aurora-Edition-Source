#!/usr/bin/env python3
"""Add the two Modern Dark design names (Blue / Red) to the translations."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NEW_KEYS = ["Blue", "Red"]
TRANSLATIONS = {
    "en": ["Blue", "Red"],
    "ar": ["أزرق", "أحمر"],
    "de": ["Blau", "Rot"],
    "es": ["Azul", "Rojo"],
    "fr": ["Bleu", "Rouge"],
    "it": ["Blu", "Rosso"],
    "ko": ["블루", "레드"],
    "pl": ["Niebieski", "Czerwony"],
    "pt-BR": ["Azul", "Vermelho"],
    "ru": ["Синий", "Красный"],
    "th": ["น้ำเงิน", "แดง"],
    "tr": ["Mavi", "Kırmızı"],
    "ur": ["نیلا", "سرخ"],
    "vi": ["Xanh dương", "Đỏ"],
    "zh-Hans": ["蓝色", "红色"],
}
DERIVED = {"pt-PT": ["Azul", "Vermelho"], "zh-Hant": ["藍色", "紅色"]}


def main():
    spec_path = ROOT / "scripts/aurora_strings.json"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if "Blue" in spec["keys"]:
        print("Design-name keys already present.")
        return
    spec["keys"].extend(NEW_KEYS)
    for language, values in TRANSLATIONS.items():
        if language == "en":
            continue
        spec["translations"][language].extend(values)
    assert all(len(v) == len(spec["keys"]) for v in spec["translations"].values())
    spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

    derived_path = ROOT / "scripts/aurora_derived_languages.json"
    derived = json.loads(derived_path.read_text(encoding="utf-8"))
    for language, values in DERIVED.items():
        for key, value in zip(NEW_KEYS, values):
            derived[language]["additions"][key] = value
    derived_path.write_text(json.dumps(derived, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Blue/Red added to 15 base and 2 derived languages.")


if __name__ == "__main__":
    main()
