#!/usr/bin/env python3
"""Append the App Icon keys to every translation input, validating lengths."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

NEW_KEYS = ["App Icon", "Neon Folder", "Aurora Wave", "Glass Prism", "Mountain Moon"]

TRANSLATIONS = {
    "en": NEW_KEYS,
    "ar": ["أيقونة التطبيق", "مجلد النيون", "موجة أورورا", "منشور زجاجي", "الجبل والقمر"],
    "de": ["App-Symbol", "Neon-Ordner", "Aurora-Welle", "Glasprisma", "Berg und Mond"],
    "es": ["Icono de la app", "Carpeta neón", "Ola Aurora", "Prisma de cristal", "Montaña y luna"],
    "fr": ["Icône de l'app", "Dossier néon", "Vague Aurora", "Prisme de verre", "Montagne et lune"],
    "it": ["Icona dell'app", "Cartella al neon", "Onda Aurora", "Prisma di vetro", "Montagna e luna"],
    "ko": ["앱 아이콘", "네온 폴더", "오로라 웨이브", "유리 프리즘", "산과 달"],
    "pl": ["Ikona aplikacji", "Neonowy folder", "Fala Aurora", "Szklany pryzmat", "Góra i księżyc"],
    "pt-BR": ["Ícone do app", "Pasta neon", "Onda Aurora", "Prisma de vidro", "Montanha e lua"],
    "ru": ["Значок приложения", "Неоновая папка", "Волна Авроры", "Стеклянная призма", "Гора и луна"],
    "th": ["ไอคอนแอป", "โฟลเดอร์นีออน", "คลื่นออโรรา", "ปริซึมแก้ว", "ภูเขากับดวงจันทร์"],
    "tr": ["Uygulama simgesi", "Neon klasör", "Aurora dalgası", "Cam prizma", "Dağ ve ay"],
    "ur": ["ایپ کا آئیکن", "نیون فولڈر", "ارورا لہر", "شیشے کا منشور", "پہاڑ اور چاند"],
    "vi": ["Biểu tượng ứng dụng", "Thư mục neon", "Sóng Aurora", "Lăng kính thủy tinh", "Núi và trăng"],
    "zh-Hans": ["App 图标", "霓虹文件夹", "极光波浪", "玻璃棱镜", "山与月亮"],
}
DERIVED = {
    "pt-PT": ["Ícone da aplicação", "Pasta neon", "Onda Aurora", "Prisma de vidro", "Montanha e lua"],
    "zh-Hant": ["App 圖示", "霓虹資料夾", "極光波浪", "玻璃稜鏡", "山與月亮"],
}


def main():
    spec_path = ROOT / "scripts/aurora_strings.json"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if any(key in spec["keys"] for key in NEW_KEYS):
        print("Keys already present; nothing to do.")
        return
    spec["keys"].extend(NEW_KEYS)
    missing = set(spec["translations"]) - set(TRANSLATIONS)
    if missing:
        raise SystemExit(f"Missing authored translations for: {sorted(missing)}")
    for language, values in TRANSLATIONS.items():
        if language == "en":
            continue
        spec["translations"][language].extend(values)
    assert all(len(v) == len(spec["keys"]) for v in spec["translations"].values())
    spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

    derived_path = ROOT / "scripts/aurora_derived_languages.json"
    derived = json.loads(derived_path.read_text(encoding="utf-8"))
    for language, values in DERIVED.items():
        for key, value in zip(NEW_KEYS, values):
            derived[language]["additions"][key] = value
    derived_path.write_text(json.dumps(derived, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Appended 5 App Icon keys to 15 base languages and 2 derived languages.")


if __name__ == "__main__":
    main()
