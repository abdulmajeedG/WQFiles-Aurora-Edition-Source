#!/usr/bin/env python3
"""Apply Immersive Neon text/icon colors to list cells across the app."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = ["WQApps.m", "WQCache.m", "WQAurora.m", "WQPlistEditor.m", "main.m"]
PATTERN = re.compile(r"UIListContentConfiguration \*(c|content) = \[UIListContentConfiguration subtitleCellConfiguration\];")
INSERT = """    if (wq_prism_enabled()) {
        {v}.textProperties.color = wq_neon_textPrimary();
        {v}.secondaryTextProperties.color = wq_neon_textSecondary();
        {v}.imageProperties.tintColor = wq_neon_cyan();
    }"""

for name in FILES:
    path = ROOT / name
    text = path.read_text(encoding="utf-8")

    def repl(match):
        return match.group(0) + "\n" + INSERT.replace("{v}", match.group(1))

    updated, count = PATTERN.subn(repl, text)
    if updated != text:
        path.write_text(updated, encoding="utf-8")
    print(name, "cells themed:", count)
