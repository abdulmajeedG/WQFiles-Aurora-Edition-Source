#!/usr/bin/env python3
"""Replace the dashboard header/tools with the Immersive Neon components."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

START = "- (UIView *)buildAuroraBrand"
END = "- (void)refreshMetrics"
start = text.index(START)
end = text.index(END, start)

new = r'''- (UIView *)buildAuroraBrand
{
    WQPrismIconTile *logo = [[WQPrismIconTile alloc] initWithSymbol:@"folder.fill" tone:@"sky" size:36];
    UILabel *name = [UILabel new];
    name.text = @"WQFiles";
    name.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    name.adjustsFontForContentSizeCategory = YES;
    name.textColor = wq_neon_textPrimary();
    UILabel *edition = [UILabel new];
    edition.attributedText = [[NSAttributedString alloc] initWithString:@"AURORA · 2026" attributes:@{
        NSFontAttributeName: [UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightSemibold],
        NSForegroundColorAttributeName: wq_neon_textMuted(),
        NSKernAttributeName: @1.4 }];
    UIStackView *brand = [[UIStackView alloc] initWithArrangedSubviews:@[name, edition]];
    brand.axis = UILayoutConstraintAxisVertical;
    brand.spacing = 1;
    UIView *spacer = [UIView new];
    __weak typeof(self) weakSelf = self;
    UIButton *(^button)(NSString *, NSString *, void (^)(void)) = ^UIButton *(NSString *symbol, NSString *label, void (^action)(void)) {
        UIButtonConfiguration *cfg = [UIButtonConfiguration plainButtonConfiguration];
        cfg.image = [UIImage systemImageNamed:symbol
            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold]];
        cfg.baseForegroundColor = wq_neon_cyan();
        UIButton *control = [UIButton buttonWithConfiguration:cfg primaryAction:[UIAction actionWithHandler:^(UIAction *__unused a) { action(); }]];
        control.accessibilityLabel = label;
        control.backgroundColor = wq_neon_surface();
        control.layer.cornerRadius = 19;
        control.layer.cornerCurve = kCACornerCurveContinuous;
        control.layer.borderWidth = 1;
        control.layer.borderColor = [wq_neon_border() colorWithAlphaComponent:0.09].CGColor;
        [control.widthAnchor constraintEqualToConstant:38].active = YES;
        [control.heightAnchor constraintEqualToConstant:38].active = YES;
        return control;
    };
    UIButton *search = button(@"magnifyingglass", WQLocalized(@"Search"), ^{ [weakSelf searchFiles]; });
    UIButton *settings = button(@"gearshape", WQLocalized(@"Settings"), ^{ [weakSelf openSettings]; });
    UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[logo, brand, spacer, search, settings]];
    row.axis = UILayoutConstraintAxisHorizontal;
    row.alignment = UIStackViewAlignmentCenter;
    row.spacing = 10;
    [spacer setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    name.adjustsFontSizeToFitWidth = YES;
    name.minimumScaleFactor = 0.7;
    [brand setContentCompressionResistancePriority:UILayoutPriorityDefaultHigh forAxis:UILayoutConstraintAxisHorizontal];
    return row;
}

// Large storage overview: real capacity from the volume, a neon progress bar,
// and the local-files count. Nothing is estimated or simulated.
- (UIView *)buildStorageCard
{
    WQPrismGlassView *card = [[WQPrismGlassView alloc] initWithRadius:22];
    card.layer.borderColor = [wq_neon_blue() colorWithAlphaComponent:0.30].CGColor;

    UILabel *eyebrow = [UILabel new];
    eyebrow.text = WQLocalized(@"Storage Used");
    eyebrow.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    eyebrow.textColor = wq_neon_textMuted();

    _storageValue = [UILabel new];
    _storageValue.text = @"—";
    _storageValue.font = [UIFont monospacedDigitSystemFontOfSize:34 weight:UIFontWeightBold];
    _storageValue.adjustsFontForContentSizeCategory = YES;
    _storageValue.textColor = wq_neon_textPrimary();
    _storageValue.adjustsFontSizeToFitWidth = YES;
    _storageValue.minimumScaleFactor = 0.6;
    _storageTotalLabel = [UILabel new];
    _storageTotalLabel.text = @"";
    _storageTotalLabel.font = [UIFont monospacedDigitSystemFontOfSize:14 weight:UIFontWeightMedium];
    _storageTotalLabel.textColor = wq_neon_textMuted();

    _storageTrack = [UIView new];
    _storageTrack.translatesAutoresizingMaskIntoConstraints = NO;
    _storageTrack.backgroundColor = [wq_neon_border() colorWithAlphaComponent:0.08];
    _storageTrack.layer.cornerRadius = 3;
    _storageTrack.clipsToBounds = YES;
    _storageFill = [UIView new];
    _storageFill.translatesAutoresizingMaskIntoConstraints = NO;
    _storageFill.backgroundColor = wq_neon_cyan();
    _storageFill.layer.cornerRadius = 3;
    _storageFill.layer.shadowColor = wq_neon_cyan().CGColor;
    _storageFill.layer.shadowOpacity = 0.8;
    _storageFill.layer.shadowRadius = 6;
    _storageFill.layer.shadowOffset = CGSizeZero;
    [_storageTrack addSubview:_storageFill];
    _storageFillConstraint = [NSLayoutConstraint constraintWithItem:_storageFill attribute:NSLayoutAttributeWidth
        relatedBy:NSLayoutRelationEqual toItem:_storageTrack attribute:NSLayoutAttributeWidth multiplier:0.0001 constant:0];
    [NSLayoutConstraint activateConstraints:@[
        [_storageFillConstraint],
        [_storageFill.leadingAnchor constraintEqualToAnchor:_storageTrack.leadingAnchor],
        [_storageFill.topAnchor constraintEqualToAnchor:_storageTrack.topAnchor],
        [_storageFill.bottomAnchor constraintEqualToAnchor:_storageTrack.bottomAnchor],
        [_storageTrack.heightAnchor constraintEqualToConstant:6],
    ]];

    UILabel *filesCaption = [UILabel new];
    filesCaption.text = WQLocalized(@"Local Files");
    filesCaption.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightMedium];
    filesCaption.textColor = wq_neon_textMuted();
    _filesValue = [UILabel new];
    _filesValue.text = @"—";
    _filesValue.font = [UIFont monospacedDigitSystemFontOfSize:12.5 weight:UIFontWeightSemibold];
    _filesValue.textColor = wq_neon_textSecondary();
    UIStackView *footer = [[UIStackView alloc] initWithArrangedSubviews:@[filesCaption, _filesValue]];
    footer.axis = UILayoutConstraintAxisHorizontal;
    footer.spacing = 6;
    footer.alignment = UIStackViewAlignmentCenter;

    UIStackView *valueRow = [[UIStackView alloc] initWithArrangedSubviews:@[_storageValue, _storageTotalLabel]];
    valueRow.axis = UILayoutConstraintAxisHorizontal;
    valueRow.spacing = 8;
    valueRow.alignment = UIStackViewAlignmentLastBaseline;

    UIStackView *column = [[UIStackView alloc] initWithArrangedSubviews:@[eyebrow, valueRow, _storageTrack, footer]];
    column.translatesAutoresizingMaskIntoConstraints = NO;
    column.axis = UILayoutConstraintAxisVertical;
    column.alignment = UIStackViewAlignmentLeading;
    column.spacing = 8;
    [column setCustomSpacing:10 afterView:_storageTrack];
    [card.contentView addSubview:column];
    [NSLayoutConstraint activateConstraints:@[
        [column.topAnchor constraintEqualToAnchor:card.contentView.topAnchor constant:18],
        [column.bottomAnchor constraintEqualToAnchor:card.contentView.bottomAnchor constant:-16],
        [column.leadingAnchor constraintEqualToAnchor:card.contentView.leadingAnchor constant:18],
        [column.trailingAnchor constraintEqualToAnchor:card.contentView.trailingAnchor constant:-18],
        [_storageTrack.widthAnchor constraintEqualToAnchor:column.widthAnchor],
    ]];

    __weak typeof(self) weakSelf = self;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleStorageTap)];
    [card addGestureRecognizer:tap];
    card.userInteractionEnabled = YES;
    card.accessibilityLabel = WQLocalized(@"Storage Used");
    card.accessibilityTraits = UIAccessibilityTraitButton;
    (void)weakSelf;
    return card;
}

- (void)handleStorageTap { [self openCleaner]; }

// Floating tool card: gradient icon, clear title, optional real value.
- (UIControl *)wq_neonToolCardWithTitle:(NSString *)title symbol:(NSString *)symbol tone:(NSString *)tone
                                 action:(SEL)action value:(UILabel *__strong *)outValue
{
    UIControl *card = [UIControl new];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = wq_neon_surface();
    card.layer.cornerRadius = 20;
    card.layer.cornerCurve = kCACornerCurveContinuous;
    card.layer.borderWidth = 1;
    card.layer.borderColor = [wq_neon_border() colorWithAlphaComponent:0.08].CGColor;
    WQPrismIconTile *icon = [[WQPrismIconTile alloc] initWithSymbol:symbol tone:tone size:40];
    UILabel *name = [UILabel new];
    name.text = title;
    name.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    name.adjustsFontForContentSizeCategory = YES;
    name.textColor = wq_neon_textPrimary();
    name.numberOfLines = 1;
    name.adjustsFontSizeToFitWidth = YES;
    name.minimumScaleFactor = 0.75;
    UILabel *value = [UILabel new];
    value.text = @"—";
    value.font = [UIFont monospacedDigitSystemFontOfSize:20 weight:UIFontWeightBold];
    value.textColor = wq_neon_textSecondary();
    UIStackView *column = [[UIStackView alloc] initWithArrangedSubviews:@[icon, name, value]];
    column.translatesAutoresizingMaskIntoConstraints = NO;
    column.axis = UILayoutConstraintAxisVertical;
    column.alignment = UIStackViewAlignmentLeading;
    column.spacing = 8;
    [column setCustomSpacing:10 afterView:icon];
    column.userInteractionEnabled = NO;
    [card addSubview:column];
    [NSLayoutConstraint activateConstraints:@[
        [column.topAnchor constraintEqualToAnchor:card.topAnchor constant:14],
        [column.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-13],
        [column.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:14],
        [column.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-14],
        [card.heightAnchor constraintGreaterThanOrEqualToConstant:128],
    ]];
    card.isAccessibilityElement = YES;
    card.accessibilityLabel = title;
    card.accessibilityTraits = UIAccessibilityTraitButton;
    if (action) [card addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    if (outValue) *outValue = value; else value.hidden = YES;
    [card addTarget:self action:@selector(handleToolHighlight:) forControlEvents:UIControlEventTouchDown];
    [card addTarget:self action:@selector(handleToolHighlightEnd:) forControlEvents:UIControlEventTouchUpInside | UIControlEventTouchUpOutside | UIControlEventTouchCancel];
    return card;
}

- (void)handleToolHighlight:(UIControl *)sender
{
    [UIView animateWithDuration:UIAccessibilityIsReduceMotionEnabled() ? 0 : 0.12 animations:^{ sender.alpha = 0.75; }];
}
- (void)handleToolHighlightEnd:(UIControl *)sender
{
    [UIView animateWithDuration:UIAccessibilityIsReduceMotionEnabled() ? 0 : 0.18 animations:^{ sender.alpha = 1; }];
}

- (UIView *)buildToolsGrid
{
    UIControl *files = [self wq_neonToolCardWithTitle:WQLocalized(@"Files") symbol:@"folder.fill"
        tone:@"sky" action:@selector(openFiles) value:nil];
    UIControl *apps = [self wq_neonToolCardWithTitle:WQLocalized(@"Apps") symbol:@"square.grid.3x3.fill"
        tone:@"violet" action:@selector(openApps) value:&_appsValue];
    UIControl *clean = [self wq_neonToolCardWithTitle:WQLocalized(@"Clean") symbol:@"sparkles"
        tone:@"mint" action:@selector(openCleaner) value:nil];
    UIControl *backups = [self wq_neonToolCardWithTitle:WQLocalized(@"Backups") symbol:@"lock.shield.fill"
        tone:@"amber" action:@selector(openBackups) value:nil];
    UIStackView *top = [[UIStackView alloc] initWithArrangedSubviews:@[files, apps]];
    top.axis = UILayoutConstraintAxisHorizontal;
    top.distribution = UIStackViewDistributionFillEqually;
    top.spacing = 10;
    UIStackView *bottom = [[UIStackView alloc] initWithArrangedSubviews:@[clean, backups]];
    bottom.axis = UILayoutConstraintAxisHorizontal;
    bottom.distribution = UIStackViewDistributionFillEqually;
    bottom.spacing = 10;
    UIStackView *grid = [[UIStackView alloc] initWithArrangedSubviews:@[top, bottom]];
    grid.axis = UILayoutConstraintAxisVertical;
    grid.spacing = 10;
    return grid;
}

'''

text = text[:start] + new + text[end:]
path.write_text(text, encoding="utf-8")
print("dashboard components replaced;", len(new), "chars inserted")
