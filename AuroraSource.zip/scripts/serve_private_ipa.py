#!/usr/bin/env python3
"""Bounded LAN-only transfer of one verified IPA. No uploads or account access.

No directory listing, arbitrary-file routes, firewall changes, port forwarding,
certificate collection or GitHub credentials. The temporary capability URL and
QR stay in ignored local output folders. HTTP is local-network transport, not TLS.
"""
import argparse
import hashlib
import ipaddress
import json
import re
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / ".work/private-build/lan-download.json"


def prepare(host, port, minutes, ipa, digest):
    import qrcode
    from PIL import Image, ImageDraw, ImageFont
    address = ipaddress.ip_address(host)
    if address.version != 4 or not address.is_private or address.is_loopback or address.is_link_local:
        raise SystemExit("Only a private LAN IPv4 address is allowed.")
    ipa = ipa.resolve(strict=True)
    actual = hashlib.sha256(ipa.read_bytes()).hexdigest()
    if digest is None:
        digest = actual
    if actual != digest:
        raise SystemExit("Refusing to serve an IPA other than the independently verified test build.")
    route = f"/aurora/{secrets.token_urlsafe(18)}/{ipa.name}"
    url = f"http://{host}:{port}{route}"
    out = ROOT / "outputs/private-test1"
    out.mkdir(parents=True, exist_ok=True)
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=14, border=4)
    qr.add_data(url)
    qr.make(fit=True)
    image = qr.make_image(fill_color="black", back_color="white").convert("RGB")
    plain = out / "Aurora-WiFi-IPA-QR-simple.png"
    image.save(plain)
    width = max(850, image.width + 100)
    height = image.height + 360
    card = Image.new("RGB", (width, height), "#0b1432")
    draw = ImageDraw.Draw(card)
    regular = "C:/Windows/Fonts/segoeui.ttf"
    bold = "C:/Windows/Fonts/segoeuib.ttf"
    def font(size, heavy=False):
        path = Path(bold if heavy else regular)
        return ImageFont.truetype(str(path), size) if path.exists() else ImageFont.load_default()
    draw.text((50, 30), "WQ Files - Aurora Edition", font=font(43, True), fill="white")
    draw.text((50, 100), "DIRECT IPA DOWNLOAD - SAME WI-FI", font=font(26), fill="#91f0e5")
    card.paste(image, ((width - image.width) // 2, 165))
    bottom = 185 + image.height
    draw.text((50, bottom), f"{host}:{port}  |  Available for {minutes} minutes", font=font(25), fill="white")
    draw.text((50, bottom + 47), "No GitHub login. Keep this computer on and connected.", font=font(24), fill="#b4c9ed")
    draw.text((50, bottom + 90), "Re-sign preserving App Group support before installing.", font=font(24), fill="#b4c9ed")
    poster = out / "Aurora-WiFi-IPA-QR.png"
    card.save(poster)
    import cv2
    decoded, _, _ = cv2.QRCodeDetector().detectAndDecode(cv2.imread(str(plain)))
    if decoded != url:
        raise SystemExit("QR did not decode to the intended LAN-only URL.")
    config = {"host": host, "port": port, "minutes": minutes, "ipa": str(ipa),
              "sha256": digest, "route": route, "url": url,
              "qr": str(poster), "plain_qr": str(plain), "max_get_requests": 16}
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    CONFIG.write_text(json.dumps(config, indent=2), encoding="utf-8")
    print(json.dumps({"url": url, "qr": str(poster), "direct_ipa": True, "qr_decoded": True,
                      "minutes": minutes, "bytes": ipa.stat().st_size, "sha256": digest}, indent=2))


def serve():
    cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    ipa = Path(cfg["ipa"])
    if not ipaddress.ip_address(cfg["host"]).is_private or hashlib.sha256(ipa.read_bytes()).hexdigest() != cfg["sha256"]:
        raise SystemExit("Invalid binding or changed IPA; not starting.")
    deadline = time.monotonic() + min(30, max(1, cfg["minutes"])) * 60
    counter = [0]
    lock = threading.Lock()
    size = ipa.stat().st_size

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "AuroraLocalTransfer/1.0"
        sys_version = ""

        def log_message(self, *_):
            pass  # Do not log capability paths, headers or client identifiers.

        def setup(self):
            super().setup()
            self.connection.settimeout(15)

        def do_HEAD(self):
            self.send_file(False)

        def do_GET(self):
            self.send_file(True)

        def send_file(self, body):
            parsed = urlsplit(self.path)
            if parsed.path != cfg["route"] or parsed.query:
                self.send_error(404)
                return
            if time.monotonic() >= deadline:
                self.send_error(410)
                return
            if body:
                with lock:
                    if counter[0] >= cfg["max_get_requests"]:
                        self.send_error(410)
                        return
                    counter[0] += 1
            start, end, status = 0, size - 1, 200
            range_header = self.headers.get("Range")
            if range_header:
                match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header)
                if not match or not any(match.groups()):
                    self.send_error(416)
                    return
                a, b = match.groups()
                if not a:
                    start = max(0, size - int(b))
                else:
                    start = int(a)
                    end = min(size - 1, int(b)) if b else size - 1
                if start > end or start >= size:
                    self.send_error(416)
                    return
                status = 206
            self.send_response(status)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Disposition", f'attachment; filename="{ipa.name}"')
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Connection", "close")
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            self.close_connection = True
            if not body:
                return
            try:
                with ipa.open("rb") as source:
                    source.seek(start)
                    remaining = end - start + 1
                    while remaining and time.monotonic() < deadline:
                        data = source.read(min(64 * 1024, remaining))
                        if not data:
                            break
                        self.wfile.write(data)
                        remaining -= len(data)
            except (ConnectionError, TimeoutError):
                pass

    with ThreadingHTTPServer((cfg["host"], cfg["port"]), Handler) as server:
        server.daemon_threads = True
        server.timeout = 1
        print(f"Serving only the verified IPA on LAN {cfg['host']}:{cfg['port']} for at most {cfg['minutes']} minutes.", flush=True)
        while time.monotonic() < deadline:
            with lock:
                if counter[0] >= cfg["max_get_requests"]:
                    break
            server.handle_request()
    print("LAN transfer stopped; no router or firewall setting was changed.", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--host", required=True)
    p.add_argument("--port", type=int, default=8879)
    p.add_argument("--minutes", type=int, choices=range(1, 31), default=30)
    p.add_argument("--ipa", type=Path, required=True)
    p.add_argument("--sha", default=None, help="Expected SHA-256; defaults to the file's own digest")
    sub.add_parser("serve")
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.host, args.port, args.minutes, args.ipa, args.sha)
    else:
        serve()
