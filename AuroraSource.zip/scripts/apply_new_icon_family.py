#!/usr/bin/env python3
"""Point the app icon family at Cleaning / Files / Storage / Apps."""
import plistlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

ALTERNATES = {
    "files": {"CFBundleIconFiles": ["AltFiles120", "AltFiles180"], "UIPrerenderedIcon": False},
    "storage": {"CFBundleIconFiles": ["AltStorage120", "AltStorage180"], "UIPrerenderedIcon": False},
    "apps": {"CFBundleIconFiles": ["AltApps120", "AltApps180"], "UIPrerenderedIcon": False},
}

# Source Info.plist (built app gets this merged again by build.sh).
info_path = ROOT / "Info.plist"
info = plistlib.loads(info_path.read_bytes())
icons = info.setdefault("CFBundleIcons", {})
icons["CFBundleAlternateIcons"] = ALTERNATES
info_path.write_bytes(plistlib.dumps(info, fmt=plistlib.FMT_XML))
print("Info.plist alternates:", list(icons["CFBundleAlternateIcons"]))

# Fragment merged after actool in build.sh.
fragment_path = ROOT / "icons" / "alternate-icons.plist"
fragment_path.write_bytes(plistlib.dumps({"CFBundleIcons": {"CFBundleAlternateIcons": ALTERNATES}},
                                          fmt=plistlib.FMT_XML))
print("alternate-icons.plist written")

# build.sh: new file stems, validation names and merge checks.
build_path = ROOT / "build.sh"
text = build_path.read_text(encoding="utf-8")
text = text.replace(
    "for stem in AltAuroraWave AltGlassPrism AltMountain; do",
    "for stem in AltFiles AltStorage AltApps; do")
text = text.replace(
    'if set(alternates) != {"aurora-wave", "glass-prism", "mountain"}:',
    'if set(alternates) != {"files", "storage", "apps"}:')
text = text.replace(
    'for name in ("aurora-wave", "glass-prism", "mountain"):',
    'for name in ("files", "storage", "apps"):')
build_path.write_text(text, encoding="utf-8")
print("build.sh updated")

# Tests stage the same fixture icon names.
test_path = ROOT / "tests" / "test_build.py"
text = test_path.read_text(encoding="utf-8")
for old, new in [
    ('"AltAuroraWave120.png", "AltAuroraWave180.png", "AltGlassPrism120.png",\n                         "AltGlassPrism180.png", "AltMountain120.png", "AltMountain180.png"',
     '"AltFiles120.png", "AltFiles180.png", "AltStorage120.png",\n                         "AltStorage180.png", "AltApps120.png", "AltApps180.png"'),
    ('"AltAuroraWave120.png", "AltAuroraWave180.png", "AltGlassPrism120.png",\n                     "AltGlassPrism180.png", "AltMountain120.png", "AltMountain180.png"',
     '"AltFiles120.png", "AltFiles180.png", "AltStorage120.png",\n                     "AltStorage180.png", "AltApps120.png", "AltApps180.png"'),
]:
    text = text.replace(old, new)
test_path.write_text(text, encoding="utf-8")
print("test_build.py updated")

# Verify script expects the new alternate set.
verify_path = ROOT / "scripts" / "verify_aurora_ipa.py"
text = verify_path.read_text(encoding="utf-8")
text = text.replace(
    '''alts = {"aurora-wave": ["AltAuroraWave120", "AltAuroraWave180"],
                "glass-prism": ["AltGlassPrism120", "AltGlassPrism180"],
                "mountain": ["AltMountain120", "AltMountain180"]}''',
    '''alts = {"files": ["AltFiles120", "AltFiles180"],
                "storage": ["AltStorage120", "AltStorage180"],
                "apps": ["AltApps120", "AltApps180"]}''')
verify_path.write_text(text, encoding="utf-8")
print("verify_aurora_ipa.py updated")
