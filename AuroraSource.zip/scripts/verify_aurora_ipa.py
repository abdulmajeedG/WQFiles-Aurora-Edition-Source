#!/usr/bin/env python3
"""Independently inspect the private arm64 IPA on Windows/macOS, offline.

Verifies ZIP CRC, source metadata/localizations, ad-hoc CodeDirectory page
hashes, Info.plist and embedded XML entitlement hashes. This is integrity
validation, NOT Apple certificate/provisioning trust or installation approval.
"""
import argparse
import hashlib
import json
import math
import plistlib
import stat
import struct
import zipfile
from pathlib import Path, PurePosixPath


def require(condition, message):
    if not condition:
        raise ValueError(message)


def signature_info(binary, info_bytes):
    require(len(binary) >= 32, "truncated executable")
    magic, cpu, _, filetype, ncmds, cmdsize = struct.unpack_from("<6I", binary)
    require((magic, cpu, filetype) == (0xFEEDFACF, 0x0100000C, 2), "not an arm64 executable")
    require(ncmds < 10000 and 32 + cmdsize <= len(binary), "invalid Mach-O commands")
    cursor = 32
    signature = None
    for _ in range(ncmds):
        require(cursor + 8 <= 32 + cmdsize, "truncated load command")
        command, length = struct.unpack_from("<2I", binary, cursor)
        require(length >= 8 and cursor + length <= 32 + cmdsize, "bad command length")
        if command == 0x1D:
            require(length >= 16, "bad code signature command")
            offset, size = struct.unpack_from("<2I", binary, cursor + 8)
            require(offset + size <= len(binary), "signature outside executable")
            signature = binary[offset:offset + size]
        cursor += length
    require(signature is not None and len(signature) >= 12, "missing signature")
    magic, length, count = struct.unpack_from(">3I", signature)
    require(magic == 0xFADE0CC0 and length <= len(signature) and 12 + count * 8 <= length, "bad signature superblob")
    blobs = {}
    for index in range(count):
        slot, offset = struct.unpack_from(">2I", signature, 12 + 8 * index)
        require(offset + 8 <= length, "invalid signature blob offset")
        _, size = struct.unpack_from(">2I", signature, offset)
        require(size >= 8 and offset + size <= length, "invalid signature blob length")
        blobs[slot] = signature[offset:offset + size]
    require(0 in blobs and 5 in blobs, "missing CodeDirectory or XML entitlements")
    cd = blobs[0]
    require(len(cd) >= 44, "truncated CodeDirectory")
    magic, size, version, flags, hashes, _, special, slots, limit = struct.unpack_from(">9I", cd)
    hash_size, hash_type, _, shift = struct.unpack_from("4B", cd, 36)
    require(magic == 0xFADE0C02 and size == len(cd), "invalid CodeDirectory")
    require(flags & 2, "expected the build.sh ad-hoc signature")
    functions = {1: hashlib.sha1, 2: hashlib.sha256, 3: hashlib.sha256, 4: hashlib.sha384}
    require(hash_type in functions and hash_size in (20, 32, 48), "unsupported code hash format")
    if limit == 0xFFFFFFFF and version >= 0x20300:
        require(len(cd) >= 64, "missing 64-bit code limit")
        limit = struct.unpack_from(">Q", cd, 56)[0]
    require(0 < limit <= len(binary) and shift <= 20, "invalid code range/page size")
    page = (1 << shift) if shift else limit
    require(slots == math.ceil(limit / page), "code page count mismatch")
    require(hashes >= special * hash_size and hashes + slots * hash_size <= len(cd), "hash table outside CodeDirectory")
    digest = lambda data: functions[hash_type](data).digest()[:hash_size]
    for index in range(slots):
        expected = cd[hashes + index * hash_size:hashes + (index + 1) * hash_size]
        actual = digest(binary[index * page:min(limit, (index + 1) * page)])
        require(actual == expected, f"executable page hash mismatch: {index}")
    require(special >= 5, "missing required special hash slots")
    for slot, data in ((1, info_bytes), (5, blobs[5])):
        expected = cd[hashes - slot * hash_size:hashes - (slot - 1) * hash_size]
        require(digest(data) == expected, f"special slot hash mismatch: {slot}")
    entitlement_blob = blobs[5]
    require(struct.unpack_from(">I", entitlement_blob)[0] == 0xFADE7171, "not an XML entitlement blob")
    entitlements = plistlib.loads(entitlement_blob[8:].rstrip(b"\0"))
    require(entitlements.get("com.apple.security.application-groups") == ["group.cz.kolbi.wqfiles"], "App Group changed or missing")
    return {"architecture": "arm64", "ad_hoc": True, "verified_code_pages": slots,
            "hash_type": hash_type, "app_groups": entitlements["com.apple.security.application-groups"]}


def verify(path):
    data = path.read_bytes()
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "ZIP CRC failure")
        require(len(archive.infolist()) < 1000, "unexpected archive size")
        for entry in archive.infolist():
            name = PurePosixPath(entry.filename)
            require(not name.is_absolute() and ".." not in name.parts and "\\" not in entry.filename, "unsafe ZIP path")
            mode = stat.S_IFMT(entry.external_attr >> 16)
            require(mode in (0, stat.S_IFREG, stat.S_IFDIR), "unexpected ZIP special file")
        prefix = "Payload/WQFiles.app/"
        raw_info = archive.read(prefix + "Info.plist")
        info = plistlib.loads(raw_info)
        expected = {"CFBundleIdentifier": "cz.kolbi.wqfiles", "CFBundleExecutable": "WQFiles",
                    "CFBundleShortVersionString": "0.1.0", "CFBundleVersion": "2", "MinimumOSVersion": "26.0",
                    "WQUpstreamVersion": "0.9.10"}
        for key, value in expected.items():
            require(info.get(key) == value, f"metadata mismatch: {key}")
        languages = set(info.get("CFBundleLocalizations", []))
        require(languages == {"en", "ar", "de", "es", "it", "ko", "pl", "pt-BR", "ru", "th", "tr", "zh-Hans",
                              "vi", "fr", "ur", "pt-PT", "zh-Hant"}, "unexpected localization list")
        for language in languages:
            require(prefix + language + ".lproj/Localizable.strings" in archive.namelist(), "missing localization: " + language)
        require(prefix + "Assets.car" in archive.namelist(), "missing compiled icon catalog")
        alts = {"files": ["AltFiles120", "AltFiles180"],
                "storage": ["AltStorage120", "AltStorage180"],
                "apps": ["AltApps120", "AltApps180"]}
        icons = info.get("CFBundleIcons", {}).get("CFBundleAlternateIcons", {})
        require(set(icons) == set(alts), "unexpected alternate icon set")
        for name, files in alts.items():
            require(set(icons[name].get("CFBundleIconFiles", [])) == set(files), "alternate icon list mismatch: " + name)
            for stem in files:
                require(prefix + stem + ".png" in archive.namelist(), "missing alternate icon file: " + stem)
        signature = signature_info(archive.read(prefix + "WQFiles"), raw_info)
        return {"file": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                "metadata": expected, "localizations": sorted(languages), "signature_integrity": signature,
                "device_tested": False, "apple_distribution_signature": False}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ipa", type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.ipa), indent=2, ensure_ascii=False))
