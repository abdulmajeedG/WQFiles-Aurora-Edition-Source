#!/usr/bin/env python3
"""Replace WQAuroraSceneView.drawRect with the calm native grouped background."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "WQAuroraScene.m"
text = path.read_text(encoding="utf-8")
start = text.index("- (void)drawRect:(CGRect)rect")
end = text.index("\n@end", start)
new = '''- (void)drawRect:(CGRect)rect
{
    (void)rect;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;
    CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    BOOL plain = wq_prism_plain_background();
    BOOL flat = plain || self.traitCollection.accessibilityContrast == UIAccessibilityContrastHigh;
    UIColor *base = flat ? UIColor.systemBackgroundColor : UIColor.systemGroupedBackgroundColor;
    [base setFill];
    UIRectFill(self.bounds);
    if (flat || w <= 0 || h <= 0) return;
    // A very quiet vertical wash over the exact system grouped background:
    // no artwork, no curves, no motion - the 2026 calm hierarchy.
    BOOL dark = self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    NSArray *colors = dark
        ? @[(id)[UIColor colorWithWhite:1 alpha:0.035].CGColor,
            (id)[UIColor colorWithWhite:1 alpha:0].CGColor]
        : @[(id)[UIColor colorWithWhite:0 alpha:0.018].CGColor,
            (id)[UIColor colorWithWhite:1 alpha:0].CGColor];
    CGGradientRef wash = CGGradientCreateWithColors(space, (__bridge CFArrayRef)colors, NULL);
    CGContextDrawLinearGradient(ctx, wash, CGPointZero, CGPointMake(0, h), 0);
    CGGradientRelease(wash);
    CGColorSpaceRelease(space);
}'''
path.write_text(text[:start] + new + text[end:], encoding="utf-8")
print("drawRect replaced;", len(new), "chars")
