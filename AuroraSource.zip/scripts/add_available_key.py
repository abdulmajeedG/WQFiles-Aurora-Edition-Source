#!/usr/bin/env python3
"""Add the 'Available' storage caption to every translation input."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KEY = "Available"
TRANSLATIONS = {
    "en": "Available",
    "ar": "المتاح",
    "de": "Verfügbar",
    "es": "Disponible",
    "fr": "Disponible",
    "it": "Disponibile",
    "ko": "사용 가능",
    "pl": "Dostępne",
    "pt-BR": "Disponível",
    "ru": "Доступно",
    "th": "ว่าง",
    "tr": "Kullanılabilir",
    "ur": "دستیاب",
    "vi": "Khả dụng",
    "zh-Hans": "可用",
}
DERIVED = {"pt-PT": "Disponível", "zh-Hant": "可用"}


def main():
    spec_path = ROOT / "scripts/aurora_strings.json"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if KEY in spec["keys"]:
        print("'Available' already present.")
        return
    spec["keys"].append(KEY)
    for language, value in TRANSLATIONS.items():
        if language == "en":
            continue
        spec["translations"][language].append(value)
    assert all(len(v) == len(spec["keys"]) for v in spec["translations"].values())
    spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

    derived_path = ROOT / "scripts/aurora_derived_languages.json"
    derived = json.loads(derived_path.read_text(encoding="utf-8"))
    for language, value in DERIVED.items():
        derived[language]["additions"][KEY] = value
    derived_path.write_text(json.dumps(derived, indent=2, ensure_ascii=False), encoding="utf-8")
    print("'Available' added to 15 base and 2 derived languages.")


if __name__ == "__main__":
    main()
