#!/usr/bin/env python3
"""Build the design-concept gallery with base64-embedded screenshots."""
import base64
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/design/concepts"
OUT.mkdir(parents=True, exist_ok=True)

shots = {
    "design-A.png": r"C:\Users\HP\AppData\Local\Temp\opencode-browser-LAn4k6\0\screenshot.png",
    "design-B.png": r"C:\Users\HP\AppData\Local\Temp\opencode-browser-gljvd3\0\screenshot.png",
    "design-C.png": r"C:\Users\HP\AppData\Local\Temp\opencode-browser-mvQ8ju\0\screenshot.png",
    "design-D.png": r"C:\Users\HP\AppData\Local\Temp\opencode-browser-KpAa0U\0\screenshot.png",
}
captions = {
    "design-A.png": ("A — Nova المضغوط",
                     "صفحة واحدة مرتبة: إحصاءات في صف واحد، إجراءات سريعة، ملفات حديثة. حركة خفيفة جدًا."),
    "design-B.png": ("B — زجاج أورورا",
                     "خلفية شفقية متدرجة + بطاقات زجاجية شفافة وإطار متوهج. متوازن ومبهر."),
    "design-C.png": ("C — الشبكة الكبيرة",
                     "بلاطات ضخمة ملونة تملأ الشاشة بأرقام كبيرة وبحث بارز. أيقونات أولًا."),
    "design-D.png": ("D — داكن نيون",
                     "داكن فاخر بخطوط نيون سماوية/بنفسجية وحواف متوهجة. هادئ وفخم."),
}

cards = []
for name, src in shots.items():
    dest = OUT / name
    shutil.copy2(src, dest)
    b64 = base64.b64encode(dest.read_bytes()).decode()
    title, desc = captions[name]
    cards.append(
        f'<div class="c"><img src="data:image/png;base64,{b64}" alt="{title}">'
        f'<h3>{title}</h3><p>{desc}</p></div>'
    )

html = """<!doctype html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
body{background:#0b1220;color:#e8eefb;font-family:system-ui,sans-serif;padding:24px;margin:0}
h1{font-size:22px;margin:0 0 6px}
.sub{color:#8fa3c6;font-size:14px;margin:0 0 22px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:18px}
.c{background:#111a2e;border:1px solid #223048;border-radius:18px;padding:14px}
.c img{width:100%;border-radius:12px;display:block}
h3{margin:12px 2px 4px;font-size:17px;color:#3fd6e3}
p{margin:0 2px;font-size:13.5px;color:#b7c3dc;line-height:1.7}
</style></head><body><h1>WQ Files — Aurora: 4 تصاميم مقترحة</h1>
<p class="sub">نماذج أولية (ليست لقطات من التطبيق). اختر رقم التصميم أو اطلب دمج عناصر من أكثر من تصميم.</p>
<div class="grid">""" + "".join(cards) + "</div></body></html>"

(OUT / "gallery.html").write_text(html, encoding="utf-8")
print("gallery ready:", (OUT / "gallery.html").stat().st_size, "bytes")
