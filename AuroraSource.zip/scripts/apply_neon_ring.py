#!/usr/bin/env python3
"""Storage card as a green glowing ring + Settings-accurate used value."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

# --- Replace buildStorageCard (keep handleStorageTap following it) -------------
start = text.index("- (UIView *)buildStorageCard")
end = text.index("- (void)handleStorageTap", start)
card = r'''- (UIView *)buildStorageCard
{
    WQPrismGlassView *card = [[WQPrismGlassView alloc] initWithRadius:22];
    card.layer.borderColor = [wq_neon_cyan() colorWithAlphaComponent:0.32].CGColor;

    UILabel *eyebrow = [UILabel new];
    eyebrow.text = WQLocalized(@"Storage Used");
    eyebrow.font = [UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    eyebrow.textColor = wq_neon_textMuted();

    _storageValue = [UILabel new];
    _storageValue.text = @"—";
    _storageValue.font = [UIFont monospacedDigitSystemFontOfSize:30 weight:UIFontWeightBold];
    _storageValue.adjustsFontForContentSizeCategory = YES;
    _storageValue.textColor = wq_neon_textPrimary();
    _storageValue.adjustsFontSizeToFitWidth = YES;
    _storageValue.minimumScaleFactor = 0.6;
    _storageTotalLabel = [UILabel new];
    _storageTotalLabel.text = @"";
    _storageTotalLabel.font = [UIFont monospacedDigitSystemFontOfSize:13 weight:UIFontWeightMedium];
    _storageTotalLabel.textColor = wq_neon_textMuted();

    UILabel *filesCaption = [UILabel new];
    filesCaption.text = WQLocalized(@"Local Files");
    filesCaption.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightMedium];
    filesCaption.textColor = wq_neon_textMuted();
    _filesValue = [UILabel new];
    _filesValue.text = @"—";
    _filesValue.font = [UIFont monospacedDigitSystemFontOfSize:12.5 weight:UIFontWeightSemibold];
    _filesValue.textColor = wq_neon_textSecondary();
    UIStackView *footer = [[UIStackView alloc] initWithArrangedSubviews:@[filesCaption, _filesValue]];
    footer.axis = UILayoutConstraintAxisHorizontal;
    footer.spacing = 6;
    footer.alignment = UIStackViewAlignmentCenter;

    UIStackView *valueRow = [[UIStackView alloc] initWithArrangedSubviews:@[_storageValue, _storageTotalLabel]];
    valueRow.axis = UILayoutConstraintAxisHorizontal;
    valueRow.spacing = 6;
    valueRow.alignment = UIStackViewAlignmentLastBaseline;

    _storageRing = [WQNeonStorageRing new];
    UIStackView *info = [[UIStackView alloc] initWithArrangedSubviews:@[_storageRing, eyebrow, valueRow, footer]];
    info.translatesAutoresizingMaskIntoConstraints = NO;
    info.axis = UILayoutConstraintAxisVertical;
    info.alignment = UIStackViewAlignmentLeading;
    info.spacing = 7;
    [info setCustomSpacing:12 afterView:_storageRing];

    [card.contentView addSubview:info];
    [NSLayoutConstraint activateConstraints:@[
        [info.topAnchor constraintEqualToAnchor:card.contentView.topAnchor constant:16],
        [info.bottomAnchor constraintEqualToAnchor:card.contentView.bottomAnchor constant:-16],
        [info.leadingAnchor constraintEqualToAnchor:card.contentView.leadingAnchor constant:18],
        [info.trailingAnchor constraintEqualToAnchor:card.contentView.trailingAnchor constant:-18],
    ]];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleStorageTap)];
    [card addGestureRecognizer:tap];
    card.userInteractionEnabled = YES;
    card.accessibilityLabel = WQLocalized(@"Storage Used");
    card.accessibilityTraits = UIAccessibilityTraitButton;
    return card;
}

'''
text = text[:start] + card + text[end:]

# --- Replace refreshMetrics with ring + Settings-matching used value ----------
start = text.index("- (void)refreshMetrics")
end = text.index("- (void)rebuildRecent", start)
metrics = r'''- (void)refreshMetrics
{
    _favoritesValue.text = [NSNumberFormatter localizedStringFromNumber:@(wq_favorites().count)
        numberStyle:NSNumberFormatterDecimalStyle];
    id count = [NSUserDefaults.standardUserDefaults objectForKey:@"WQAuroraAppCount"];
    _appsValue.text = [count isKindOfClass:NSNumber.class]
        ? [NSNumberFormatter localizedStringFromNumber:count numberStyle:NSNumberFormatterDecimalStyle] : @"—";
    if (_metricsPending) return;
    _metricsPending = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(wq_io(), ^{
        // Personal data inside this app, measured recursively (bounded).
        NSURL *documents = [NSURL fileURLWithPath:[NSHomeDirectory() stringByAppendingPathComponent:@"Documents"] isDirectory:YES];
        NSFileManager *manager = NSFileManager.defaultManager;
        NSDirectoryEnumerator<NSURL *> *walker = [manager enumeratorAtURL:documents
            includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLIsSymbolicLinkKey, NSURLFileSizeKey]
            options:NSDirectoryEnumerationSkipsHiddenFiles errorHandler:nil];
        NSUInteger files = 0, seen = 0;
        unsigned long long bytes = 0;
        for (NSURL *url in walker) {
            if (++seen > 50000) break;
            NSDictionary *values = [url resourceValuesForKeys:@[NSURLIsSymbolicLinkKey, NSURLIsRegularFileKey, NSURLFileSizeKey] error:nil];
            if (![values[NSURLIsSymbolicLinkKey] isEqual:@YES] && [values[NSURLIsRegularFileKey] isEqual:@YES]) {
                files++;
                bytes += [values[NSURLFileSizeKey] unsignedLongLongValue];
            }
        }
        // Capacity: both free-space APIs are read and the smaller free value
        // is used, which matches Settings → iPhone Storage more closely
        // (Settings does not count purgeable space as free).
        NSURL *volumeURL = [NSURL fileURLWithPath:@"/" isDirectory:YES];
        NSDictionary *volumeValues = [volumeURL resourceValuesForKeys:@[
            NSURLVolumeTotalCapacityKey,
            NSURLVolumeAvailableCapacityKey,
            NSURLVolumeAvailableCapacityForImportantUsageKey] error:nil];
        unsigned long long total = [volumeValues[NSURLVolumeTotalCapacityKey] unsignedLongLongValue];
        unsigned long long avail = [volumeValues[NSURLVolumeAvailableCapacityKey] unsignedLongLongValue];
        unsigned long long important = [volumeValues[NSURLVolumeAvailableCapacityForImportantUsageKey] unsignedLongLongValue];
        unsigned long long free = 0;
        if (avail && important) free = MIN(avail, important);
        else free = avail ?: important;
        if (!total || free > total) {
            NSDictionary *volume = [manager attributesOfFileSystemForPath:NSHomeDirectory() error:nil];
            total = [volume[NSFileSystemSize] unsignedLongLongValue];
            free = [volume[NSFileSystemFreeSize] unsignedLongLongValue];
        }
        BOOL readable = walker != nil;
        (void)bytes;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) owner = weakSelf;
            if (!owner) return;
            owner->_metricsPending = NO;
            owner->_filesValue.text = readable
                ? [NSNumberFormatter localizedStringFromNumber:@(files) numberStyle:NSNumberFormatterDecimalStyle] : @"—";
            if (total && free <= total) {
                unsigned long long used = total - free;
                owner->_storageValue.text = wq_size_text(used);
                owner->_storageTotalLabel.text = [@"/ " stringByAppendingString:wq_size_text(total)];
                double fraction = (double)used / (double)total;
                [owner->_storageRing setFraction:fraction animated:YES];
            } else {
                owner->_storageValue.text = @"—";
                owner->_storageTotalLabel.text = @"";
            }
        });
    });
}

'''
text = text[:start] + metrics + text[end:]

# --- Backups: open the proven backups folder directly (no vault crash) -------
old_backups = """- (void)openBackups { [self openTab:3]; }"""
new_backups = """- (void)openBackups
{
    [NSFileManager.defaultManager createDirectoryAtPath:wq_backup_root() withIntermediateDirectories:YES attributes:nil error:nil];
    [self openPath:wq_backup_root() title:WQLocalizedNullable(@"File Backups")];
}"""
if old_backups in text:
    text = text.replace(old_backups, new_backups)

path.write_text(text, encoding="utf-8")
print("storage card, metrics and backups action updated.")
