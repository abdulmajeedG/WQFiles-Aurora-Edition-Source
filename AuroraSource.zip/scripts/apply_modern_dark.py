#!/usr/bin/env python3
"""Modern Dark: clean icons, ring gauge, calm cards, accent themes."""
from pathlib import Path

path = Path(__file__).resolve().parents[1] / "main.m"
text = path.read_text(encoding="utf-8")

# 1) Replace the tone helper + icon tile with the clean monochrome-inside-
#    raised-surface style used by the Modern Dark reference.
start = text.index("// Immersive Neon gradient pairs per category")
end = text.index("@interface WQPrismGlassView", start)
tile = r'''// Modern Dark icon tile: raised neutral square, single accent glyph.
@implementation WQPrismIconTile {
    UIImageView *_imageView;
}

- (instancetype)initWithSymbol:(NSString *)symbol tone:(NSString *)tone size:(CGFloat)size
{
    if ((self = [super initWithFrame:CGRectZero])) {
        (void)tone;
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.userInteractionEnabled = NO;
        self.layer.cornerRadius = size * 0.28;
        self.layer.cornerCurve = kCACornerCurveContinuous;
        self.clipsToBounds = YES;
        self.backgroundColor = wq_neon_surfaceRaised();
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = wq_neon_border().CGColor;
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:size * 0.44
                                                                                         weight:UIImageSymbolWeightSemibold];
        _imageView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbol withConfiguration:cfg]];
        _imageView.translatesAutoresizingMaskIntoConstraints = NO;
        _imageView.tintColor = wq_neon_blue();
        _imageView.contentMode = UIViewContentModeScaleAspectFit;
        [self addSubview:_imageView];
        [NSLayoutConstraint activateConstraints:@[
            [self.widthAnchor constraintEqualToConstant:size],
            [self.heightAnchor constraintEqualToConstant:size],
            [_imageView.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
            [_imageView.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
            [_imageView.widthAnchor constraintEqualToConstant:size * 0.58],
            [_imageView.heightAnchor constraintEqualToConstant:size * 0.58],
        ]];
    }
    return self;
}

@end

'''
text = text[:start] + tile + text[end:]

# 2) The glass card border is now the calm #293444 hairline (no glow).
text = text.replace(
    """    if (wq_prism_enabled()) {
        // Glowing edges on every card, one consistent neon hairline.
        self.layer.borderColor = [wq_neon_cyan() colorWithAlphaComponent:0.30].CGColor;
    } else {
        self.layer.borderColor = UIColor.separatorColor.CGColor;
    }""",
    """    self.layer.borderColor = wq_prism_enabled() ? wq_neon_border().CGColor : UIColor.separatorColor.CGColor;""")

# 3) Ring: accent arc, percent label inside, no rotating halo.
start = text.index("@interface WQNeonStorageRing")
end = text.index("@implementation WQPrismHomeViewController", start)
ring = r'''@interface WQNeonStorageRing : UIView
@property (nonatomic, readonly) UILabel *percentLabel;
- (void)setFraction:(double)fraction animated:(BOOL)animated;
@end

@implementation WQNeonStorageRing {
    CAShapeLayer *_track;
    CAShapeLayer *_progress;
    UILabel *_percentLabel;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if ((self = [super initWithFrame:frame])) {
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.backgroundColor = UIColor.clearColor;
        _track = [CAShapeLayer layer];
        _track.fillColor = UIColor.clearColor.CGColor;
        _track.strokeColor = [UIColor colorWithWhite:1 alpha:0.07].CGColor;
        _track.lineWidth = 10;
        _track.lineCap = kCALineCapRound;
        [self.layer addSublayer:_track];
        _progress = [CAShapeLayer layer];
        _progress.fillColor = UIColor.clearColor.CGColor;
        _progress.strokeColor = wq_neon_blue().CGColor;
        _progress.lineWidth = 10;
        _progress.lineCap = kCALineCapRound;
        _progress.strokeEnd = 0;
        _progress.shadowColor = wq_neon_blue().CGColor;
        _progress.shadowOpacity = 0.45;
        _progress.shadowRadius = 8;
        _progress.shadowOffset = CGSizeZero;
        [self.layer addSublayer:_progress];
        _percentLabel = [UILabel new];
        _percentLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _percentLabel.font = [UIFont monospacedDigitSystemFontOfSize:19 weight:UIFontWeightBold];
        _percentLabel.textColor = wq_neon_textPrimary();
        _percentLabel.textAlignment = NSTextAlignmentCenter;
        _percentLabel.text = @"—";
        [self addSubview:_percentLabel];
        [NSLayoutConstraint activateConstraints:@[
            [_percentLabel.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
            [_percentLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor],
        ]];
        [self.widthAnchor constraintEqualToConstant:104].active = YES;
        [self.heightAnchor constraintEqualToConstant:104].active = YES;
    }
    return self;
}

- (void)updatePaths
{
    CGRect inset = CGRectInset(self.bounds, 7, 7);
    UIBezierPath *circle = [UIBezierPath bezierPathWithArcCenter:CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds))
        radius:CGRectGetWidth(inset) / 2 startAngle:-M_PI_2 endAngle:M_PI * 1.5 clockwise:YES];
    _track.path = circle.CGPath;
    _progress.path = circle.CGPath;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self updatePaths];
}

- (void)setFraction:(double)fraction animated:(BOOL)animated
{
    fraction = MIN(1.0, MAX(0.0, fraction));
    BOOL reduce = UIAccessibilityIsReduceMotionEnabled();
    [CATransaction begin];
    [CATransaction setDisableActions:!animated || reduce];
    _progress.strokeEnd = fraction;
    [CATransaction commit];
    _percentLabel.text = [NSString stringWithFormat:@"%.1f%%", fraction * 100];
}

@end

'''
text = text[:start] + ring + text[end:]

# 4) Storage card: ring left, used/total/label right (reference composition).
start = text.index("- (UIView *)buildStorageCard")
end = text.index("- (void)handleStorageTap", start)
card = r'''- (UIView *)buildStorageCard
{
    WQPrismGlassView *card = [[WQPrismGlassView alloc] initWithRadius:20];

    _storageRing = [WQNeonStorageRing new];

    UILabel *eyebrow = [UILabel new];
    eyebrow.text = WQLocalized(@"Storage Used");
    eyebrow.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    eyebrow.textColor = wq_neon_textSecondary();

    _storageValue = [UILabel new];
    _storageValue.text = @"—";
    _storageValue.font = [UIFont monospacedDigitSystemFontOfSize:26 weight:UIFontWeightBold];
    _storageValue.adjustsFontForContentSizeCategory = YES;
    _storageValue.textColor = wq_neon_textPrimary();
    _storageValue.adjustsFontSizeToFitWidth = YES;
    _storageValue.minimumScaleFactor = 0.6;
    _storageTotalLabel = [UILabel new];
    _storageTotalLabel.text = @"";
    _storageTotalLabel.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightMedium];
    _storageTotalLabel.textColor = wq_neon_textSecondary();

    UILabel *filesCaption = [UILabel new];
    filesCaption.text = WQLocalized(@"Local Files");
    filesCaption.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightMedium];
    filesCaption.textColor = wq_neon_textMuted();
    _filesValue = [UILabel new];
    _filesValue.text = @"—";
    _filesValue.font = [UIFont monospacedDigitSystemFontOfSize:12 weight:UIFontWeightSemibold];
    _filesValue.textColor = wq_neon_textSecondary();
    UIStackView *footer = [[UIStackView alloc] initWithArrangedSubviews:@[filesCaption, _filesValue]];
    footer.axis = UILayoutConstraintAxisHorizontal;
    footer.spacing = 6;
    footer.alignment = UIStackViewAlignmentCenter;

    UIStackView *valueRow = [[UIStackView alloc] initWithArrangedSubviews:@[_storageValue, _storageTotalLabel]];
    valueRow.axis = UILayoutConstraintAxisHorizontal;
    valueRow.spacing = 6;
    valueRow.alignment = UIStackViewAlignmentFirstBaseline;

    UIStackView *info = [[UIStackView alloc] initWithArrangedSubviews:@[eyebrow, valueRow, footer]];
    info.axis = UILayoutConstraintAxisVertical;
    info.alignment = UIStackViewAlignmentLeading;
    info.spacing = 5;

    UIStackView *row = [[UIStackView alloc] initWithArrangedSubviews:@[_storageRing, info]];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.axis = UILayoutConstraintAxisHorizontal;
    row.alignment = UIStackViewAlignmentCenter;
    row.spacing = 16;
    [row setContentHuggingPriority:UILayoutPriorityDefaultHigh forAxis:UILayoutConstraintAxisHorizontal];
    [card.contentView addSubview:row];
    [NSLayoutConstraint activateConstraints:@[
        [row.topAnchor constraintEqualToAnchor:card.contentView.topAnchor constant:16],
        [row.bottomAnchor constraintEqualToAnchor:card.contentView.bottomAnchor constant:-16],
        [row.leadingAnchor constraintEqualToAnchor:card.contentView.leadingAnchor constant:16],
        [row.trailingAnchor constraintLessThanOrEqualToAnchor:card.contentView.trailingAnchor constant:-16],
        [info.trailingAnchor constraintLessThanOrEqualToAnchor:card.contentView.trailingAnchor constant:-16],
    ]];

    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleStorageTap)];
    [card addGestureRecognizer:tap];
    card.userInteractionEnabled = YES;
    card.accessibilityLabel = WQLocalized(@"Storage Used");
    card.accessibilityTraits = UIAccessibilityTraitButton;
    return card;
}

'''
text = text[:start] + card + text[end:]

# 5) Tagline: Modern Dark identity.
text = text.replace('@"AURORA · 2026"', '@"MODERN DARK"')

# 6) Tool cards: calm #293444 border, no glow.
text = text.replace(
    """    card.layer.borderWidth = 1;
    card.layer.borderColor = [wq_neon_border() colorWithAlphaComponent:0.08].CGColor;
    WQPrismIconTile *icon = [[WQPrismIconTile alloc] initWithSymbol:symbol tone:tone size:40];""",
    """    card.layer.borderWidth = 1;
    card.layer.borderColor = wq_neon_border().CGColor;
    WQPrismIconTile *icon = [[WQPrismIconTile alloc] initWithSymbol:symbol tone:tone size:40];""")

# 7) Wide primary Clean action under the tool grid.
anchor = "    [_contentStack setCustomSpacing:16 afterView:[_contentStack.arrangedSubviews lastObject]];\n\n    [_contentStack addArrangedSubview:WQPrismSectionHeaderView(WQLocalized(@\"Recent Files\"), nil)];"
replacement = """    [_contentStack setCustomSpacing:16 afterView:[_contentStack.arrangedSubviews lastObject]];
    [_contentStack addArrangedSubview:[self buildPrimaryCleanButton]];
    [_contentStack setCustomSpacing:16 afterView:[_contentStack.arrangedSubviews lastObject]];

    [_contentStack addArrangedSubview:WQPrismSectionHeaderView(WQLocalized(@"Recent Files"), nil)];"""
if anchor in text:
    text = text.replace(anchor, replacement)

# 7b) Define the wide primary Clean action (Smart-Cleaning style).
tools_anchor = "- (UIView *)buildToolsGrid"
clean_method = r'''- (UIView *)buildPrimaryCleanButton
{
    UIButtonConfiguration *cfg = [UIButtonConfiguration filledButtonConfiguration];
    cfg.title = WQLocalized(@"Clean");
    cfg.image = [UIImage systemImageNamed:@"sparkles"];
    cfg.imagePadding = 8;
    cfg.baseBackgroundColor = wq_neon_blue();
    cfg.baseForegroundColor = UIColor.whiteColor;
    cfg.cornerStyle = UIButtonConfigurationCornerStyleCapsule;
    cfg.contentInsets = NSDirectionalEdgeInsetsMake(15, 20, 15, 20);
    __weak typeof(self) weakSelf = self;
    UIButton *button = [UIButton buttonWithConfiguration:cfg primaryAction:[UIAction actionWithHandler:^(UIAction *__unused a) {
        [weakSelf openCleaner];
    }]];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button.heightAnchor constraintGreaterThanOrEqualToConstant:50].active = YES;
    return button;
}

'''
if tools_anchor in text and "buildPrimaryCleanButton" not in text.split(tools_anchor)[0]:
    text = text.replace(tools_anchor, clean_method + tools_anchor, 1)

# 8) More button: calm circle, accent glyph, hairline border.
text = text.replace(
    """    moreCfg.baseForegroundColor = wq_neon_cyan();
    _moreButton = [UIButton buttonWithConfiguration:moreCfg primaryAction:[UIAction actionWithHandler:^(UIAction *__unused a) {
        [weakSelf toggleExtras];
    }]];
    _moreButton.translatesAutoresizingMaskIntoConstraints = NO;
    _moreButton.accessibilityLabel = WQLocalized(@"More");
    _moreButton.backgroundColor = wq_neon_surface();
    _moreButton.layer.cornerRadius = 21;
    _moreButton.layer.borderWidth = 1;
    _moreButton.layer.borderColor = [wq_neon_cyan() colorWithAlphaComponent:0.45].CGColor;""",
    """    moreCfg.baseForegroundColor = wq_neon_blue();
    _moreButton = [UIButton buttonWithConfiguration:moreCfg primaryAction:[UIAction actionWithHandler:^(UIAction *__unused a) {
        [weakSelf toggleExtras];
    }]];
    _moreButton.translatesAutoresizingMaskIntoConstraints = NO;
    _moreButton.accessibilityLabel = WQLocalized(@"More");
    _moreButton.backgroundColor = wq_neon_surface();
    _moreButton.layer.cornerRadius = 21;
    _moreButton.layer.borderWidth = 1;
    _moreButton.layer.borderColor = wq_neon_border().CGColor;""")

# 9) Tab bar: neutral chrome, accent selection.
text = text.replace(
    """    appearance.backgroundColor = wq_neon_backgroundDeep();
    UITabBarItemAppearance *item = appearance.stackedLayoutAppearance;
    item.selected.iconColor = wq_neon_cyan();
    item.selected.titleTextAttributes = @{NSForegroundColorAttributeName: wq_neon_cyan()};""",
    """    appearance.backgroundColor = wq_neon_background();
    UITabBarItemAppearance *item = appearance.stackedLayoutAppearance;
    item.selected.iconColor = wq_neon_blue();
    item.selected.titleTextAttributes = @{NSForegroundColorAttributeName: wq_neon_blue()};""")
text = text.replace("    self.tabBar.tintColor = wq_neon_cyan();", "    self.tabBar.tintColor = wq_neon_blue();")

# 10) Nav bar accent.
text = text.replace('    nav.backgroundColor = wq_neon_backgroundDeep();\n    nav.shadowColor = [wq_neon_border() colorWithAlphaComponent:0.06];',
                    '    nav.backgroundColor = wq_neon_background();\n    nav.shadowColor = wq_neon_border();')
text = text.replace("    self.navigationBar.tintColor = wq_neon_cyan();", "    self.navigationBar.tintColor = wq_neon_blue();")

# 11) Scene backdrop is handled in WQAuroraScene.m separately.
path.write_text(text, encoding="utf-8")
print("main.m updated for Modern Dark.")
