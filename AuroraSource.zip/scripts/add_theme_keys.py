#!/usr/bin/env python3
"""Append the two theme names (Neon / Gold) to every translation input."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NEW_KEYS = ["Neon", "Gold"]
TRANSLATIONS = {
    "en": ["Neon", "Gold"],
    "ar": ["نيون", "ذهبي"],
    "de": ["Neon", "Gold"],
    "es": ["Neón", "Dorado"],
    "fr": ["Néon", "Doré"],
    "it": ["Neon", "Oro"],
    "ko": ["네온", "골드"],
    "pl": ["Neon", "Złoty"],
    "pt-BR": ["Neon", "Dourado"],
    "ru": ["Неон", "Золотой"],
    "th": ["นีออน", "ทอง"],
    "tr": ["Neon", "Altın"],
    "ur": ["نیون", "سنہری"],
    "vi": ["Neon", "Vàng"],
    "zh-Hans": ["霓虹", "金色"],
}
DERIVED = {
    "pt-PT": ["Neon", "Dourado"],
    "zh-Hant": ["霓虹", "金色"],
}


def main():
    spec_path = ROOT / "scripts/aurora_strings.json"
    spec = json.loads(spec_path.read_text(encoding="utf-8"))
    if "Neon" in spec["keys"]:
        print("Theme keys already present.")
        return
    spec["keys"].extend(NEW_KEYS)
    for language, values in TRANSLATIONS.items():
        if language == "en":
            continue
        spec["translations"][language].extend(values)
    assert all(len(v) == len(spec["keys"]) for v in spec["translations"].values())
    spec_path.write_text(json.dumps(spec, indent=2, ensure_ascii=False), encoding="utf-8")

    derived_path = ROOT / "scripts/aurora_derived_languages.json"
    derived = json.loads(derived_path.read_text(encoding="utf-8"))
    for language, values in DERIVED.items():
        for key, value in zip(NEW_KEYS, values):
            derived[language]["additions"][key] = value
    derived_path.write_text(json.dumps(derived, indent=2, ensure_ascii=False), encoding="utf-8")
    print("Theme names added to 15 base and 2 derived languages.")


if __name__ == "__main__":
    main()
