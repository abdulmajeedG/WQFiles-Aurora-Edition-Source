// WQ Files – Aurora Edition. GPL-3.0-or-later.
// User-initiated download + the standard iOS share sheet. No signing secrets,
// installer URL schemes, certificate import, provisioning changes or auto retry.
#import "WQReleaseDownload.h"
#import "WQReleaseArtifact.h"
#import "WQUpdate.h"
#import "WQAurora.h"
#import "WQUI.h"

@implementation WQReleaseDownloadController {
    NSDictionary<NSString *, NSString *> *_release;
    NSURLSession *_session;
    NSURLSessionDownloadTask *_task;
    NSURL *_directory;
    NSURL *_ipa;
    WQAuroraProgressView *_ring;
    UILabel *_status;
    UIButton *_share;
    NSProgress *_validation;
    NSUInteger _redirects;
    BOOL _started, _closed;
}
- (instancetype)initWithRelease:(NSDictionary<NSString *, NSString *> *)release
{
    if ((self = [super initWithNibName:nil bundle:nil])) _release = [release copy];
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = WQLocalized(@"Download IPA");
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    wq_prism_install_background(self);
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:WQLocalized(@"Done")
        style:UIBarButtonItemStylePlain target:self action:@selector(close)];
    _ring = [WQAuroraProgressView new];
    _ring.translatesAutoresizingMaskIntoConstraints = NO;
    _ring.titleLabel.text = @"IPA";
    _ring.detailLabel.text = WQLocalized(@"Downloading…");
    _ring.accessibilityLabel = WQLocalized(@"Downloading…");
    _ring.indeterminate = YES;
    _status = [UILabel new];
    _status.numberOfLines = 0;
    _status.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    _status.adjustsFontForContentSizeCategory = YES;
    _status.textColor = UIColor.secondaryLabelColor;
    _status.textAlignment = NSTextAlignmentCenter;
    UILabel *notice = [UILabel new];
    notice.text = [NSString stringWithFormat:@"%@\n\n%@", WQLocalized(@"Not an Aurora Edition update."),
        WQLocalized(@"Signing must preserve an App Group. No certificate is requested here.")];
    notice.numberOfLines = 0;
    notice.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    notice.adjustsFontForContentSizeCategory = YES;
    notice.textColor = UIColor.secondaryLabelColor;
    notice.textAlignment = NSTextAlignmentCenter;
    UIButtonConfiguration *config = [UIButtonConfiguration filledButtonConfiguration];
    config.title = WQLocalized(@"Share with signing app");
    config.image = [UIImage systemImageNamed:@"square.and.arrow.up"];
    config.imagePadding = 8;
    _share = [UIButton buttonWithConfiguration:config primaryAction:nil];
    [_share addTarget:self action:@selector(shareIPA) forControlEvents:UIControlEventTouchUpInside];
    _share.enabled = NO;
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[_ring, _status, _share, notice]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.spacing = 22;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    UIScrollView *scroll = [UIScrollView new];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scroll];
    [scroll addSubview:stack];
    UILayoutGuide *safe = self.view.safeAreaLayoutGuide;
    [NSLayoutConstraint activateConstraints:@[
        [scroll.leadingAnchor constraintEqualToAnchor:safe.leadingAnchor],
        [scroll.trailingAnchor constraintEqualToAnchor:safe.trailingAnchor],
        [scroll.topAnchor constraintEqualToAnchor:safe.topAnchor],
        [scroll.bottomAnchor constraintEqualToAnchor:safe.bottomAnchor],
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:32],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-32],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor constant:24],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor constant:-24],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor constant:-48],
        [_ring.widthAnchor constraintEqualToConstant:180],
        [_ring.heightAnchor constraintEqualToAnchor:_ring.widthAnchor],
        [_status.widthAnchor constraintEqualToAnchor:stack.widthAnchor],
        [notice.widthAnchor constraintEqualToAnchor:stack.widthAnchor],
        [_share.widthAnchor constraintEqualToAnchor:stack.widthAnchor],
        [_share.heightAnchor constraintGreaterThanOrEqualToConstant:48],
    ]];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (!_started) { _started = YES; [self download]; }
}
- (void)download
{
    NSURL *url = wq_update_official_download_url(_release);
    if (!url) { [self fail]; return; }
    _directory = [NSURL fileURLWithPath:[NSTemporaryDirectory() stringByAppendingPathComponent:
        [@"WQAuroraDownload-" stringByAppendingString:NSUUID.UUID.UUIDString]] isDirectory:YES];
    if (![NSFileManager.defaultManager createDirectoryAtURL:_directory withIntermediateDirectories:NO
        attributes:@{NSFileProtectionKey: NSFileProtectionCompleteUntilFirstUserAuthentication} error:nil]) { [self fail]; return; }
    NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
    config.HTTPCookieStorage = nil;
    config.URLCredentialStorage = nil;
    config.URLCache = nil;
    config.HTTPShouldSetCookies = NO;
    config.timeoutIntervalForRequest = 30;
    config.timeoutIntervalForResource = 300;
    config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:NSOperationQueue.mainQueue];
    _ring.running = YES;
    _task = [_session downloadTaskWithURL:url];
    [_task resume];
}
- (void)URLSession:(NSURLSession *__unused)session task:(NSURLSessionTask *__unused)task
    willPerformHTTPRedirection:(NSHTTPURLResponse *__unused)response newRequest:(NSURLRequest *)request
    completionHandler:(void (^)(NSURLRequest *_Nullable))completionHandler
{
    NSURL *url = request.URL;
    BOOL host = [url.host.lowercaseString isEqual:@"release-assets.githubusercontent.com"]
        || [url.host.lowercaseString isEqual:@"objects.githubusercontent.com"];
    BOOL safe = ++_redirects <= 4 && host && [url.scheme.lowercaseString isEqual:@"https"]
        && !url.user.length && !url.password.length && !url.fragment.length && (!url.port || url.port.integerValue == 443)
        && ([url.path hasPrefix:@"/github-production-release-asset/"] || [url.path hasPrefix:@"/github-production-release-asset-2e65be/"]);
    completionHandler(safe ? request : nil);
}
- (void)URLSession:(NSURLSession *__unused)session downloadTask:(NSURLSessionDownloadTask *)task
    didWriteData:(int64_t)bytesWritten totalBytesWritten:(int64_t)written totalBytesExpectedToWrite:(int64_t)expected
{
    (void)bytesWritten;
    if (_closed) return;
    if (written > WQReleaseMaximumDownloadBytes || expected > WQReleaseMaximumDownloadBytes) { [task cancel]; [self fail]; return; }
    _ring.indeterminate = expected <= 0;
    if (expected > 0) {
        CGFloat value = (CGFloat)written / (CGFloat)expected;
        [_ring setProgress:value animated:YES];
        _ring.titleLabel.text = [NSNumberFormatter localizedStringFromNumber:@(MIN(1, value)) numberStyle:NSNumberFormatterPercentStyle];
    }
    _status.text = expected > 0 ? [NSString stringWithFormat:@"%@ / %@", wq_size_text((unsigned long long)written), wq_size_text((unsigned long long)expected)]
        : wq_size_text((unsigned long long)written);
}
- (void)URLSession:(NSURLSession *__unused)session downloadTask:(NSURLSessionDownloadTask *)task didFinishDownloadingToURL:(NSURL *)location
{
    NSHTTPURLResponse *response = [task.response isKindOfClass:NSHTTPURLResponse.class] ? (NSHTTPURLResponse *)task.response : nil;
    if (_closed || response.statusCode != 200) { if (!_closed) [self fail]; return; }
    _ipa = [_directory URLByAppendingPathComponent:@"WQFiles.ipa"];
    // NSURLSession removes its temp file after this delegate callback returns.
    if (![NSFileManager.defaultManager moveItemAtURL:location toURL:_ipa error:nil]) { [self fail]; return; }
    [NSFileManager.defaultManager setAttributes:@{NSFileProtectionKey: NSFileProtectionCompleteUntilFirstUserAuthentication}
        ofItemAtPath:_ipa.path error:nil];
    _ring.indeterminate = YES;
    _ring.titleLabel.text = @"IPA";
    _ring.detailLabel.text = WQLocalized(@"Preparing…");
    _status.text = WQLocalized(@"Preparing…");
    _validation = [NSProgress progressWithTotalUnitCount:1];
    NSProgress *validation = _validation;
    NSURL *ipa = _ipa;
    NSString *version = _release[@"version"];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        BOOL valid = wq_release_validate_ipa(ipa, version, validation);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (self->_closed) return;
            if (!valid) { [self fail]; return; }
            self->_ring.running = NO;
            self->_ring.indeterminate = NO;
            [self->_ring setProgress:1 animated:YES];
            self->_ring.detailLabel.text = WQLocalized(@"Ready to share");
            self->_status.text = WQLocalized(@"Ready to share");
            self->_share.enabled = YES;
            // Explicitly requested download-to-share flow; no silent installation.
            [self shareIPA];
        });
    });
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *__unused)task didCompleteWithError:(NSError *)error
{
    _task = nil;
    _session = nil;
    [session finishTasksAndInvalidate];
    if (error && !_closed) [self fail];
}
- (void)shareIPA
{
    if (_closed || !_share.enabled || self.presentedViewController || !self.view.window) return;
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[_ipa] applicationActivities:nil];
    share.popoverPresentationController.sourceView = _share;
    share.popoverPresentationController.sourceRect = _share.bounds;
    [self presentViewController:share animated:YES completion:nil];
}
- (void)fail
{
    _ring.running = NO;
    _ring.detailLabel.text = WQLocalized(@"Download failed");
    _status.text = WQLocalized(@"The download could not be verified. Please use the official release page.");
    _share.enabled = NO;
    // URLSession temp files and our private files are not exposed as usable IPAs.
    if (_ipa) [NSFileManager.defaultManager removeItemAtURL:_ipa error:nil];
    _ipa = nil;
}
- (void)close
{
    _closed = YES;
    [_validation cancel];
    [_task cancel];
    [_session invalidateAndCancel];
    _ring.running = NO;
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    if (self.navigationController.isBeingDismissed || self.isBeingDismissed) {
        _closed = YES;
        [_validation cancel];
        [_task cancel];
        [_session invalidateAndCancel];
        _ring.running = NO;
    }
}
- (void)dealloc
{
    [_session invalidateAndCancel];
    if (_directory) [NSFileManager.defaultManager removeItemAtURL:_directory error:nil];
}
@end
