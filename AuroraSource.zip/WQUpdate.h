// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
// Stable dotted numeric releases only. Rejects unknown/prerelease formats rather
// than guessing that a beta is newer. Missing trailing components mean zero.
BOOL wq_update_valid_version(NSString *version);
NSComparisonResult wq_update_compare_versions(NSString *left, NSString *right);
NSDictionary<NSString *, NSString *> *_Nullable wq_update_release_from_data(NSData *data);
BOOL wq_update_is_newer(NSDictionary<NSString *, NSString *> *release, NSUserDefaults *defaults);
NSURL *_Nullable wq_update_official_download_url(NSDictionary<NSString *, NSString *> *release);
void wq_update_dismiss(NSDictionary<NSString *, NSString *> *release);
@interface WQUpdateService : NSObject <NSURLSessionDataDelegate>
+ (instancetype)shared;
// Dependency injection for disposable URLProtocol fixtures, not a new endpoint.
- (instancetype)initWithDefaults:(NSUserDefaults *)defaults configuration:(NSURLSessionConfiguration *)configuration;
// Main thread. May deliver a cached value, then fresh data. No credentials/API.
- (void)check:(void (^)(NSDictionary<NSString *, NSString *> *release))completion;
@end
NS_ASSUME_NONNULL_END
