// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
// Original vector artwork drawn on-device. No remote artwork, web view or data scan.
#import "WQAurora.h"
#import "WQUI.h"

@interface WQAuroraSceneView : UIView
- (instancetype)initWithLandscape:(BOOL)landscape;
@end

@implementation WQAuroraSceneView {
    BOOL _landscape;
}
- (instancetype)initWithLandscape:(BOOL)landscape
{
    if ((self = [super initWithFrame:CGRectZero])) {
        _landscape = landscape;
        self.userInteractionEnabled = NO;
        self.accessibilityElementsHidden = YES;
        self.opaque = YES;
        self.contentMode = UIViewContentModeRedraw;
        [self registerForTraitChanges:@[UITraitUserInterfaceStyle.class, UITraitAccessibilityContrast.class]
            withAction:@selector(redraw)];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(redraw)
            name:@"WQPrismBackgroundChanged" object:nil];
    }
    return self;
}
- (void)redraw { [self setNeedsDisplay]; }
- (void)drawRect:(CGRect)rect
{
    (void)rect;
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    if (!ctx) return;
    CGFloat w = self.bounds.size.width, h = self.bounds.size.height;
    BOOL plain = wq_prism_plain_background();
    BOOL flat = plain || self.traitCollection.accessibilityContrast == UIAccessibilityContrastHigh;
    UIColor *base = flat ? UIColor.systemBackgroundColor : wq_neon_background();
    [base setFill];
    UIRectFill(self.bounds);
    if (flat || w <= 0 || h <= 0) return;
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    // Modern Dark base: #0D1117 → #111823.
    NSArray *colors = @[(id)wq_neon_background().CGColor, (id)wq_neon_backgroundDeep().CGColor];
    CGGradientRef wash = CGGradientCreateWithColors(space, (__bridge CFArrayRef)colors, NULL);
    CGContextDrawLinearGradient(ctx, wash, CGPointZero, CGPointMake(0, h), 0);
    // Ambient accent glow top (behind the gauge) and bottom (behind the tab bar),
    // exactly the composition of the reference; static, no animation.
    NSArray *top = @[(id)[wq_neon_blue() colorWithAlphaComponent:0.40].CGColor,
                     (id)[wq_neon_cyan() colorWithAlphaComponent:0.10].CGColor,
                     (id)[wq_neon_blue() colorWithAlphaComponent:0].CGColor];
    CGGradientRef topGlow = CGGradientCreateWithColors(space, (__bridge CFArrayRef)top, NULL);
    CGPoint topCenter = CGPointMake(w * 0.42, -h * 0.02);
    CGContextDrawRadialGradient(ctx, topGlow, topCenter, 0, topCenter, w * 1.05, 0);
    CGGradientRelease(topGlow);
    NSArray *bottom = @[(id)[wq_neon_blue() colorWithAlphaComponent:0.30].CGColor,
                        (id)[wq_neon_blue() colorWithAlphaComponent:0].CGColor];
    CGGradientRef bottomGlow = CGGradientCreateWithColors(space, (__bridge CFArrayRef)bottom, NULL);
    CGPoint bottomCenter = CGPointMake(w * 0.18, h * 1.02);
    CGContextDrawRadialGradient(ctx, bottomGlow, bottomCenter, 0, bottomCenter, w * 0.9, 0);
    CGGradientRelease(bottomGlow);
    CGGradientRelease(wash);
    CGColorSpaceRelease(space);
}
@end

UIView *wq_aurora_scene_view(BOOL landscape) { return [[WQAuroraSceneView alloc] initWithLandscape:landscape]; }

@implementation WQAuroraMetricControl {
    UILabel *_nameLabel;
    UIColor *_tint;
}
- (instancetype)initWithTitle:(NSString *)title symbol:(NSString *)symbol tint:(UIColor *)tint
{
    if ((self = [super initWithFrame:CGRectZero])) {
        _tint = tint;
        self.translatesAutoresizingMaskIntoConstraints = NO;
        self.layer.cornerRadius = 15;
        self.layer.cornerCurve = kCACornerCurveContinuous;
        self.isAccessibilityElement = YES;
        self.accessibilityLabel = title;
        self.accessibilityTraits = UIAccessibilityTraitButton;
        UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:symbol
            withConfiguration:[UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold]]];
        icon.tintColor = tint;
        icon.contentMode = UIViewContentModeScaleAspectFit;
        icon.translatesAutoresizingMaskIntoConstraints = NO;
        [icon.widthAnchor constraintEqualToConstant:18].active = YES;
        [icon.heightAnchor constraintEqualToConstant:18].active = YES;
        _valueLabel = [UILabel new];
        _valueLabel.text = @"—";
        _valueLabel.textColor = UIColor.labelColor;
        _valueLabel.textAlignment = NSTextAlignmentCenter;
        _valueLabel.font = [[UIFontMetrics metricsForTextStyle:UIFontTextStyleSubheadline]
            scaledFontForFont:[UIFont systemFontOfSize:15 weight:UIFontWeightSemibold]];
        _valueLabel.adjustsFontForContentSizeCategory = YES;
        _valueLabel.adjustsFontSizeToFitWidth = YES;
        _valueLabel.minimumScaleFactor = 0.7;
        _nameLabel = [UILabel new];
        _nameLabel.text = title;
        _nameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption2];
        _nameLabel.adjustsFontForContentSizeCategory = YES;
        _nameLabel.numberOfLines = 1;
        _nameLabel.adjustsFontSizeToFitWidth = YES;
        _nameLabel.minimumScaleFactor = 0.75;
        _nameLabel.textAlignment = NSTextAlignmentCenter;
        _nameLabel.textColor = UIColor.secondaryLabelColor;
        UIStackView *column = [[UIStackView alloc] initWithArrangedSubviews:@[icon, _valueLabel, _nameLabel]];
        column.translatesAutoresizingMaskIntoConstraints = NO;
        column.axis = UILayoutConstraintAxisVertical;
        column.alignment = UIStackViewAlignmentCenter;
        column.spacing = 4;
        column.userInteractionEnabled = NO;
        [self addSubview:column];
        [NSLayoutConstraint activateConstraints:@[
            [column.topAnchor constraintEqualToAnchor:self.topAnchor constant:11],
            [column.bottomAnchor constraintEqualToAnchor:self.bottomAnchor constant:-9],
            [column.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:4],
            [column.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-4],
            [self.heightAnchor constraintGreaterThanOrEqualToConstant:74],
        ]];
        [self registerForTraitChanges:@[UITraitUserInterfaceStyle.class, UITraitAccessibilityContrast.class]
            withAction:@selector(updateSurface)];
        [NSNotificationCenter.defaultCenter addObserver:self selector:@selector(updateSurface)
            name:UIAccessibilityReduceTransparencyStatusDidChangeNotification object:nil];
        [self updateSurface];
    }
    return self;
}
- (void)updateSurface
{
    self.backgroundColor = wq_aurora_surface();
    BOOL dark = self.traitCollection.userInterfaceStyle == UIUserInterfaceStyleDark;
    self.layer.borderColor = [UIColor colorWithWhite:dark ? 1 : 0 alpha:dark ? 0.07 : 0.08].CGColor;
    self.layer.borderWidth = 0.5;
}
- (void)setCaption:(NSString *)caption
{
    _nameLabel.text = caption;
}
- (NSString *)accessibilityValue { return _valueLabel.text; }
- (void)setHighlighted:(BOOL)highlighted
{
    [super setHighlighted:highlighted];
    BOOL reduce = UIAccessibilityIsReduceMotionEnabled();
    [UIView animateWithDuration:reduce ? 0 : 0.14 delay:0 usingSpringWithDamping:0.82 initialSpringVelocity:0
        options:UIViewAnimationOptionAllowUserInteraction
        animations:^{ self.alpha = highlighted ? 0.75 : 1; } completion:nil];
    [UIView animateWithDuration:reduce ? 0 : 0.18 delay:0 usingSpringWithDamping:0.75 initialSpringVelocity:0.4
        options:UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionBeginFromCurrentState
        animations:^{ self.transform = highlighted ? CGAffineTransformMakeScale(0.965, 0.965) : CGAffineTransformIdentity; }
        completion:nil];
}
@end
