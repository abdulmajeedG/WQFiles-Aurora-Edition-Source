// Offline Foundation fixtures. No requests reach GitHub. GPL-3.0-or-later.
#import <Foundation/Foundation.h>
#import "WQUpdate.h"
#import "WQReleaseArtifact.h"
#import "WQArchive.h"
#import <mach-o/loader.h>
#import <mach/machine.h>

static void expect(BOOL ok, NSString *message)
{
    if (!ok) { fprintf(stderr, "FAIL: %s\n", message.UTF8String); exit(1); }
}
static NSData *json(id value) { return [NSJSONSerialization dataWithJSONObject:value options:0 error:nil]; }
static NSDictionary *catalog(NSArray *versions)
{
    return @{@"apps": @[@{@"bundleIdentifier": @"cz.kolbi.wqfiles", @"versions": versions}]};
}

static void artifact_fixtures(void)
{
    NSString *root = [NSTemporaryDirectory() stringByAppendingPathComponent:[@"WQUpdateFixture-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    NSString *payload = [root stringByAppendingPathComponent:@"Payload"];
    NSString *app = [payload stringByAppendingPathComponent:@"WQFiles.app"];
    expect([NSFileManager.defaultManager createDirectoryAtPath:app withIntermediateDirectories:YES attributes:nil error:nil], @"fixture directory");
    struct mach_header_64 header = {.magic = MH_MAGIC_64, .cputype = CPU_TYPE_ARM64, .filetype = MH_EXECUTE};
    expect([[NSData dataWithBytes:&header length:sizeof(header)] writeToFile:[app stringByAppendingPathComponent:@"WQFiles"] atomically:YES], @"fixture executable header");
    NSDictionary *info = @{@"CFBundleIdentifier": @"cz.kolbi.wqfiles", @"CFBundleExecutable": @"WQFiles", @"CFBundleShortVersionString": @"0.9.11"};
    expect([info writeToFile:[app stringByAppendingPathComponent:@"Info.plist"] atomically:YES], @"fixture plist");
    NSString *zip = [root stringByAppendingPathComponent:@"fixture.ipa"];
    expect(wq_zip_write(@[payload], zip, wq_archive_posix_io(), nil, nil, NULL, NULL), @"fixture ZIP");
    NSURL *file = [NSURL fileURLWithPath:zip];
    NSProgress *progress = [NSProgress progressWithTotalUnitCount:1];
    // This fixture validates structure/metadata only, not a runnable signed app.
    expect(wq_release_validate_ipa(file, @"0.9.11", progress), @"matching IPA structure");
    expect(!wq_release_validate_ipa(file, @"0.9.12", progress), @"wrong release version rejected");
    [progress cancel];
    expect(!wq_release_validate_ipa(file, @"0.9.11", progress), @"cancelled validation");
    [@"not an IPA" writeToFile:zip atomically:YES encoding:NSUTF8StringEncoding error:nil];
    expect(!wq_release_validate_ipa(file, @"0.9.11", [NSProgress progressWithTotalUnitCount:1]), @"invalid archive refused");
    [NSFileManager.defaultManager removeItemAtPath:root error:nil];
}

static NSUInteger requests;
@interface WQUpdateProtocol : NSURLProtocol
@end
@implementation WQUpdateProtocol
+ (BOOL)canInitWithRequest:(NSURLRequest *__unused)request { return YES; }
+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request { return request; }
- (void)startLoading
{
    @synchronized (WQUpdateProtocol.class) { requests++; }
    expect([self.request.URL.absoluteString isEqual:@"https://raw.githubusercontent.com/kolbicz/WQFiles/main/source.json"], @"fixed upstream URL");
    expect([self.request valueForHTTPHeaderField:@"Authorization"] == nil, @"no authorization");
    NSHTTPURLResponse *response = [[NSHTTPURLResponse alloc] initWithURL:self.request.URL statusCode:200
        HTTPVersion:@"HTTP/1.1" headerFields:@{@"ETag": @"\"fixture\""}];
    [self.client URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageNotAllowed];
    [self.client URLProtocol:self didLoadData:json(catalog(@[@{@"version": @"0.9.11", @"localizedDescription": @"Fixture notes"}]))];
    [self.client URLProtocolDidFinishLoading:self];
}
- (void)stopLoading {}
@end

int main(void)
{
    @autoreleasepool {
        for (id invalid in @[@"", @"v1.0", @"1..2", @"1.0-beta", @"-1", @"1/2", @"1.٢", @"1234567890", NSNull.null])
            expect(!wq_update_valid_version(invalid), @"invalid version rejected");
        expect(wq_update_compare_versions(@"0.9.10", @"0.9.9") == NSOrderedDescending, @"numeric ordering");
        expect(wq_update_compare_versions(@"1.0.0", @"1") == NSOrderedSame, @"zero padding");
        expect(wq_update_compare_versions(@"01.002", @"1.2") == NSOrderedSame, @"leading zeros");
        expect(wq_update_compare_versions(@"1.0", @"2") == NSOrderedAscending, @"major ordering");
        expect(wq_update_release_from_data([@"broken" dataUsingEncoding:NSUTF8StringEncoding]) == nil, @"bad JSON");
        expect(wq_update_release_from_data(json(@{@"apps": @"bad"})) == nil, @"bad apps shape");
        expect(wq_update_release_from_data([NSMutableData dataWithLength:1024 * 1024 + 1]) == nil, @"bounded parser");
        expect(wq_update_release_from_data(json(@{@"apps": @[@{@"bundleIdentifier": @"other", @"version": @"999"}]})) == nil, @"unrelated app ignored");
        NSDictionary *release = wq_update_release_from_data(json(catalog(@[
            @{@"version": @"0.9.9"}, @{@"version": @"0.9.11", @"localizedDescription": @"Notes"},
            @{@"version": @"0.9.10"}, @{@"version": @"1.0-beta"}, @{@"version": NSNull.null}])));
        expect([release[@"version"] isEqual:@"0.9.11"], @"newest stable entry, not array position");
        expect([release[@"notes"] isEqual:@"Notes"], @"release notes retained");
        NSDictionary *legacy = wq_update_release_from_data(json(@{@"apps": @[@{
            @"bundleIdentifier": @"cz.kolbi.wqfiles", @"version": @"1.0", @"downloadURL": @"https://untrusted.invalid/payload"}]}));
        expect([legacy[@"version"] isEqual:@"1.0"], @"legacy source supported");
        expect([legacy[@"url"] isEqual:@"https://github.com/kolbicz/WQFiles/releases/latest"], @"no feed-provided download");
        expect(wq_update_official_download_url(legacy) == nil, @"untrusted IPA URL refused");
        NSDictionary *download = wq_update_release_from_data(json(catalog(@[@{@"version": @"0.9.11",
            @"downloadURL": @"https://github.com/kolbicz/WQFiles/releases/download/v0.9.11/WQFiles.ipa"}])));
        expect(wq_update_official_download_url(download) != nil, @"official versioned asset accepted");
        for (NSString *url in @[@"http://github.com/kolbicz/WQFiles/releases/download/v0.9.11/WQFiles.ipa",
            @"https://github.com/other/WQFiles/releases/download/v0.9.11/WQFiles.ipa",
            @"https://github.com/kolbicz/WQFiles/releases/download/v0.9.12/WQFiles.ipa",
            @"https://github.com/kolbicz/WQFiles/releases/download/v0.9.11/WQFiles.ipa?redirect=1"]) {
            expect(wq_update_official_download_url(@{@"version": @"0.9.11", @"downloadURL": url}) == nil, @"altered download URL refused");
        }
        artifact_fixtures();

        NSString *suite = [@"WQAuroraFixture." stringByAppendingString:NSUUID.UUID.UUIDString];
        NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:suite];
        expect(wq_update_is_newer(release, defaults), @"upstream newer than base");
        [defaults setObject:@"0.9.11" forKey:@"WQUpstreamDismissedVersion"];
        expect(!wq_update_is_newer(release, defaults), @"version dismissal remembered");
        expect(wq_update_is_newer(legacy, defaults), @"later version can notify");
        [defaults setBool:YES forKey:@"WQUpdateCheckOff"];
        expect(!wq_update_is_newer(legacy, defaults), @"disabled means no banner");
        NSURLSessionConfiguration *config = NSURLSessionConfiguration.ephemeralSessionConfiguration;
        config.protocolClasses = @[WQUpdateProtocol.class];
        WQUpdateService *service = [[WQUpdateService alloc] initWithDefaults:defaults configuration:config];
        [service check:^(NSDictionary *__unused r) { expect(NO, @"disabled check must not call"); }];
        expect(requests == 0, @"disabled means no network");
        [defaults setBool:NO forKey:@"WQUpdateCheckOff"];
        __block NSUInteger callbacks = 0;
        [service check:^(NSDictionary *r) { expect([r[@"version"] isEqual:@"0.9.11"], @"transport parser"); callbacks++; }];
        [service check:^(NSDictionary *__unused r) { callbacks++; }];
        NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:5];
        while (callbacks < 2 && deadline.timeIntervalSinceNow > 0)
            [NSRunLoop.currentRunLoop runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.01]];
        expect(callbacks == 2, @"joined callbacks completed");
        expect(requests == 1, @"in-flight request coalesced");
        [service check:^(NSDictionary *__unused r) { callbacks++; }];
        expect(callbacks == 3 && requests == 1, @"12h cached result without network");
        expect([[defaults stringForKey:@"WQUpstreamETag"] isEqual:@"\"fixture\""], @"ETag retained");
        expect([[defaults objectForKey:@"WQUpstreamNextCheck"] timeIntervalSinceNow] > 11 * 3600, @"attempt cached");
        [defaults removePersistentDomainForName:suite];
        puts("WQUpdateTests: PASS (offline parser, policy, transport and cache fixtures)");
    }
    return 0;
}
