// Disposable local defaults only. No installed app or filesystem mutation.
#import <Foundation/Foundation.h>
#import "WQRecent.h"
static void expect(BOOL value, NSString *label)
{
    if (!value) { fprintf(stderr, "FAIL: %s\n", label.UTF8String); exit(1); }
}
int main(void)
{
    @autoreleasepool {
        NSString *suite = [@"WQRecentFixture." stringByAppendingString:NSUUID.UUID.UUIDString];
        NSUserDefaults *defaults = [[NSUserDefaults alloc] initWithSuiteName:suite];
        WQRecentStore *store = [[WQRecentStore alloc] initWithDefaults:defaults];
        expect(!store.enabled, @"history disabled by default");
        [store recordPath:@"/fixture/private.txt" readOnly:YES];
        expect(store.entries.count == 0 && [defaults objectForKey:@"WQAuroraRecentEntries"] == nil, @"no implicit history");
        store.enabled = YES;
        for (NSUInteger i = 0; i < 20; i++) [store recordPath:[NSString stringWithFormat:@"/fixture/%lu.txt", (unsigned long)i] readOnly:NO];
        expect(store.entries.count == 12, @"bounded history");
        expect([store.entries[0][@"path"] isEqual:@"/fixture/19.txt"], @"newest first");
        [store recordPath:@"/fixture/./10.txt" readOnly:YES];
        expect(store.entries.count == 12 && [store.entries[0][@"path"] isEqual:@"/fixture/10.txt"], @"deduplicate normalized path");
        expect([store.entries[0][@"readOnly"] boolValue], @"read-only capability retained");
        for (NSDictionary *entry in store.entries) expect(entry.count == 3, @"no file contents collected");
        [store recordPath:@"relative.txt" readOnly:NO];
        expect([store.entries[0][@"path"] isEqual:@"/fixture/10.txt"], @"relative paths refused");
        WQRecentStore *reloaded = [[WQRecentStore alloc] initWithDefaults:defaults];
        expect(reloaded.enabled && reloaded.entries.count == 12, @"local settings persisted");
        store.enabled = NO;
        expect(store.entries.count == 0 && [defaults objectForKey:@"WQAuroraRecentEntries"] == nil, @"disabling erases history");
        store.enabled = YES;
        [defaults setObject:@[@"invalid", @{@"path": @"relative", @"date": NSDate.date, @"readOnly": @NO},
            @{@"path": @"/fixture/file", @"date": @"bad", @"readOnly": @NO}] forKey:@"WQAuroraRecentEntries"];
        expect(store.entries.count == 0, @"malformed cached entries rejected");
        [store recordPath:@"/fixture/one.txt" readOnly:NO];
        [store clear];
        expect(store.enabled && store.entries.count == 0, @"clear does not disable preference");
        [defaults removePersistentDomainForName:suite];
        puts("WQRecentTests: PASS (opt-in, bounds, ordering, deduplication, read-only, clearing and corrupt cache)");
    }
    return 0;
}
