"""Static wiring/security checks, NOT UIKit execution or an iOS build."""
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(name):
    return (ROOT / name).read_text(encoding="utf-8")


class AuroraStaticContracts(unittest.TestCase):
    def test_new_sources_are_in_both_compile_paths(self):
        for name in ("WQAurora.m", "WQAuroraScene.m", "WQAuroraProgress.m", "WQRecent.m", "WQUpdate.m", "WQReleaseArtifact.m", "WQReleaseDownload.m"):
            self.assertIn(name, source("build.sh"))
            self.assertIn(name, source("tests/run_all_tests.sh"))
            self.assertTrue((ROOT / name).is_file())

    def test_ring_lifecycle_and_accessibility_guards_are_wired(self):
        ring = source("WQAuroraProgress.m")
        for guard in ("UIAccessibilityIsReduceMotionEnabled()", "didMoveToWindow", "UIApplicationWillResignActiveNotification",
                      "UIApplicationDidBecomeActiveNotification", "removeAnimationForKey", "isfinite(progress)"):
            self.assertIn(guard, ring)
        self.assertNotIn("NSTimer", ring)
        self.assertNotIn("dispatch_after", ring)

    def test_clean_progress_and_stop_are_real_operation_callbacks(self):
        cache = source("WQCache.m")
        self.assertIn("self->_cleanProgress = completed", cache)
        self.assertIn("(float)i / (float)selected.count", cache)
        self.assertIn("[_cleanCancellation cancel]", cache)
        self.assertIn("WQCacheValidateItem(item", cache)
        self.assertIn("wq_purge_contents_cancellable", cache)
        self.assertIn("configureSummaryCell:cell", cache)

    def test_app_scan_ring_uses_existing_scan_state(self):
        apps = source("WQApps.m")
        self.assertIn("BOOL active = _scanning && !_scanCancellation.isCancelled", apps)
        self.assertIn("_scanIndicator.running = NO", apps)
        self.assertIn("_scanIndicator.indeterminate = YES", apps)

    def test_update_network_implementation_is_not_duplicated_in_home(self):
        self.assertEqual(source("main.m").count("[[WQUpdateService shared] check:"), 2)
        self.assertNotIn("dataTaskWithURL", source("main.m"))
        update = source("WQUpdate.m")
        self.assertIn("12 * 3600", update)
        self.assertIn("If-None-Match", update)
        self.assertIn("WQUpstreamNextCheck", update)

    def test_download_is_separate_and_user_initiated(self):
        self.assertNotIn("downloadTask", source("WQUpdate.m"))
        ui = source("WQAurora.m")
        self.assertIn('wq_alert_action(@"Download IPA"', ui)
        self.assertIn("wq_update_official_download_url(release)", ui)
        download = source("WQReleaseDownload.m")
        self.assertIn("UIActivityViewController", download)
        self.assertIn("@[_ipa]", download)
        for forbidden in ("itms-services:", "SecPKCS12Import", ".p12", "embedded.mobileprovision", "Authorization"):
            self.assertNotIn(forbidden, download)

    def test_download_has_bounds_and_no_auto_retry(self):
        download = source("WQReleaseDownload.m")
        self.assertIn("WQReleaseMaximumDownloadBytes", download)
        self.assertIn("_redirects <= 4", download)
        self.assertIn("config.URLCredentialStorage = nil", download)
        self.assertIn("config.timeoutIntervalForResource = 300", download)
        self.assertIn("wq_release_validate_ipa", download)
        self.assertNotIn("NSTimer", download)
        self.assertNotIn("dispatch_after", download)

    def test_artifact_validation_uses_existing_safe_archive_reader(self):
        artifact = source("WQReleaseArtifact.m")
        for check in ("wq_zip_extract", "128ull * 1024 * 1024", "!skipped", "CFBundleIdentifier",
                      "wq_update_compare_versions", "CPU_TYPE_ARM64", "O_NOFOLLOW", "cancellation.cancelled"):
            self.assertIn(check, artifact)

    def test_generated_aurora_translation_inputs_cover_all_bundled_tables(self):
        data = json.loads(source("scripts/aurora_strings.json"))
        dashboard = json.loads(source("scripts/aurora_dashboard_strings.json"))
        for language, values in data["translations"].items():
            self.assertEqual(len(values), len(data["keys"]), language)
            self.assertEqual(len(data["download_translations"][language]), len(data["download_keys"]), language)
            self.assertEqual(len(dashboard["translations"][language]), len(dashboard["keys"]), language)

    def test_hosted_build_is_manual_bounded_read_only_and_private_only(self):
        workflow = source(".github/workflows/aurora-manual-build.yml")
        self.assertIn("workflow_dispatch:", workflow)
        for event in ("push:", "pull_request:", "schedule:", "workflow_run:"):
            self.assertNotIn(event, workflow)
        self.assertIn("timeout-minutes: 30", workflow)
        self.assertIn("&& github.event.repository.private", workflow)
        self.assertIn("inputs.free_usage_confirmed", workflow)
        self.assertIn("'abdulmajeedG/WQFiles-Aurora-Edition'", workflow)
        self.assertIn("retention-days: 1", workflow)
        self.assertIn("contents: read", workflow)
        self.assertIn("persist-credentials: false", workflow)
        self.assertNotIn("secrets.", workflow)
        self.assertNotIn("gh release", workflow)
        actions = re.findall(r"uses:\s+(\S+)", workflow)
        self.assertEqual(len(actions), 2)
        for action in actions:
            self.assertRegex(action, r"^actions/(checkout|upload-artifact)@[0-9a-f]{40}$")

    def test_dashboard_uses_measured_metrics_not_demo_values(self):
        main = source("main.m")
        dashboard = main.split("- (void)refreshMetrics", 1)[1].split("- (void)rebuildRecent", 1)[0]
        for operation in ("WQAuroraAppCount", "enumeratorAtURL", "NSURLFileSizeKey", "attributesOfFileSystemForPath"):
            self.assertIn(operation, dashboard)
        for fake in ('@"1,248"', '@"68.5 GB"', '@"42"'):
            self.assertNotIn(fake, dashboard)
        self.assertIn("@[homeNav, appsNav, favoritesNav, filesNav]", main)
        # Quick actions route to real navigation actions (no fabricated data).
        self.assertIn("case 0: [self openFiles]", main)
        self.assertIn("case 1: [self openApps]", main)
        self.assertIn("case 2: [self openFavorites]", main)
        self.assertIn("case 3: [self openCleaner]", main)

    def test_recent_history_is_opt_in_local_bounded_and_preserves_read_only(self):
        recent = source("WQRecent.m")
        self.assertIn("boolForKey:WQRecentEnabled", recent)
        self.assertNotIn("registerDefaults", recent)
        self.assertIn("if (!enabled) [self clear]", recent)
        self.assertIn("entries.count == 12", recent)
        self.assertIn('@"readOnly": @(readOnly)', recent)
        for remote in ("NSURLSession", "HTTP", "uploadTask", "dataTask"):
            self.assertNotIn(remote, recent)

    def test_artwork_is_native_and_respects_plain_background_and_contrast(self):
        scene = source("WQAuroraScene.m")
        self.assertIn("CGContextDrawLinearGradient", scene)
        self.assertIn("wq_prism_plain_background()", scene)
        self.assertIn("UIAccessibilityContrastHigh", scene)
        self.assertNotIn("WKWebView", scene)
        self.assertNotIn("NSURLSession", scene)
        self.assertIn("return wq_aurora_scene_view(NO)", source("WQUI.m"))


if __name__ == "__main__":
    unittest.main()
