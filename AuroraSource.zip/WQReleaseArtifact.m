// WQ Files – Aurora Edition. GPL-3.0-or-later.
#import "WQReleaseArtifact.h"
#import "WQArchive.h"
#import "WQUpdate.h"
#import <fcntl.h>
#import <unistd.h>
#import <string.h>
#import <mach-o/loader.h>
#import <mach/machine.h>

BOOL wq_release_validate_ipa(NSURL *file, NSString *version, NSProgress *cancellation)
{
    if (!wq_update_valid_version(version) || cancellation.cancelled) return NO;
    NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:file.path error:nil];
    unsigned long long size = [attributes[NSFileSize] unsignedLongLongValue];
    if (![attributes[NSFileType] isEqual:NSFileTypeRegular] || size < 22 || size > WQReleaseMaximumDownloadBytes) return NO;
    NSString *check = [NSTemporaryDirectory() stringByAppendingPathComponent:[@"WQAuroraIPA-" stringByAppendingString:NSUUID.UUID.UUIDString]];
    if (![NSFileManager.defaultManager createDirectoryAtPath:check withIntermediateDirectories:NO attributes:nil error:nil]) return NO;
    NSUInteger files = 0, skipped = 0;
    BOOL extracted = wq_zip_extract(file.path, check, wq_archive_posix_io(), 128ull * 1024 * 1024,
        ^BOOL { return cancellation.cancelled; }, nil, &files, &skipped, nil);
    BOOL valid = NO;
    if (extracted && files && !skipped && !cancellation.cancelled) {
        NSString *app = [check stringByAppendingPathComponent:@"Payload/WQFiles.app"];
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[app stringByAppendingPathComponent:@"Info.plist"]];
        id actualVersion = info[@"CFBundleShortVersionString"];
        BOOL metadata = [info[@"CFBundleIdentifier"] isEqual:@"cz.kolbi.wqfiles"]
            && [info[@"CFBundleExecutable"] isEqual:@"WQFiles"] && wq_update_valid_version(actualVersion)
            && wq_update_compare_versions(actualVersion, version) == NSOrderedSame;
        if (metadata) {
            int fd = open([app stringByAppendingPathComponent:@"WQFiles"].fileSystemRepresentation, O_RDONLY | O_NOFOLLOW);
            struct mach_header_64 header = {0};
            ssize_t count = fd >= 0 ? read(fd, &header, sizeof(header)) : -1;
            if (fd >= 0) close(fd);
            valid = count == (ssize_t)sizeof(header) && header.magic == MH_MAGIC_64
                && header.cputype == CPU_TYPE_ARM64 && header.filetype == MH_EXECUTE;
        }
    }
    // Only our UUID-named private extraction folder is removed, never app data.
    [NSFileManager.defaultManager removeItemAtPath:check error:nil];
    return valid && !cancellation.cancelled;
}
