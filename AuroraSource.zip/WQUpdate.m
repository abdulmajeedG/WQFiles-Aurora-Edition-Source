// WQ Files – Aurora Edition. Modified 2026-11-15. GPL-3.0-or-later.
// Retains the original source.json check. Downloading is a separate explicit action.
#import "WQUpdate.h"

static const NSTimeInterval WQUpdateInterval = 12 * 3600;
static const NSUInteger WQUpdateLimit = 1024 * 1024;
static NSString *const WQUpdateURL = @"https://raw.githubusercontent.com/kolbicz/WQFiles/main/source.json";

BOOL wq_update_valid_version(NSString *version)
{
    if (![version isKindOfClass:NSString.class] || !version.length || version.length > 40) return NO;
    NSArray<NSString *> *parts = [version componentsSeparatedByString:@"."];
    if (parts.count > 8) return NO;
    NSCharacterSet *invalid = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet];
    for (NSString *part in parts) {
        if (!part.length || part.length > 9 || [part rangeOfCharacterFromSet:invalid].location != NSNotFound) return NO;
    }
    return YES;
}

NSComparisonResult wq_update_compare_versions(NSString *left, NSString *right)
{
    if (!wq_update_valid_version(left) || !wq_update_valid_version(right)) return NSOrderedSame;
    NSArray<NSString *> *a = [left componentsSeparatedByString:@"."], *b = [right componentsSeparatedByString:@"."];
    for (NSUInteger i = 0; i < MAX(a.count, b.count); i++) {
        long long x = i < a.count ? a[i].longLongValue : 0, y = i < b.count ? b[i].longLongValue : 0;
        if (x != y) return x > y ? NSOrderedDescending : NSOrderedAscending;
    }
    return NSOrderedSame;
}

static NSString *wq_update_notes(id value)
{
    if ([value isKindOfClass:NSDictionary.class]) {
        NSMutableArray<NSString *> *languages = [NSMutableArray new];
        for (id key in [value allKeys]) if ([key isKindOfClass:NSString.class]) [languages addObject:key];
        NSArray *preferred = [NSBundle preferredLocalizationsFromArray:languages];
        value = value[preferred.firstObject ?: @"en"] ?: value[@"en"];
    }
    // Source notes are untrusted plain text, never HTML or executable content.
    if (![value isKindOfClass:NSString.class]) return @"";
    NSString *text = value;
    if (text.length > 4000) text = [text substringToIndex:4000];
    return text;
}

NSDictionary<NSString *, NSString *> *wq_update_release_from_data(NSData *data)
{
    if (!data.length || data.length > WQUpdateLimit) return nil;
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    id apps = [json isKindOfClass:NSDictionary.class] ? json[@"apps"] : nil;
    if (![apps isKindOfClass:NSArray.class]) return nil;
    NSDictionary *best = nil;
    for (id app in apps) {
        if (![app isKindOfClass:NSDictionary.class] || ![app[@"bundleIdentifier"] isEqual:@"cz.kolbi.wqfiles"]) continue;
        id versions = app[@"versions"];
        NSArray *candidates = [versions isKindOfClass:NSArray.class] ? versions : @[app];
        for (id candidate in candidates) {
            if (![candidate isKindOfClass:NSDictionary.class]) continue;
            id version = candidate[@"version"];
            if (!wq_update_valid_version(version)) continue;
            if (best && wq_update_compare_versions(version, best[@"version"]) != NSOrderedDescending) continue;
            NSMutableDictionary *entry = [@{@"version": version, @"notes": wq_update_notes(candidate[@"localizedDescription"]),
                @"url": @"https://github.com/kolbicz/WQFiles/releases/latest"} mutableCopy];
            NSString *expected = [NSString stringWithFormat:@"https://github.com/kolbicz/WQFiles/releases/download/v%@/WQFiles.ipa", version];
            if ([candidate[@"downloadURL"] isKindOfClass:NSString.class] && [candidate[@"downloadURL"] isEqual:expected])
                entry[@"downloadURL"] = expected;
            best = entry;
        }
    }
    return best;
}

BOOL wq_update_is_newer(NSDictionary<NSString *, NSString *> *release, NSUserDefaults *defaults)
{
    if ([defaults boolForKey:@"WQUpdateCheckOff"]) return NO;
    NSString *version = release[@"version"];
    if (!wq_update_valid_version(version)) return NO;
    // Aurora's marketing version must never be compared to upstream's version.
    NSString *base = NSBundle.mainBundle.infoDictionary[@"WQUpstreamVersion"] ?: @"0.9.10";
    return wq_update_compare_versions(version, base) == NSOrderedDescending
        && ![version isEqualToString:[defaults stringForKey:@"WQUpstreamDismissedVersion"]];
}

NSURL *wq_update_official_download_url(NSDictionary<NSString *, NSString *> *release)
{
    if (!wq_update_valid_version(release[@"version"])) return nil;
    NSString *expected = [NSString stringWithFormat:@"https://github.com/kolbicz/WQFiles/releases/download/v%@/WQFiles.ipa", release[@"version"]];
    return [release[@"downloadURL"] isKindOfClass:NSString.class] && [release[@"downloadURL"] isEqual:expected]
        ? [NSURL URLWithString:expected] : nil;
}

void wq_update_dismiss(NSDictionary<NSString *, NSString *> *release)
{
    if (wq_update_valid_version(release[@"version"]))
        [NSUserDefaults.standardUserDefaults setObject:release[@"version"] forKey:@"WQUpstreamDismissedVersion"];
}

@implementation WQUpdateService {
    NSUserDefaults *_defaults;
    NSURLSessionConfiguration *_configuration;
    NSURLSession *_session;
    NSMutableData *_body;
    NSHTTPURLResponse *_response;
    NSMutableArray<void (^)(NSDictionary<NSString *, NSString *> *)> *_callbacks;
}
- (instancetype)init
{
    return [self initWithDefaults:NSUserDefaults.standardUserDefaults configuration:NSURLSessionConfiguration.ephemeralSessionConfiguration];
}
- (instancetype)initWithDefaults:(NSUserDefaults *)defaults configuration:(NSURLSessionConfiguration *)configuration
{
    if ((self = [super init])) {
        _defaults = defaults;
        _configuration = [configuration copy];
    }
    return self;
}
+ (instancetype)shared
{
    static WQUpdateService *service;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ service = [WQUpdateService new]; });
    return service;
}
- (void)check:(void (^)(NSDictionary<NSString *, NSString *> *))completion
{
    NSCAssert(NSThread.isMainThread, @"Update coordinator must run on the main thread");
    NSUserDefaults *defaults = _defaults;
    if ([defaults boolForKey:@"WQUpdateCheckOff"]) return;
    id cached = [defaults dictionaryForKey:@"WQUpstreamRelease"];
    if ([cached isKindOfClass:NSDictionary.class] && wq_update_valid_version(cached[@"version"])) completion(cached);
    // Join an existing request even if its attempt timestamp is fresh.
    if (_session) { [_callbacks addObject:[completion copy]]; return; }
    NSDate *now = NSDate.date;
    id next = [defaults objectForKey:@"WQUpstreamNextCheck"];
    // Ignore corrupted/clock-shifted cache dates more than seven days ahead.
    if ([next isKindOfClass:NSDate.class] && [next timeIntervalSinceDate:now] > 0
        && [next timeIntervalSinceDate:now] <= 7 * 24 * 3600) return;
    // Cache attempts, including failures, to prevent offline/relaunch request storms.
    [defaults setObject:[now dateByAddingTimeInterval:WQUpdateInterval] forKey:@"WQUpstreamNextCheck"];
    _callbacks = [NSMutableArray arrayWithObject:[completion copy]];
    _body = [NSMutableData new];
    _response = nil;
    NSURLSessionConfiguration *config = [_configuration copy];
    config.timeoutIntervalForRequest = 15;
    config.timeoutIntervalForResource = 20;
    config.HTTPCookieStorage = nil;
    config.HTTPShouldSetCookies = NO;
    config.URLCredentialStorage = nil;
    config.URLCache = nil;
    config.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    _session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:NSOperationQueue.mainQueue];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:WQUpdateURL]];
    NSString *etag = [defaults stringForKey:@"WQUpstreamETag"];
    if (cached && etag.length && etag.length <= 512) [request setValue:etag forHTTPHeaderField:@"If-None-Match"];
    [[_session dataTaskWithRequest:request] resume];
}
- (void)URLSession:(NSURLSession *__unused)session task:(NSURLSessionTask *__unused)task
    willPerformHTTPRedirection:(NSHTTPURLResponse *__unused)response newRequest:(NSURLRequest *__unused)request
    completionHandler:(void (^)(NSURLRequest *_Nullable))completionHandler
{
    // No credentials are attached; still fail closed on unexpected redirects.
    completionHandler(nil);
}
- (void)URLSession:(NSURLSession *__unused)session dataTask:(NSURLSessionDataTask *__unused)dataTask
    didReceiveResponse:(NSURLResponse *)response completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler
{
    if (![response isKindOfClass:NSHTTPURLResponse.class]) { completionHandler(NSURLSessionResponseCancel); return; }
    _response = (NSHTTPURLResponse *)response;
    NSInteger status = _response.statusCode;
    if (status == 429 || status == 403 || status == 503) {
        NSString *retry = [_response valueForHTTPHeaderField:@"Retry-After"];
        NSTimeInterval seconds = retry.doubleValue;
        if (seconds <= 0 && retry.length) {
            NSDateFormatter *format = [NSDateFormatter new];
            format.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
            format.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
            format.dateFormat = @"EEE, dd MMM yyyy HH:mm:ss zzz";
            seconds = [[format dateFromString:retry] timeIntervalSinceNow];
        }
        seconds = MIN(7 * 24 * 3600, MAX(WQUpdateInterval, seconds));
        [_defaults setObject:[NSDate dateWithTimeIntervalSinceNow:seconds] forKey:@"WQUpstreamNextCheck"];
    }
    completionHandler((status == 200 || status == 304) && response.expectedContentLength <= (int64_t)WQUpdateLimit
        ? NSURLSessionResponseAllow : NSURLSessionResponseCancel);
}
- (void)URLSession:(NSURLSession *__unused)session dataTask:(NSURLSessionDataTask *)dataTask didReceiveData:(NSData *)data
{
    if (_body.length + data.length > WQUpdateLimit) { [dataTask cancel]; return; }
    [_body appendData:data];
}
- (void)URLSession:(NSURLSession *)session task:(NSURLSessionTask *__unused)task didCompleteWithError:(NSError *)error
{
    NSUserDefaults *defaults = _defaults;
    NSDictionary *release = !error && _response.statusCode == 200 ? wq_update_release_from_data(_body) : nil;
    if (release) {
        [defaults setObject:release forKey:@"WQUpstreamRelease"];
        NSString *etag = [_response valueForHTTPHeaderField:@"ETag"];
        if (etag.length && etag.length <= 512) [defaults setObject:etag forKey:@"WQUpstreamETag"];
        else [defaults removeObjectForKey:@"WQUpstreamETag"];
    }
    NSArray *callbacks = [_callbacks copy];
    _callbacks = nil;
    _body = nil;
    _response = nil;
    _session = nil;
    [session finishTasksAndInvalidate];
    if (release && ![defaults boolForKey:@"WQUpdateCheckOff"])
        for (void (^callback)(NSDictionary *) in callbacks) callback(release);
}
@end
