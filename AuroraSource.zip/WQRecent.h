// WQ Files – Aurora Edition. GPL-3.0-or-later.
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
FOUNDATION_EXPORT NSNotificationName const WQRecentChanged;
@interface WQRecentStore : NSObject
+ (instancetype)shared;
- (instancetype)initWithDefaults:(NSUserDefaults *)defaults;
// Opt-in. Disabling clears local path history; no contents or remote analytics.
@property (nonatomic) BOOL enabled;
@property (nonatomic, readonly) NSArray<NSDictionary *> *entries;
- (void)recordPath:(NSString *)path readOnly:(BOOL)readOnly;
- (void)clear;
@end
NS_ASSUME_NONNULL_END
