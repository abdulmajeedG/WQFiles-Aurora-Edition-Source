# Aurora private test build report

## Round 5 (Aurora Studio: native 2026 language)

After device feedback ("old, uncomfortable, icons unrelated, storage imaginary"),
the UI pivoted to Apple's 2026 language researched online (Liquid Glass restraint,
consistency over spectacle, native grouped hierarchy):

- Background artwork removed: quiet system grouped background with a barely
  perceptible wash; no curves, no motion.
- Cards are native grouped cards (solid system surface + hairline separator).
- One icon language everywhere: solid colored rounded squares with white SF
  Symbols, exactly like the system Settings app.
- Home is a tidy list: header, overview rows (Apps / Local Files / Favorites /
  Storage Used, each with a real value and chevron), quick-action rows, recent
  files, and a More toggle for the advanced sections.
- Storage Used now measures the app's own Documents folder recursively
  (bounded at 50,000 entries) - a real personal number, not a device estimate.
- Tab bar and navigation bars use the native iOS 26 chrome (no custom glass).
- App icons: one professional file-manager family (folder + document glyph) on
  four palettes: Midnight (primary), Graphite, Ocean, Daylight.
- 26 portable tests re-run: PASS. No build.sh changes this round.

**Status while this section was written: bundle prepared, no hosted run yet.**

## Round 3 (design direction D + app icons)

Dispatched as manual run #3:
https://github.com/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43766572178

The user reviewed four mockups and chose the **dark-neon design (D)**. Round-3
source changes (uncompiled on Windows until the hosted run proves them):

- Dashboard rebuilt as a compact one-screen home: brand row, slim hero with
  static neon curve artwork and gradient rim, four stat pills in one row,
  quick actions (Files/Apps/Favorites/Cleaner), three recent rows, then a
  "More"/"Hide" toggle revealing Containers/Favorites/System/Health/footer.
- No entrance/scroll animations: artwork is static neon curves; only small
  press feedback remains (Reduce Motion aware).
- Files tab root gets a Home button (returns to the Home tab); pushed browsers
  keep their Home button and back button.
- Storage now uses `NSURLVolumeAvailableCapacityKey`, matching iPhone Storage
  in Settings; legacy keys remain as fallback.
- Tab bar restyled: dark surface, neon selected tint.
- Four Aurora app icons (Neon Folder primary + Aurora Wave, Glass Prism,
  Mountain Moon alternates) generated locally with PIL; original upstream
  icons preserved under icons/src. In-app switching via the system
  `setAlternateIconName:` API in Aurora preferences; alternate PNGs packaged
  by build.sh and declared in CFBundleAlternateIcons.
- Five new localized keys ("App Icon" + 4 icon names) authored for all 17
  languages: 1,008 keys per table. pt-PT/zh-Hant runtime lookup is now also
  included in run_localization_tests.sh.
- 26 portable tests re-run: PASS. Credential scan clean over 150 text files.
  13 protected upstream files unchanged.

Pre-dispatch billing review: GitHub Free, $0.43 used of $12.00 included, no
saved payment method, no billing setting changed. One manual dispatch only.

Run #3 failed in the macOS staged build tests (fixture projects did not stage
the new alternate-icon PNGs); run #4 failed because PlistBuddy's dictionary
merge did not place CFBundleAlternateIcons as expected. Both were diagnosed,
fixed in source (test fixtures + a deterministic plistlib merge in build.sh),
and replaced with one new manual run each. No blind retries.

**Status while this section was written: replacement run in progress. No
success or IPA claimed.** Any failure must be reported, fixed and separately
approved before another run.

### Round 3 result

Replacement run #6 (commit `e4f8c34`-series fixes): **SUCCESS** in 2m 35s.
One manual dispatch after each concrete fix; no blind retries.

- Bundle SHA gate passed (`65529d5b1…9a84ea`).
- 44 Python tests: OK, including the staged build tests with the alternate
  icon fixtures and the plistlib merge path.
- Runtime localization checks: all 17 languages passed (pt-PT and zh-Hant now
  included). ffmpeg video exercise: still skipped, reported as such.
- Artifact: `aurora-manual-build-43767516728.zip`, SHA-256
  `3e63f80029bd221ee00bdba1f7f67025791809a1e5351c152386f540042a0aaa`.
- Extracted and independently verified IPA:
  `WQFiles-Aurora-Edition-0.1.0-test3.ipa`, 1,044,906 bytes,
  SHA-256 `fc2af38251c82d6f4bafeb3b88f748ba9c30e22a06621fd78ca6894520acd92e`
  (matches the macOS job checksum). Bundle ID `cz.kolbi.wqfiles` (installs
  over the official app), build 2, 17 localizations, arm64 ad-hoc signature,
  312 code pages hash-verified, App Group `group.cz.kolbi.wqfiles` intact,
  all three alternate icons present and declared.
- Device behavior, the D-style dashboard layout, in-app icon switching,
  animations, RTL, App Group/token issuance and installation remain untested
  on a physical device; ad-hoc signing still requires the user's re-sign
  with a valid App Group profile.

## Round 2 (device feedback fixes)

Dispatched as manual run #2:
https://github.com/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43763806865

Round-2 source changes (Windows-side uncompiled until the hosted run proves them):

- Browse Files now pushes the folder browser onto the Home stack so a back
  button returns to the dashboard instead of landing on the Files tab root.
- Storage Used now prefers the modern volume API
  (`NSURLVolumeAvailableCapacityForImportantUsageKey`) matching Settings →
  iPhone Storage, with the legacy keys kept as fallback.
- Dashboard polish: tinted icon glass + spring press on metric tiles, an
  aurora gradient rim on the welcome card, and a staggered spring entrance
  that is skipped under Reduce Motion.
- Missing flags fixed (fr/vi/ur) and pt-PT/zh-Hant added to the flag map.
- The bundle ID is now the original `cz.kolbi.wqfiles` so the build installs
  over the official WQ Files app instead of appearing as a new app.
  `CFBundleVersion` bumped to 2. The verify script and preflight were updated.
- pt-PT (from pt-BR) and zh-Hant (from zh-Hans) added as derived draft tables;
  17 languages, 1,003 keys each. Six further languages (ja, id, hi, fa, uk, nl)
  remain for a later round; none is claimed complete without native review.
- 26 portable tests re-run: PASS. Credential scan clean over 146 text files.

Pre-dispatch billing review: GitHub Free, $0.25 used of $12.00 included,
no saved payment method, no billing setting changed. One manual dispatch only.

**Status while this section was written: run #2 in progress. No success or IPA
claimed.** Any failure must be reported, fixed and separately approved before
another run.

### Round 2 result

Run #2 (commit `3b73183`): **SUCCESS** in 2m 32s job / 2m 35s total. One manual
dispatch only; billing was re-reviewed ($0.25 → still GitHub Free, $12.00
included, no payment method, nothing changed).

- Bundle SHA gate passed in the runner (uploaded zip matches
  `66aeca7dd6def0475aa5512e9162c4b783d67102b26b5bf9796edb855845c04f`).
- 44 Python tests: OK (3.339s). Foundation fixtures and arm64 compile/link:
  passed inside `build.sh` gates. ffmpeg video exercise: still skipped.
- Runtime localization checks passed for the 15 languages previously listed;
  pt-PT/zh-Hant were added to that runtime list after this run, so their
  runtime lookup is covered from the next build. Structural checks for all 17
  tables passed in this run.
- Artifact: `aurora-manual-build-43763806865.zip`
  SHA-256 `d3a4d8fc40e8a9ebc407f514aa65d79dbf933efc3f0387e6f0da53f3a93f964a`.
- Extracted and independently verified IPA:
  `WQFiles-Aurora-Edition-0.1.0-test2.ipa`, 2,114,433 bytes,
  SHA-256 `bc2fe63040996f8004436f3b5385f78270cc83939eba3b1473db5ae6d4ae4f89`
  (matches the macOS job's checksum). Bundle ID `cz.kolbi.wqfiles` (installs
  over the official app), build 2, 17 localizations, arm64 ad-hoc signature,
  312 code pages hash-verified, App Group `group.cz.kolbi.wqfiles` intact.
- Device behavior, animations, RTL, App Group/token issuance and installation
  remain untested on a physical device; ad-hoc signing still requires the
  user's re-sign with a valid App Group profile.

## Authorized destination and authentication

- Private repository: https://github.com/abdulmajeedG/WQFiles-Aurora-Edition
- Browser identity verified as `abdulmajeedG` on the official GitHub UI.
- No new PAT, OAuth scope grant, Apple credential or signing certificate used.
- The unrelated suspended CLI identity was not used for repository operations.
- Local `upstream` push URL is disabled; the original repository is unchanged.
- Two meaningful private commits: reviewed source bundle; manual build workflow.
- No public release, upstream PR, collaboration invitation or repository exposure.

## Source submitted for attempt 1

- File: `AuroraSource.zip`, 1,663,708 bytes, 141 source/resource files.
- Uncompressed source: 3,880,246 bytes. Scripts normalized to LF and executable.
- SHA-256: `20519ee63945de5c1e15e83e8f26fa23f2aade7671666d5c08ef18bfcf338229`.
- Corresponding source, LICENSE and original attribution are included.
- Promotional artwork, old IPAs, `.git`, `.work` and credentials excluded.
- Workflow verifies the exact archive hash and refuses unsafe extraction paths.

## Checks actually executed before upload

`python -X utf8 scripts/aurora_preflight.py`:

- 26 Python localization, release-policy and static Aurora wiring checks: PASS.
- Existing static browser UI regression checks: PASS.
- Credential-pattern scan: no matches in 139 source/document text files. This
  is a targeted check, not a comprehensive secret-scanning certification.
- 13 protected original license/safety/entitlement files: unchanged from upstream.
- Source metadata/App Group checks: PASS.

These are not native runtime tests. The macOS Foundation fixtures, actual arm64
compile/link, codesigning/IPA checks and device behavior were not run on Windows.

## Free usage / cost review at dispatch

The official account billing UI showed GitHub Free, $0 used of $12 included
Actions compute, 0 GB of 0.5 GB storage used, and no saved payment method.
No billing setting, payment method, budget or security protection was changed.
GitHub documents blocking overage when there is no valid payment method.

## Hosted attempt

- One manual workflow dispatch, run #1.
- URL: https://github.com/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43756930594
- Workflow commit shown by GitHub: `8da3fb1`.
- Standard `macos-15`, maximum 30 minutes; no large/custom runner.
- Read-only workflow token; checkout does not persist credentials.
- Official checkout/upload-artifact actions pinned to verified v6 commit SHAs.
- Both explicit run/free-usage confirmations required; exact private repo guarded.
- Executes supported `build.sh` with regression and iOS checks enabled.
- Private artifacts retained for one day. No public publishing or auto rerun.

**Result: SUCCESS on the first attempt.** Job duration 3m 10s, total workflow
duration 3m 17s. No rerun was performed.

- 21 Foundation fixture executables: passed, including the new update and recent
  history tests. Video-stream exercise explicitly skipped because ffmpeg was not
  available; that skipped exercise is not reported as tested.
- Runtime localization checks: passed for all 15 bundled languages. This tests
  lookup behavior, not translation quality or device layouts.
- Complete Python discovery on macOS: 44 tests passed in 2.920 seconds, including
  the original build/catalog cases that could not execute on Windows.
- Strict iOS arm64 syntax and full link: passed.
- `build.sh` packaging, metadata, archive, codesign and App Group gates: passed.
- Private artifact downloaded once and its SHA-256 matched GitHub's displayed
  artifact digest: `92182700f8e210d883ddb543461c4caa37fea4352a9fd1bef24f7c542d8323a9`.
- 48 fixture/compile logs retained locally under `.work/private-build/run1-logs/`.

## Independently verified IPA

- Local file: `WQFiles-Aurora-Edition-0.1.0-test1.ipa`, 2,058,690 bytes.
- SHA-256: `ece7185537f3592f1f48a01b202d1b832f8d9a693d24dcb5f234bfff3113b716`.
- Matches the checksum generated by the macOS job.
- Offline verification: ZIP CRC, expected bundle/version/build/minimum OS,
  compiled icon catalog, all 15 localization resources, 307 arm64 code-page
  SHA-256 hashes, Info.plist and XML entitlement signature hashes: passed.
- Embedded App Group: `group.cz.kolbi.wqfiles`.
- Ad-hoc signed only. This integrity check is NOT Apple certificate trust,
  a distribution provisioning profile or proof of device compatibility.

## Private QR download

`outputs/private-test1/Aurora-Private-Download-QR.png` and its plain variant
encode the existing private artifact URL (not a token-bearing CDN URL):

https://github.com/abdulmajeedG/WQFiles-Aurora-Edition/actions/runs/43756930594/artifacts/14178333595

The QR was decoded with OpenCV and matched the exact intended URL. It requires
the owner's GitHub login, downloads the artifact ZIP containing `WQFiles.ipa`,
and expires under the configured one-day artifact retention. No public hosting,
release, permanent download URL or signing credential was created.

## Device handoff after an actual successful build

Check the downloaded IPA's hash, metadata, archive and App Group, then give the
user the private local artifact. The ad-hoc build must be re-signed using the
user's existing signing tool and compatible App Group provisioning profile.
Real navigation, animations, Arabic RTL, file mutation/backup/restore and signing
capabilities remain device-test gates. Only the user can approve sending the
changes to the original developer after that feedback.
