# WQ Files – Aurora Edition: current status

**First private test IPA built successfully on GitHub macOS, run #1.**
Private repository: `abdulmajeedG/WQFiles-Aurora-Edition`.
No public release or upstream pull request. See [build report](AURORA-BUILD-REPORT.md).

## Implemented in source, pending macOS and device verification

- Native aurora/vector mountain artwork, glass-like semantic surfaces, Light /
  Dark / system selection, saved appearance, short nonblocking animated splash.
- Native dashboard: welcome card, measured local file/storage metrics, app-count
  snapshot only after the original scan finishes, favorites, real shortcuts,
  Home/Apps/Favorites/Files tabs. Cleaner, backups, container groups, logs,
  health checks and Go to Path remain reachable.
- Circular cleaning progress driven by completed selected apps, animated app
  discovery driven by existing scan state, cancellation retained. Layer animations
  stop off-window/inactive and respect Reduce Motion. No fake progress timer.
- Opt-in recent files: local paths only, max 12 entries, deduplication, original
  read-only state retained, clear history and erase-on-disable.
- Single original `source.json` update coordinator for both navigation designs.
  Attempts throttled to 12 hours (including failure), ETag caching, bounded
  response, Retry-After, numeric stable-version ordering, release notes,
  disable/dismiss choices. Aurora version and upstream base version are distinct.
- User-initiated official IPA download, real transfer progress, cancellation,
  restricted HTTPS redirects, 32 MiB download / 128 MiB extraction limits, existing
  safe ZIP parser, metadata/version/arm64 header checks, then iOS share sheet.
  External signing apps must preserve an App Group. No automatic signing or install;
  no Apple credentials/certificates requested. Validation is NOT certificate trust.
- A clearly labelled upstream IPA is the original developer's release, **not an
  Aurora update**. There is no Aurora feed or fabricated Aurora release URL.

## Localization

15 bundled tables, 1,003 keys each: English, Arabic, German, Spanish, Italian,
Brazilian Portuguese, Russian, Polish, Turkish, Thai, Korean, Simplified Chinese,
Vietnamese, French and Urdu.

Existing upstream values are preserved. Vietnamese was already in upstream but
unregistered. French/Urdu draft values were migrated from the user's earlier local
translation files and updated for current keys; old workspace code/IPAs were not
reused. Aurora additions are machine-assisted drafts. Key/format validation is
not native-speaker review or proof of complete language/layout support.

Additional requested languages remain pending: six fully authored tables
(Japanese, Indonesian, Hindi, Persian, Ukrainian, Dutch) were deferred to keep
each device-test build reviewable; pt-PT and zh-Hant ship in this round as
machine-assisted derived drafts (native review still pending). Arabic and Urdu
use the existing AppleLanguages restart-based RTL mechanism; device RTL testing
is still required.

## Verification boundaries

Windows can run Python localization, release-policy and static wiring/browser
contracts. It cannot run the Foundation fixture executables or compile/link UIKit.
New offline `WQUpdateTests.m` and `WQRecentTests.m` have now passed in GitHub's
macOS preflight. The hosted run passed all 21 Foundation fixture executables,
44 Python tests, runtime lookup for 15 languages, strict iOS arm64 compile/link
and `build.sh` artifact gates. One ffmpeg-dependent video exercise was skipped.
Passing host checks does not certify device animations, navigation, backup/restore,
App Group/token issuance or installation.

Device feedback after attempt 1 produced these round-2 source changes (uncompiled
on Windows until the next hosted run): back button restored when opening the file
browser from the dashboard; storage figure switched to the modern volume API
(`volumeAvailableCapacityForImportantUsage`) matching Settings; metric tiles got
tinted icon glass and press spring, the welcome card an aurora gradient rim, and
a staggered spring entrance (Reduce Motion aware); missing flags fixed for
fr/vi/ur; pt-PT and zh-Hant derived draft tables added (17 languages total).

The original complete Python discovery was attempted before changes: 19 passing
methods, 12 methods with environment errors (13 error entries including subtests).
Those macOS/POSIX build/catalog failures are not hidden or reported as passes.

## Secure delivery plan

1. The browser session has verified `abdulmajeedG` through the official GitHub UI.
   No new PAT/OAuth grant is needed for the browser source-bundle upload. The old CLI
   identity is `abomohma3d-dot`, not the requested `abdulmajeedG`; it returned a
   suspension error and is not used for development operations. Do not try to
   bypass its suspension. No token/password has been printed or requested in chat.
2. At the user's direction: one **private** build repository, not a public release.
   Restrict any new access to that repository. Upstream push is disabled locally.
3. Review free compute/storage and existing no-paid-overage protection. The manual
   workflow requires explicit approvals, a private repository with the exact
   expected name, standard macos-15, a 30-minute maximum, read-only GITHUB_TOKEN,
   verified official action SHAs and one-day private artifact retention. Its input
   checkbox is an attestation, **not a technical billing limit**. Never enable
   billing or change account budgets without explicit permission.
4. Run the supported `build.sh` once, without skipping preflight. Report failures;
   no blind rerun. Download and check the artifact only after an actual success.
5. User re-signs with a compatible App Group profile and tests on their phone.
6. Only after the user's device feedback and separate permission: prepare/send
   the source changes to kolbicz for optional review. No automatic PR or release.

## Known unfinished items

- macOS build passed; physical-device launch is pending. The verified ad-hoc IPA
  still needs valid signing/provisioning before installation.
- App icon assets still need final artwork approval/integration; the dashboard's
  native folder mark and promotional art are not a new compiled app icon catalog.
- Remaining languages, native-speaker review, Dynamic Type/VoiceOver/RTL and
  all original safety/regression/device release gates.
- End-to-end download/share testing with installed signing apps. iOS decides
  which apps accept IPA files; universal compatibility is not claimed.

## Building on an authorized Mac

Install stable Xcode with iPhoneOS SDK >= 26 and Python 3, select its developer
directory, then run `bash ./build.sh`. The script runs the full regression suite
and packages an ad-hoc-signed `WQFiles.ipa` only after validation. Re-signing and a
valid provisioning profile retaining an App Group are required for installation.
The separate Aurora bundle ID has been removed at the user's request: the build
now uses the original application identifier `cz.kolbi.wqfiles` so it installs
over the official WQ Files app (same container) instead of appearing as a new
app. The requested App Group entitlement remains `group.cz.kolbi.wqfiles`.
Never drop it; avoid concurrent operations by apps sharing that group.
Re-signing must use a provisioning profile valid for the original identifier.
