# WQ Files – Aurora Edition: engineering record

## Phase 1 — inspection (2026-11-15)

Clean clone of `https://github.com/kolbicz/WQFiles`, upstream commit
`dcd5c1811811fb8bb75a370f9e0080d0b856fb11`, local branch `aurora-edition`.
Existing workspace projects/artifacts have not been modified or reused.

### Architecture and feature inventory

- `main.m`: UIKit navigation, classic and Prism home, directory browser,
  file actions, text/image viewing, search, favorites, log, settings, scene lifecycle.
- `WQUI`: shared UI; `WQLocalization`: keyed `.strings` lookup, verbatim data.
- `WQCore`, `WQAccess`, safety headers: worse_query, access tokens, inode
  enumeration, identity checks, durable backup/recovery and protected mutations.
- `WQLaunchServices`, `WQApps`, `WQCache`, `WQTrash`: container names,
  app backup/restore, cache cleaning, recovery and recently deleted files.
- `WQArchive`, `WQSharing`, `WQMediaStream`: ZIP, exports and native media.
- `WQPlistEditor`, `WQHexViewer`, `WQSQLiteViewer`, `WQSQLiteSave`, `WQSyntax`:
  editors, integrity checks, transaction-aware saves and syntax highlighting.
- `WQHealth`: asynchronous startup checks. Must remain independent of branding.
- System dependencies: UIKit, Foundation, Security, UniformTypeIdentifiers,
  SQLite, zlib, plus dynamically loaded Apple media frameworks. No package manager.

The original UI has a native tabbed Prism design and optional classic list.
Many screens already use semantic system colors and shared backdrops. These
controllers and both navigation modes are retained rather than rewritten.
Two duplicate `source.json` checkers currently compare the app version with
upstream, cache only success, and offer neither notes nor persisted dismissal.

### Localization baseline

Bundled: en, ar, de, es, it, ko, pl, pt-BR, ru, th, tr, zh-Hans; vi exists
upstream but is not registered in metadata or the localization test list.
AppleLanguages controls the existing restart-based language/RTL selection.
Key/format parity is a structural check, not linguistic or layout certification.

### Build and tests

`build.sh` requires macOS/Xcode (`xcrun`, iPhoneOS SDK, `actool`, `codesign`,
`PlistBuddy`, `plutil`) and runs `tests/run_all_tests.sh` before packaging.
It stages and validates an arm64 IPA, metadata, signature and App Group before
replacing output. Its ad-hoc signature is NOT a distribution provisioning profile.
`entitlements.plist` and all worse_query/safety functionality must remain intact.
Deployment minimum 26.0 is inherited, not a new Aurora compatibility claim.

Windows baseline: Python discovery ran 31 test methods: 19 passed, 12 methods
errored (13 error entries including subtests). Build fixtures require POSIX/macOS;
two catalog fixtures cannot fsync a directory on Windows. No runtime/device test
or iOS build has run. The full suite remains a required macOS gate.

## Phase 2 — security and distribution

Local clone only; `upstream` is read-only in practice (no push performed).
No account authentication, remote creation, push, workflow run or release.
GPL-3.0-or-later allows a clearly marked modified distribution with original
notices/license retained and corresponding source supplied with binaries.
Keep README upstream credits, LICENSE, and modification notices. No author
endorsement is implied. This is an engineering assessment, not legal advice.

Proposed repository (NOT created): `abdulmajeedG/WQFiles-Aurora-Edition`.
Creation, visibility, push scope and any hosted build require explicit approval.
Do not reuse credentials or the unrelated account mentioned in old workspace reports.
Do not include signing material, existing IPAs or unrelated workspace files.

## Remaining release gates

- macOS: complete regression runner, strict Objective-C compile/link, `build.sh`.
- Device: Light/Dark/system appearance, large text, VoiceOver, reduced motion /
  transparency, splash lifecycle, Arabic RTL, both navigation designs, rotation.
- Disposable data: file operations, ZIP, all editors, app backup/restore, cache
  cleanup, health failures, App Group/token issuance and signing capabilities.
- Update transport/cache/dismissal fixtures and offline/error behavior.
- Native-speaker review of every newly translated language; no false complete-support claim.
- Review source, secrets, GPL source availability and build artifact before publication.
