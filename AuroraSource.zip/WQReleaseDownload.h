// WQ Files – Aurora Edition. GPL-3.0-or-later.
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN
@interface WQReleaseDownloadController : UIViewController <NSURLSessionDownloadDelegate>
- (instancetype)initWithRelease:(NSDictionary<NSString *, NSString *> *)release;
@end
NS_ASSUME_NONNULL_END
