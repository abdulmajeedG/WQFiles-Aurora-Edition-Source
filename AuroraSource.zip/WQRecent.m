// WQ Files – Aurora Edition. GPL-3.0-or-later.
#import "WQRecent.h"
NSNotificationName const WQRecentChanged = @"WQAuroraRecentChanged";
static NSString *const WQRecentEnabled = @"WQAuroraRecentEnabled";
static NSString *const WQRecentEntries = @"WQAuroraRecentEntries";
@implementation WQRecentStore {
    NSUserDefaults *_defaults;
}
+ (instancetype)shared
{
    static WQRecentStore *store;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ store = [[self alloc] initWithDefaults:NSUserDefaults.standardUserDefaults]; });
    return store;
}
- (instancetype)initWithDefaults:(NSUserDefaults *)defaults
{
    if ((self = [super init])) _defaults = defaults;
    return self;
}
- (BOOL)enabled { return [_defaults boolForKey:WQRecentEnabled]; }
- (void)setEnabled:(BOOL)enabled
{
    [_defaults setBool:enabled forKey:WQRecentEnabled];
    if (!enabled) [self clear];
    else [NSNotificationCenter.defaultCenter postNotificationName:WQRecentChanged object:nil];
}
- (NSArray<NSDictionary *> *)entries
{
    if (!self.enabled) return @[];
    NSMutableArray *valid = [NSMutableArray new];
    id stored = [_defaults objectForKey:WQRecentEntries];
    if (![stored isKindOfClass:NSArray.class]) return @[];
    for (id entry in stored) {
        if (![entry isKindOfClass:NSDictionary.class]) continue;
        id path = entry[@"path"], date = entry[@"date"], readOnly = entry[@"readOnly"];
        if (![path isKindOfClass:NSString.class] || ![path hasPrefix:@"/"] || [path length] > 4096
            || ![date isKindOfClass:NSDate.class] || ![readOnly isKindOfClass:NSNumber.class]) continue;
        [valid addObject:@{@"path": path, @"date": date, @"readOnly": readOnly}];
        if (valid.count == 12) break;
    }
    return valid;
}
- (void)recordPath:(NSString *)path readOnly:(BOOL)readOnly
{
    if (!self.enabled || ![path isKindOfClass:NSString.class] || ![path hasPrefix:@"/"] || path.length > 4096) return;
    NSString *normalized = path.stringByStandardizingPath;
    NSMutableArray *entries = [NSMutableArray arrayWithObject:@{@"path": normalized, @"date": NSDate.date, @"readOnly": @(readOnly)}];
    for (NSDictionary *entry in self.entries) {
        if (![entry[@"path"] isEqual:normalized]) [entries addObject:entry];
        if (entries.count == 12) break;
    }
    [_defaults setObject:entries forKey:WQRecentEntries];
    [NSNotificationCenter.defaultCenter postNotificationName:WQRecentChanged object:nil];
}
- (void)clear
{
    [_defaults removeObjectForKey:WQRecentEntries];
    [NSNotificationCenter.defaultCenter postNotificationName:WQRecentChanged object:nil];
}
@end
